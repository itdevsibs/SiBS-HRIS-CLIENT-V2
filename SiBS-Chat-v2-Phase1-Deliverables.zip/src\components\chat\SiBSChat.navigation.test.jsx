import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { MemoryRouter } from "react-router-dom";
import SiBSChat from "./SiBSChat";
import {
  saveChatState,
  loadSavedChatState,
  saveConversationDraft,
  getConversationDraft,
  clearChatState,
} from "@/lib/utils/chat/chatStatePersistence";

const now = new Date();
const nowIso = now.toISOString();

const mockConversations = [
  {
    id: 101,
    title: "HR IT Support Ticket",
    conversationType: "HELPDESK",
    isHelpdesk: true,
    helpdeskCategory: "IT",
    caseCode: "IT-2026-001",
    caseStatus: "OPEN",
    createdBySibsId: "EMP-001",
    lastMessageText: "Can you restart your router?",
    lastMessageAt: nowIso,
    unreadCount: 2,
    members: [
      { sibsId: "EMP-001", displayName: "Ralph Vincent", role: "requester" },
      { sibsId: "IT-101", displayName: "IT Admin", role: "support" },
    ],
  },
  {
    id: 102,
    title: "Dev Team Discussion",
    conversationType: "GROUP",
    isGroup: true,
    lastMessageText: "Let us review Phase 1 PR",
    lastMessageAt: nowIso,
    unreadCount: 0,
    members: [
      { sibsId: "EMP-001", displayName: "Ralph Vincent" },
      { sibsId: "EMP-002", displayName: "Jane Doe" },
    ],
  },
  {
    id: 103,
    title: "Jane Doe",
    conversationType: "DIRECT",
    isGroup: false,
    otherMember: {
      sibsId: "EMP-002",
      displayName: "Jane Doe",
      chatNickname: "Janie",
      lastSeenAt: nowIso,
    },
    lastMessageText: "Good morning! Are we good for the meeting?",
    lastMessageAt: nowIso,
    unreadCount: 1,
    members: [
      { sibsId: "EMP-001", displayName: "Ralph Vincent" },
      { sibsId: "EMP-002", displayName: "Jane Doe" },
    ],
  },
];

let mockChatContext = {
  chatAllowed: true,
  conversations: mockConversations,
  activeConversation: null,
  activeConversationId: null,
  totalUnread: 3,
  messages: [],
  messagesLoading: false,
  conversationsLoading: false,
  error: null,
  selectConversation: vi.fn((id) => {
    const found = mockConversations.find((c) => c.id === id) || null;
    mockChatContext.activeConversation = found;
    mockChatContext.activeConversationId = id;
  }),
  refreshConversations: vi.fn(),
  setChatWindowOpen: vi.fn(),
  startPrivateConversation: vi.fn(),
  startGroupConversation: vi.fn(),
  typingByConversation: {},
  presence: {},
};

vi.mock("@/services/context/ChatContext", () => ({
  useChat: () => mockChatContext,
}));

vi.mock("@/services/context/UserContext", () => ({
  useUser: () => ({
    user: {
      sibsId: "EMP-001",
      employee_id: "EMP-001",
      displayName: "Ralph Vincent",
      role: "EMPLOYEE",
    },
  }),
}));

vi.mock("@/lib/axios/chatSocket", () => ({
  default: {
    on: vi.fn(),
    off: vi.fn(),
    emit: vi.fn(),
  },
}));

vi.mock("@/lib/axios/sibsChat", () => ({
  getChatAttachmentUrl: vi.fn(),
  getChatAttachmentPreview: vi.fn(),
  getChatParticipants: vi.fn(async () => []),
  getChatHelpdeskDuty: vi.fn(async () => ({ members: [] })),
  getChatHelpdeskRequestableCategories: vi.fn(async () => ["IT", "TA_HR"]),
  getHelpdeskTicketDetails: vi.fn(async () => null),
  updateHelpdeskTicketStatus: vi.fn(async () => ({})),
  getChatMessages: vi.fn(async () => []),
  markChatRead: vi.fn(),
  sendChatMessage: vi.fn(),
  searchGifs: vi.fn(async () => []),
}));

vi.mock("@/lib/utils/chat/chatHelpdeskVisibility", () => ({
  shouldShowHelpdeskInSibsChat: () => true,
}));

describe("SiBSChat Phase 1: Window UX and Conversation Navigation", () => {
  beforeEach(() => {
    clearChatState();
    mockChatContext.activeConversation = null;
    mockChatContext.activeConversationId = null;
    mockChatContext.totalUnread = 3;
    mockChatContext.selectConversation.mockClear();

    Object.defineProperty(window, "matchMedia", {
      writable: true,
      value: vi.fn().mockImplementation((query) => ({
        matches: false,
        media: query,
        onchange: null,
        addListener: vi.fn(),
        removeListener: vi.fn(),
        addEventListener: vi.fn(),
        removeEventListener: vi.fn(),
        dispatchEvent: vi.fn(),
      })),
    });
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it("renders non-modal window structure with role='region' and no modal locks", () => {
    render(
      <MemoryRouter>
        <SiBSChat isOpen={true} />
      </MemoryRouter>,
    );

    const chatRegion = screen.getByRole("region", { name: /SiBS Chat/i });
    expect(chatRegion).toBeInTheDocument();
    expect(chatRegion).not.toHaveAttribute("aria-modal", "true");
    expect(chatRegion).toHaveAttribute("id", "sibs-chat-panel");
  });

  it("shows floating launcher when closed with total unread badge", () => {
    render(
      <MemoryRouter>
        <SiBSChat isOpen={false} />
      </MemoryRouter>,
    );

    const launcher = screen.getByRole("button", { name: /Open SiBS Chat, 3 unread messages/i });
    expect(launcher).toBeInTheDocument();
    expect(within(launcher).getByText("3")).toBeInTheDocument();
  });

  it("defaults to Recent (All) chats tab and displays category badges and Manila dates", async () => {
    render(
      <MemoryRouter>
        <SiBSChat isOpen={true} />
      </MemoryRouter>,
    );

    // Recent tab is selected
    const recentTab = screen.getByRole("button", { name: /Recent/i });
    expect(recentTab).toHaveAttribute("aria-selected", "true");

    // Displays authorized chats
    expect(screen.getByText("Dev Team Discussion")).toBeInTheDocument();
    expect(screen.getByText("Janie")).toBeInTheDocument();

    // Check category badges in Recent view
    await waitFor(() => {
      expect(screen.getAllByText("IT Support").length).toBeGreaterThan(0);
    });
    expect(screen.getAllByText("Group").length).toBeGreaterThan(0);
    expect(screen.getAllByText("Direct").length).toBeGreaterThan(0);
  });

  it("switches category filter tabs and displays category-specific action buttons", () => {
    render(
      <MemoryRouter>
        <SiBSChat isOpen={true} />
      </MemoryRouter>,
    );

    // Click Private tab
    const privateTab = screen.getByRole("button", { name: /^Private/i });
    fireEvent.click(privateTab);
    expect(privateTab).toHaveAttribute("aria-selected", "true");
    expect(screen.getByText("Janie")).toBeInTheDocument();
    expect(screen.queryByText("Dev Team Discussion")).not.toBeInTheDocument();
    expect(screen.getAllByRole("button", { name: /Start private message/i }).length).toBeGreaterThan(0);

    // Click Groups tab
    const groupsTab = screen.getByRole("button", { name: /^Groups$/i });
    fireEvent.click(groupsTab);
    expect(groupsTab).toHaveAttribute("aria-selected", "true");
    expect(screen.getByText("Dev Team Discussion")).toBeInTheDocument();
    expect(screen.queryByText("Janie")).not.toBeInTheDocument();
    expect(screen.getAllByRole("button", { name: /Create group chat/i }).length).toBeGreaterThan(0);

    // Click Helpdesk tab
    const helpdeskTab = screen.getByRole("button", { name: /^Helpdesk$/i });
    fireEvent.click(helpdeskTab);
    expect(helpdeskTab).toHaveAttribute("aria-selected", "true");
    expect(screen.getByRole("button", { name: /New IT Support/i })).toBeInTheDocument();
  });

  it("supports Minimizing to floating dock chip and Restoring back to active chat", async () => {
    render(
      <MemoryRouter>
        <SiBSChat isOpen={true} />
      </MemoryRouter>,
    );

    // Click Minimize button on sidebar header
    const minimizeBtns = screen.getAllByRole("button", { name: /Minimize chat/i });
    fireEvent.click(minimizeBtns[0]);

    // Panel is marked minimized
    const chatRegion = screen.getByRole("region", { name: /SiBS Chat/i });
    expect(chatRegion).toHaveAttribute("data-minimized", "true");

    // Minimized Dock Chip appears
    const dockChip = screen.getByTestId("sibs-chat-minimized-dock");
    expect(dockChip).toBeInTheDocument();
    expect(dockChip).toHaveAttribute("aria-label", "Minimized SiBS Chat");

    // Click Restore button on the dock chip
    const restoreBtn = within(dockChip).getByRole("button", { name: /Restore chat window/i });
    fireEvent.click(restoreBtn);

    // Panel is restored
    expect(chatRegion).toHaveAttribute("data-minimized", "false");
  });

  it("preserves conversation drafts and UI state in employee-namespaced sessionStorage", () => {
    saveConversationDraft("EMP-001", 102, "Hello team, draft in progress");
    expect(getConversationDraft("EMP-001", 102)).toBe("Hello team, draft in progress");

    saveChatState("EMP-001", {
      isExpanded: true,
      activeCategoryTab: "groups",
      activeConversationId: 102,
    });

    const state = loadSavedChatState("EMP-001");
    expect(state.isExpanded).toBe(true);
    expect(state.activeCategoryTab).toBe("groups");
    expect(state.activeConversationId).toBe(102);
  });

  it("navigates into conversation and selects conversation through ChatContext", () => {
    render(
      <MemoryRouter>
        <SiBSChat isOpen={true} />
      </MemoryRouter>,
    );

    const devChatBtn = screen.getByRole("button", { name: /Dev Team Discussion/i });
    fireEvent.click(devChatBtn);

    expect(mockChatContext.selectConversation).toHaveBeenCalledWith(102);
  });

  it("renders active conversation header and composer with clean non-clipping placeholder", () => {
    mockChatContext.activeConversation = mockConversations[1]; // Dev Team Discussion (Group)
    mockChatContext.activeConversationId = 102;

    render(
      <MemoryRouter>
        <SiBSChat isOpen={true} />
      </MemoryRouter>,
    );

    // Header title and member count rendered in conversation pane
    expect(screen.getByRole("heading", { name: "Dev Team Discussion", hidden: true })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /2 members/i, hidden: true })).toBeInTheDocument();

    // Verify composer textarea is present with concise placeholder in compact mode
    const textarea = screen.getByPlaceholderText("Type a message...", { hidden: true });
    expect(textarea).toBeInTheDocument();

    // Action buttons rendered
    expect(screen.getByRole("button", { name: /Chat theme & wallpaper/i, hidden: true })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Group info/i, hidden: true })).toBeInTheDocument();
  });

  it("renders elevated empty workspace with quick-action cards in expanded mode", () => {
    mockChatContext.activeConversation = null;
    mockChatContext.activeConversationId = null;
    saveChatState("EMP-001", {
      isExpanded: true,
      activeConversationId: null,
      activeCategoryTab: "recent",
    });

    render(
      <MemoryRouter>
        <SiBSChat isOpen={true} />
      </MemoryRouter>,
    );

    // Empty workspace header and title
    expect(screen.getAllByRole("heading", { name: /SiBS Chat Workspace/i, hidden: true }).length).toBeGreaterThan(0);

    // Quick-action cards rendered
    expect(screen.getByRole("button", { name: /Direct Message/i, hidden: true })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Team Group/i, hidden: true })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /IT & HR Helpdesk/i, hidden: true })).toBeInTheDocument();
  });
});
