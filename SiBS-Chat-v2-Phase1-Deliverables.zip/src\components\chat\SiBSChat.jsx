/* eslint-disable react-hooks/set-state-in-effect, no-unused-vars */
import { createSystemDateTimeFormatter } from "@/lib/axios/dateFormatter";
import {
  useCallback,
  useEffect,
  useLayoutEffect,
  memo,
  useMemo,
  useRef,
  useState,
} from "react";
import { createPortal } from "react-dom";
import { useLocation } from "react-router-dom";
import { shouldShowHelpdeskInSibsChat } from "@/lib/utils/chat/chatHelpdeskVisibility";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Eye,
  EyeOff,
  FileText,
  FileSpreadsheet,
  FolderTree,
  Download,
  ImagePlus,
  ListFilter,
  Loader2,
  Lock,
  Maximize2,
  MessageCircleMore,
  Headset,
  MonitorCog,
  HeartHandshake,
  Minimize2,
  Minus,
  MoreHorizontal,
  MapPin,
  Music,
  Pencil,
  Plus,
  Reply,
  Palette,
  Search,
  Send,
  Smile,
  Settings2,
  Trash2,
  User,
  UserPlus,
  UsersRound,
  X,
} from "lucide-react";

import {
  getChatAttachmentUrl,
  getChatAttachmentPreview,
  getChatParticipants,
  getChatHelpdeskDuty,
  getChatHelpdeskRequestableCategories,
  getHelpdeskTicketDetails,
  updateHelpdeskTicketStatus,
  getChatThemeImageBlob,
} from "@/lib/axios/sibsChat";
import {
  getTrendingChatGifs,
  searchChatGifs,
} from "@/lib/axios/gifSearch";
import ChatDocumentPreviewModal from "@/components/chat/ChatDocumentPreviewModal";
import ChatHeicThumbnail from "@/components/chat/ChatHeicThumbnail";
import { hasChatHeicSignature, isChatHeicImage } from "@/lib/utils/chat/chatHeicPreview";
import { decodeChatCsvBytes } from "@/lib/utils/chat/chatCsvPreview";
import ChatVideoPlayer from "@/components/chat/ChatVideoPlayer";
import ChatAudioPlayer from "@/components/chat/ChatAudioPlayer";
import ChatTypingIndicator from "@/components/chat/ChatTypingIndicator";
import ChatThemeModal from "@/components/chat/ChatThemeModal";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { useChat } from "@/services/context/ChatContext";
import { useUser } from "@/services/context/UserContext";
import { ensureSibsChatSystemNotifications } from "@/lib/sibsChatSystemNotifications";
import { calculateSeenMembersByMessageId } from "@/lib/utils/chat/chatSeenReceipts";
import {
  getChatLayoutFlip,
  getExpandedChatBounds,
} from "@/lib/utils/chat/chatWindowLayout";
import {
  calculatePixelLuminanceIsDark,
  getChatThemeBackgroundStyle,
  isChatThemeCustom,
  isChatThemeDark,
} from "@/lib/utils/chat/chatTheme";
import {
  calculatePrependScrollTop,
  checkIsNearBottom,
  shouldSnapToBottom,
} from "@/lib/utils/chat/chatScroll";
import {
  loadSavedChatState,
  saveChatState,
  saveConversationDraft,
  getConversationDraft,
  clearConversationDraft,
  clearChatState,
  cleanupOtherEmployeeChatStates,
} from "@/lib/utils/chat/chatStatePersistence";

// These formatters are used for every message row. Constructing a new Intl
// DateTimeFormat for every timestamp on every React render is expensive,
// especially in group chats with many messages. Keep the HRIS Manila display
// policy while reusing the same immutable formatter instances.
const chatClockFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", hour: "numeric", minute: "2-digit", hour12: true,
});
const chatDayKeyFormatter = createSystemDateTimeFormatter("en-CA", {
  timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit",
});
const chatConversationDateFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", month: "long", day: "numeric", year: "numeric",
});
const chatCaseDateFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", month: "short", day: "numeric", year: "numeric",
});
const chatMessageDayFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", weekday: "short", month: "long", day: "numeric", year: "numeric",
});
const chatWeekdayFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", weekday: "short",
});
const chatCenterDateFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", month: "long", day: "numeric",
});
const chatCenterDateWithYearFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", month: "long", day: "numeric", year: "numeric",
});
const chatFullTooltipDateTimeFormatter = createSystemDateTimeFormatter("en-PH", {
  timeZone: "Asia/Manila", month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit", hour12: true,
});

const MAX_ATTACHMENT_BYTES = 10 * 1024 * 1024;
const MAX_ATTACHMENTS_PER_MESSAGE = 5;

function getFileExtension(value) {
  const name = String(value ?? "").trim().toLowerCase();
  const dotIndex = name.lastIndexOf(".");
  return dotIndex >= 0 ? name.slice(dotIndex) : "";
}

function bytesToAscii(bytes, start, length) {
  return String.fromCharCode(...bytes.slice(start, start + length));
}

function hasJpegEndMarker(bytes) {
  const start = Math.max(2, bytes.length - 4096);
  for (let index = bytes.length - 2; index >= start; index -= 1) {
    if (bytes[index] === 0xff && bytes[index + 1] === 0xd9) return true;
  }
  return false;
}

// Validate the ZIP central directory (not merely the file extension) for
// Word/Excel OpenXML files. The file is never extracted or executed here.
function isChatOfficeOpenXmlZip(bytes, extension) {
  if (extension !== ".docx" && extension !== ".xlsx") return false;
  if (bytes.length < 22 || bytes[0] !== 0x50 || bytes[1] !== 0x4b) return false;
  const read16 = (at) => (bytes[at] | (bytes[at + 1] << 8)) >>> 0;
  const read32 = (at) => ((bytes[at] | (bytes[at + 1] << 8) |
    (bytes[at + 2] << 16) | (bytes[at + 3] << 24)) >>> 0);
  let footer = -1;
  for (let pos = bytes.length - 22; pos >= Math.max(0, bytes.length - 65557); pos -= 1) {
    if (read32(pos) === 0x06054b50 && pos + 22 + read16(pos + 20) === bytes.length) {
      footer = pos;
      break;
    }
  }
  if (footer < 0 || read16(footer + 4) !== 0 || read16(footer + 6) !== 0) return false;
  const count = read16(footer + 10);
  const directorySize = read32(footer + 12);
  let cursor = read32(footer + 16);
  const directoryEnd = cursor + directorySize;
  if (!count || count > 5000 || directoryEnd > footer || cursor < 0) return false;
  const names = new Set();
  for (let index = 0; index < count; index += 1) {
    if (cursor + 46 > directoryEnd || read32(cursor) !== 0x02014b50) return false;
    if (read16(cursor + 8) & 1) return false; // Do not accept encrypted ZIP members.
    const nameLength = read16(cursor + 28);
    const extraLength = read16(cursor + 30);
    const commentLength = read16(cursor + 32);
    if (!nameLength || cursor + 46 + nameLength + extraLength + commentLength > directoryEnd) return false;
    let name = "";
    for (let n = cursor + 46; n < cursor + 46 + nameLength; n += 1) {
      name += String.fromCharCode(bytes[n]);
    }
    names.add(name);
    cursor += 46 + nameLength + extraLength + commentLength;
  }
  if (cursor !== directoryEnd || !names.has("[Content_Types].xml") || !names.has("_rels/.rels")) return false;
  if (names.has("word/vbaProject.bin") || names.has("xl/vbaProject.bin")) return false;
  return extension === ".docx" ? names.has("word/document.xml") : names.has("xl/workbook.xml");
}

function detectChatDocumentMime(bytes, extension) {
  if (extension === ".pdf") {
    // PDF files may begin with a short transport prefix; require PDF start and EOF.
    let start = -1;
    for (let i = 0; i <= Math.min(bytes.length - 5, 1024); i += 1) {
      if (bytes[i] === 0x25 && bytes[i+1] === 0x50 && bytes[i+2] === 0x44 &&
          bytes[i+3] === 0x46 && bytes[i+4] === 0x2d) { start = i; break; }
    }
    if (start < 0) return "";
    for (let i = bytes.length - 5; i >= Math.max(start, bytes.length - 2048); i -= 1) {
      if (bytes[i] === 0x25 && bytes[i+1] === 0x25 && bytes[i+2] === 0x45 &&
          bytes[i+3] === 0x4f && bytes[i+4] === 0x46) return "application/pdf";
    }
    return "";
  }
  if ((extension === ".doc" || extension === ".xls") && bytes.length >= 8 &&
      [0xd0, 0xcf, 0x11, 0xe0, 0xa1, 0xb1, 0x1a, 0xe1].every((byte, i) => bytes[i] === byte)) {
    return extension === ".doc" ? "application/msword" : "application/vnd.ms-excel";
  }
  if (isChatOfficeOpenXmlZip(bytes, extension)) {
    return extension === ".docx"
      ? "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      : "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
  }
  return "";
}

// CSV has no binary file signature. Accept a real .csv filename only when
// its entire content is valid UTF-8 text (including UTF-8 BOM exported by Excel).
// Reject binary/NUL/control-byte payloads rather than trusting file.type.
function isValidChatCsvText(bytes) {
  try {
    decodeChatCsvBytes(bytes);
    return true;
  } catch {
    return false;
  }
}

function isChatDocumentMime(value) {
  const mime = cleanText(value).toLowerCase();
  return mime.startsWith("application/") || mime === "text/csv";
}

function detectSupportedAttachmentMime(bytes, file = {}) {
  if (!(bytes instanceof Uint8Array) || !bytes.length) return "";
  const extension = getFileExtension(file?.name);
  if (extension === ".csv") return isValidChatCsvText(bytes) ? "text/csv" : "";
  if (extension === ".heic" || extension === ".heif") {
    return hasChatHeicSignature(bytes) ? (extension === ".heif" ? "image/heif" : "image/heic") : "";
  }
  if (bytes.length < 4) return "";

  const declaredMime = cleanText(file?.type).toLowerCase();
  const documentMime = detectChatDocumentMime(bytes, extension);
  if (documentMime) return documentMime;
  // Never relabel a rejected document as a media upload just because it shares a magic header.
  if ([".pdf", ".doc", ".docx", ".xls", ".xlsx"].includes(extension)) return "";

  // JPEG: SOI + EOI marker. This rejects truncated/corrupt .jpg files.
  if (
    bytes.length >= 4 &&
    bytes[0] === 0xff &&
    bytes[1] === 0xd8 &&
    bytes[2] === 0xff &&
    hasJpegEndMarker(bytes)
  ) {
    return "image/jpeg";
  }

  // PNG: signature + IHDR + IEND.
  if (
    bytes.length >= 33 &&
    bytes[0] === 0x89 &&
    bytes[1] === 0x50 &&
    bytes[2] === 0x4e &&
    bytes[3] === 0x47 &&
    bytes[4] === 0x0d &&
    bytes[5] === 0x0a &&
    bytes[6] === 0x1a &&
    bytes[7] === 0x0a &&
    bytesToAscii(bytes, 12, 4) === "IHDR" &&
    bytesToAscii(bytes, bytes.length - 8, 4) === "IEND"
  ) {
    return "image/png";
  }

  // GIF87a / GIF89a + trailer.
  if (
    bytes.length >= 14 &&
    ["GIF87a", "GIF89a"].includes(bytesToAscii(bytes, 0, 6)) &&
    bytes[bytes.length - 1] === 0x3b
  ) {
    return "image/gif";
  }

  // WEBP = RIFF....WEBP + a valid VP8 family chunk.
  if (
    bytes.length >= 16 &&
    bytesToAscii(bytes, 0, 4) === "RIFF" &&
    bytesToAscii(bytes, 8, 4) === "WEBP" &&
    ["VP8 ", "VP8L", "VP8X"].includes(bytesToAscii(bytes, 12, 4))
  ) {
    return "image/webp";
  }

  // WAV = RIFF....WAVE.
  if (
    bytes.length >= 12 &&
    bytesToAscii(bytes, 0, 4) === "RIFF" &&
    bytesToAscii(bytes, 8, 4) === "WAVE"
  ) {
    return "audio/wav";
  }

  // OGG container. Keep the user's declared category when available.
  if (bytesToAscii(bytes, 0, 4) === "OggS") {
    return declaredMime.startsWith("video/") || extension === ".ogv"
      ? "video/ogg"
      : "audio/ogg";
  }

  // FLAC.
  if (bytesToAscii(bytes, 0, 4) === "fLaC") {
    return "audio/flac";
  }

  // MP3: ID3 tag or MPEG audio frame sync.
  if (
    bytesToAscii(bytes, 0, 3) === "ID3" ||
    (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0 && extension === ".mp3")
  ) {
    return "audio/mpeg";
  }

  // AAC ADTS.
  if (
    bytes.length >= 7 &&
    bytes[0] === 0xff &&
    (bytes[1] & 0xf6) === 0xf0 &&
    (declaredMime === "audio/aac" || extension === ".aac")
  ) {
    return "audio/aac";
  }

  // WEBM / Matroska EBML header.
  if (
    bytes.length >= 4 &&
    bytes[0] === 0x1a &&
    bytes[1] === 0x45 &&
    bytes[2] === 0xdf &&
    bytes[3] === 0xa3
  ) {
    return declaredMime.startsWith("audio/")
      ? "audio/webm"
      : "video/webm";
  }

  // ISO Base Media: MP4 / M4A / MOV / M4V.
  if (bytes.length >= 12 && bytesToAscii(bytes, 4, 4) === "ftyp") {
    if (declaredMime.startsWith("audio/") || extension === ".m4a") {
      return "audio/mp4";
    }
    if (extension === ".mov" || declaredMime === "video/quicktime") {
      return "video/quicktime";
    }
    if (extension === ".m4v" || declaredMime === "video/x-m4v") {
      return "video/x-m4v";
    }
    return "video/mp4";
  }

  return "";
}

async function validateAttachmentBeforeSelection(file) {
  if (!file || Number(file.size || 0) <= 0) return "";

  try {
    const buffer = await file.arrayBuffer();
    return detectSupportedAttachmentMime(new Uint8Array(buffer), file);
  } catch {
    return "";
  }
}

const CHAT_EMOJIS = [
  "😀", "😃", "😄", "😁", "😆", "😅", "😂", "🤣",
  "😊", "🙂", "🙃", "😉", "😍", "🥰", "😘", "😎",
  "🤩", "🥳", "😇", "🤗", "🤭", "🫡", "🤔", "😴",
  "😢", "😭", "😤", "😡", "🤯", "😱", "🥺", "😬",
  "👍", "👎", "👏", "🙌", "🙏", "💪", "👌", "✌️",
  "🤝", "👋", "❤️", "🧡", "💛", "💚", "💙", "💜",
  "🖤", "🤍", "💯", "🔥", "✨", "🎉", "🎊", "✅",
  "⭐", "💡", "📌", "🚀", "👀", "💬", "😊", "🤍",
];

const MESSAGE_REACTIONS = [
  "👍", "❤️", "😂", "😮", "😢", "😡",
  "😍", "🥰", "😆", "🤔", "🙏", "👏",
  "🎉", "🔥", "💯", "👎", "😎", "🤩",
];

function cleanText(value) {
  return String(value ?? "").trim();
}

function isMobileChatDevice() {
  if (typeof navigator === "undefined") return false;

  if (navigator.userAgentData?.mobile === true) return true;

  const userAgent = String(navigator.userAgent || "");
  if (/Android|iPhone|iPad|iPod|Mobile/i.test(userAgent)) return true;

  return /Macintosh/i.test(userAgent) && Number(navigator.maxTouchPoints || 0) > 1;
}

function getChatMemberDisplayName(member = {}) {
  return (
    cleanText(member?.chatNickname || member?.chat_nickname) ||
    cleanText(member?.preferredName || member?.preferred_name) ||
    cleanText(member?.displayName) ||
    (cleanText(member?.sibsId) ? `SIBS ID ${cleanText(member.sibsId)}` : "Employee")
  );
}

function getChatMemberFullName(member = {}) {
  return (
    cleanText(member?.displayName) ||
    (cleanText(member?.sibsId) ? `SIBS ID ${cleanText(member.sibsId)}` : "Employee")
  );
}

function getHelpdeskCategoryLabel(category) {
  return cleanText(category).toUpperCase() === "IT" ? "IT Support" : "TA/HR Concerns";
}

// Branding for personal Helpdesk request views only. Staff dashboards and
// regular private/group conversations retain their existing titles.
function getPersonalHelpdeskChatTitle(category) {
  return `SiBS - ${getHelpdeskCategoryLabel(category)}`;
}

// The database keeps globally unique codes (IT-1 / THR-1). The chat UI shows
// the employee-friendly case number within its own Helpdesk category.
function getHelpdeskCaseLabel(conversation = {}) {
  const caseCode = cleanText(conversation?.caseCode);
  if (!caseCode) return "New concern";
  const match = caseCode.match(/^(?:IT|THR)-(\d+)$/i);
  const caseNumber = match ? String(Number(match[1])) : caseCode;
  const status = cleanText(conversation?.caseStatus).toUpperCase();
  if (status === "REJECTED") return "Rejected request";
  const isResolved = status === "RESOLVED";
  return `Case ${isResolved ? "Closed" : "Opened"} #${caseNumber}`;
}

// Role labels come from HRIS-verified server data, including Super Admin
// (assigned_accounts.admin_access = 7). The verified role takes priority over
// the requester fallback; a Super Admin who opened a case is still Super Admin.
// Never infer a role from nicknames, message direction, or Kronos attendance.
function getHelpdeskSenderIdentifier(conversation = {}, senderSibsId) {
  if (!conversation?.isHelpdesk || !conversation?.showHelpdeskSenderIdentifiers) return "";
  const id = cleanText(senderSibsId);
  if (!id) return "";
  const verifiedRole = cleanText(conversation?.helpdeskSenderIdentifiers?.[id]);
  if (verifiedRole) return verifiedRole;
  if (id === cleanText(conversation.createdBySibsId || conversation.requester?.sibsId)) {
    return "Employee";
  }
  return "";
}

function getReplySenderName(message = {}, currentSibsId = "") {
  if (!message || message?.unavailable) return "Original message";

  const senderSibsId = cleanText(message?.senderSibsId);
  if (senderSibsId && senderSibsId === cleanText(currentSibsId)) return "You";

  return getChatMemberDisplayName(message?.sender || { sibsId: senderSibsId });
}

function getReplyPreviewLabel(message = {}) {
  if (!message || message?.unavailable) return "Original message is unavailable";
  if (message?.unsent || cleanText(message?.messageType).toUpperCase() === "UNSENT") {
    return "Message was unsent";
  }

  const text = cleanText(message?.messageText);
  if (text) {
    return text.length > 100 ? `${text.slice(0, 100)}…` : text;
  }

  const type = cleanText(message?.messageType).toUpperCase();
  if (type === "GIF" || cleanText(message?.gifUrl)) return "GIF";

  const attachments = Array.isArray(message?.attachments) ? message.attachments : [];
  if (attachments.length) {
    const mimeTypes = attachments.map((item) => cleanText(item?.mimeType).toLowerCase());
    const hasVideo = mimeTypes.some((value) => value.startsWith("video/"));
    const hasAudio = mimeTypes.some((value) => value.startsWith("audio/"));
    const hasImage = mimeTypes.some((value) => value.startsWith("image/"));
    const hasDocument = mimeTypes.some(isChatDocumentMime);
    const kinds = [hasVideo, hasAudio, hasImage, hasDocument].filter(Boolean).length;

    if (kinds > 1 || attachments.length > 1) return "Attachments";
    if (hasDocument) return "Document";
    if (hasVideo) return "Video";
    if (hasAudio) return "Audio";
    if (hasImage) return "Image";
    return "Attachment";
  }

  if (type.includes("DOCUMENT")) return "Document";
  if (type.includes("VIDEO")) return "Video";
  if (type.includes("AUDIO")) return "Audio";
  if (type.includes("IMAGE") || type.includes("MEDIA")) return "Media attachment";

  return "Message";
}

function getChatMentionLabel(member = {}) {
  if (member?.mentionEveryone === true) return "everyone";

  return (
    cleanText(member?.preferredName || member?.preferred_name) ||
    cleanText(member?.firstName || member?.first_name || member?.gy_emp_fname) ||
    cleanText(member?.displayName) ||
    cleanText(member?.sibsId)
  );
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

// Build each conversation's mention matcher once per member-list identity,
// rather than rebuilding/sorting a large regular expression for each bubble.
// Group membership lists are immutable snapshots from ChatContext.
const chatMentionMatcherCache = new WeakMap();

function getChatMentionMatcher(members) {
  if (!Array.isArray(members) || !members.length) return null;
  const cached = chatMentionMatcherCache.get(members);
  if (cached) return cached;

  const mentionLabels = [...new Set(
    ["everyone", ...members.map((member) => getChatMentionLabel(member))].filter(Boolean),
  )].sort((first, second) => second.length - first.length);
  const matcher = mentionLabels.length
    ? {
        mentionLookup: new Set(mentionLabels.map((label) => `@${label}`.toLowerCase())),
        pattern: new RegExp(
          `(@(?:${mentionLabels.map(escapeRegExp).join("|")}))(?=$|\\s|[.,!?;:()\\[\\]{}])`,
          "gi",
        ),
      }
    : null;
  if (matcher) chatMentionMatcherCache.set(members, matcher);
  return matcher;
}

function renderChatMessageText(value, members = [], mine = false) {
  const text = String(value ?? "");
  if (!text) return null;

  const matcher = getChatMentionMatcher(members);
  if (!matcher) return text;
  const { mentionLookup, pattern } = matcher;
  const parts = text.split(pattern);

  return parts.map((part, index) => {
    if (!mentionLookup.has(part.toLowerCase())) {
      return <span key={`text-${index}`}>{part}</span>;
    }

    return (
      <span
        key={`mention-${index}`}
        className={
          mine
            ? "rounded bg-white/20 px-0.5 font-extrabold text-white underline decoration-white/50 underline-offset-2"
            : "rounded bg-sibs-cream-light px-1 font-extrabold text-sibs-orange border border-sibs-orange/20"
        }
      >
        {part}
      </span>
    );
  });
}

function getReactionPeopleLabel(reaction = {}) {
  const reactors = Array.isArray(reaction?.reactors) ? reaction.reactors : [];
  const names = reactors
    .map((reactor) =>
      reactor?.reactedByMe ? "You" : getChatMemberDisplayName(reactor),
    )
    .filter(Boolean);

  if (names.length) return names.join(", ");

  const count = Number(reaction?.count || 0);
  return `${count} ${count === 1 ? "person" : "people"}`;
}

function isEmojiOnlyMessage(value) {
  const text = cleanText(value);
  if (!text) return false;

  // Remove complete emoji sequences, then check whether anything except
  // whitespace remains. This supports common emoji, skin tones, ZWJ
  // combinations, flags, variation selectors, and keycap emoji.
  const remaining = text
    .replace(
      /[\p{Extended_Pictographic}\p{Emoji_Presentation}](?:\uFE0E|\uFE0F)?(?:\p{Emoji_Modifier})?(?:\u200D[\p{Extended_Pictographic}\p{Emoji_Presentation}](?:\uFE0E|\uFE0F)?(?:\p{Emoji_Modifier})?)*/gu,
      "",
    )
    .replace(/[\u{1F1E6}-\u{1F1FF}]{2}/gu, "")
    .replace(/[0-9#*]\uFE0F?\u20E3/gu, "")
    .replace(/[\uFE0E\uFE0F\u200D]/g, "")
    .replace(/\s+/g, "");

  return remaining.length === 0;
}

function getEmojiOnlySizeClass(value) {
  const text = cleanText(value);
  if (!text) return "text-[40px]";

  let emojiCount = Array.from(text).filter((value) => value.trim()).length;

  try {
    if (typeof Intl !== "undefined" && typeof Intl.Segmenter === "function") {
      const segmenter = new Intl.Segmenter("en", { granularity: "grapheme" });
      emojiCount = Array.from(segmenter.segment(text)).filter((part) =>
        cleanText(part.segment),
      ).length;
    }
  } catch {
    // Array.from fallback above is sufficient for display sizing.
  }

  if (emojiCount <= 1) return "text-[46px]";
  if (emojiCount <= 3) return "text-[40px]";
  return "text-[32px]";
}

function getMessageBubbleRadiusClass({ mine, groupStart, groupEnd }) {
  if (groupStart && groupEnd) return "rounded-[18px]";

  if (mine) {
    if (groupStart) return "rounded-[18px] rounded-br-md";
    if (groupEnd) return "rounded-[18px] rounded-tr-md";
    return "rounded-[18px] rounded-r-md";
  }

  if (groupStart) return "rounded-[18px] rounded-bl-md";
  if (groupEnd) return "rounded-[18px] rounded-tl-md";
  return "rounded-[18px] rounded-l-md";
}

function formatClock(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  return chatClockFormatter.format(date);
}

function isFreshChatTimestamp(value, nowMs = Date.now()) {
  if (!value) return false;

  const date = new Date(value);
  const timestamp = date.getTime();
  if (Number.isNaN(timestamp)) return false;

  const elapsedMs = Number(nowMs) - timestamp;

  // Allow a tiny clock-skew tolerance, but do not hide a real timezone mismatch.
  return elapsedMs >= -5000 && elapsedMs < 60_000;
}

function getManilaDateKey(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  const parts = chatDayKeyFormatter.formatToParts(date);

  const get = (type) => parts.find((part) => part.type === type)?.value || "";
  return `${get("year")}-${get("month")}-${get("day")}`;
}

// Helpdesk sidebar = today's PH-day cases, plus unresolved cases that still
// need action. An overnight case (opened 11:59 PM, closed 12:10 AM) appears
// on both dates because the CLOSED timestamp belongs to the next day.
// Do not filter private/group conversations or delete any archived case data.
function isHelpdeskConversationVisibleOnDay(conversation = {}, todayKey) {
  if (!conversation?.isHelpdesk && cleanText(conversation?.conversationType).toUpperCase() !== "HELPDESK") {
    return true;
  }

  const status = cleanText(conversation?.caseStatus).toUpperCase();
  // Drafts are personal unsent requests, not opened cases. The backend may
  // reuse a draft from a previous Philippine day when the user contacts the
  // same team again. Keep it in the sidebar until the first message is sent,
  // regardless of its original createdAt timestamp.
  const isUnsentDraft = status === "DRAFT" || (
    !status &&
    !conversation?.caseCode &&
    !conversation?.caseOpenedAt &&
    !Number(conversation?.lastMessageId || 0)
  );
  if (isUnsentDraft) return true;
  // Do not lose an actionable case just because the calendar rolled over.
  if (status && !["RESOLVED", "CLOSED", "REJECTED"].includes(status)) return true;

  const activityDates = [
    conversation.caseOpenedAt,
    conversation.caseAcceptedAt,
    conversation.caseUpdatedAt,
    conversation.caseResolvedAt,
    conversation.caseRejectedAt,
    conversation.lastMessageAt,
    // A newly created draft has no first-message/case timestamps yet.
    ...(status === "DRAFT" || !status ? [conversation.createdAt] : []),
  ];
  return activityDates.some((date) => date && getManilaDateKey(date) === todayKey);
}

function formatMessageTime(value, nowMs = Date.now()) {
  if (isFreshChatTimestamp(value, nowMs)) return "Now";

  const clock = formatClock(value);
  if (!clock) return "";

  const date = new Date(value);
  const timestamp = date.getTime();
  if (Number.isNaN(timestamp)) return clock;

  const elapsedMs = Math.max(0, Number(nowMs) - timestamp);
  const minutesAgo = Math.max(1, Math.floor(elapsedMs / 60_000));

  if (minutesAgo < 60) {
    return `${clock} · ${minutesAgo}m ago`;
  }

  const hoursAgo = Math.floor(elapsedMs / 3_600_000);
  if (hoursAgo < 24) {
    return `${clock} · ${hoursAgo}h ago`;
  }

  const daysAgo = Math.floor(elapsedMs / 86_400_000);
  return `${clock} · ${daysAgo}d ago`;
}

function formatChatLastSeen(value, nowMs = Date.now()) {
  if (!value) return "";

  const date = new Date(value);
  const timestamp = date.getTime();
  if (Number.isNaN(timestamp)) return "";

  const elapsedMs = Math.max(0, Number(nowMs) - timestamp);
  const minutesAgo = Math.max(1, Math.floor(elapsedMs / 60_000));

  if (minutesAgo < 60) {
    return `${minutesAgo}m ago`;
  }

  const hoursAgo = Math.floor(elapsedMs / 3_600_000);
  if (hoursAgo < 24) {
    return `${hoursAgo}h ago`;
  }

  const daysAgo = Math.floor(elapsedMs / 86_400_000);
  return `${daysAgo}d ago`;
}

function formatConversationTime(value, nowMs = Date.now()) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  if (isFreshChatTimestamp(value, nowMs)) return "Now";

  const sameDate = getManilaDateKey(date) === getManilaDateKey(new Date(nowMs));

  if (sameDate) return formatClock(value);

  return chatConversationDateFormatter.format(date);
}

function formatConversationFullDate(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return chatFullTooltipDateTimeFormatter.format(date);
}

// The case starts at its first chat message, shown in Philippine time.
// Use a relative date only for the current Manila calendar day; older cases
// retain an absolute date so "Today" never mislabels a previous-day case.
function formatHelpdeskCaseOpenedAt(value, nowMs = Date.now()) {
  if (!value) return "";
  const timestamp = new Date(value);
  if (Number.isNaN(timestamp.getTime())) return "";

  const clock = formatClock(value);
  if (getManilaDateKey(timestamp) === getManilaDateKey(new Date(nowMs))) {
    return `Today at ${clock}`;
  }

  return `${chatCaseDateFormatter.format(timestamp)} at ${clock}`;
}

function formatMessageDay(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";

  return chatMessageDayFormatter.format(date);
}

function getConversationCategoryBadge(conversation = {}) {
  const type = cleanText(conversation?.conversationType).toUpperCase();
  if (conversation?.isHelpdesk || type === "HELPDESK") {
    const cat = cleanText(conversation?.helpdeskCategory).toUpperCase();
    return {
      label: cat === "IT" ? "IT Support" : "TA/HR",
      color: "text-amber-800 bg-amber-50 border-amber-200/90",
    };
  }
  if (conversation?.isGroup || type === "GROUP") {
    return {
      label: "Group",
      color: "text-blue-800 bg-blue-50 border-blue-200/90",
    };
  }
  return {
    label: "Direct",
    color: "text-slate-700 bg-slate-100 border-slate-200/90",
  };
}

function getUserSibsId(user = {}) {
  return cleanText(
    user?.sibsId ||
      user?.sibs_id ||
      user?.username ||
      user?.gy_emp_code ||
      user?.employeeId ||
      user?.employee_id,
  );
}

function isSameDay(firstValue, secondValue) {
  if (!firstValue || !secondValue) return false;
  const first = new Date(firstValue);
  const second = new Date(secondValue);

  return (
    first.getFullYear() === second.getFullYear() &&
    first.getMonth() === second.getMonth() &&
    first.getDate() === second.getDate()
  );
}

function formatMessengerCenterTimestamp(currentValue, previousValue) {
  if (!currentValue) return "";
  const date = new Date(currentValue);
  if (Number.isNaN(date.getTime())) return "";

  const clock = formatClock(currentValue);
  if (!clock) return "";

  // If there is a previous message on the same calendar day, this header was triggered by a >= 15m gap
  if (previousValue && isSameDay(previousValue, currentValue)) {
    return clock;
  }

  // Cross-day or first message: include date context
  const now = new Date();
  if (isSameDay(date, now)) {
    return `Today · ${clock}`;
  }

  const yesterday = new Date(now);
  yesterday.setDate(yesterday.getDate() - 1);
  if (isSameDay(date, yesterday)) {
    return `Yesterday · ${clock}`;
  }

  const elapsedDays = Math.floor((now.getTime() - date.getTime()) / 86_400_000);
  if (elapsedDays >= 0 && elapsedDays < 7) {
    const weekday = chatWeekdayFormatter.format(date);
    return `${weekday} · ${clock}`;
  }

  const sameYear = date.getFullYear() === now.getFullYear();
  const dateStr = (sameYear ? chatCenterDateFormatter : chatCenterDateWithYearFormatter).format(date);

  return `${dateStr} · ${clock}`;
}

function getChatProfilePictureUrl(employee = {}) {
  const directUrl = cleanText(
    employee?.profilePictureUrl || employee?.profile_picture_url,
  );

  if (directUrl) {
    return getChatAttachmentUrl(directUrl);
  }

  const filename = cleanText(
    employee?.profileFilename ||
      employee?.profile_filename ||
      employee?.profilePicture ||
      employee?.profile_picture,
  );

  if (!filename) return "";

  return getChatAttachmentUrl(
    `/api/employee-profile/file/${encodeURIComponent(filename)}`,
  );
}

function getChatAvatarPreviewPosition(element) {
  if (!element || typeof window === "undefined") return null;

  const rect = element.getBoundingClientRect();
  const previewHeight = 176;
  const gap = 12;
  const viewportPadding = 8;
  const availableAbove = rect.top - gap;
  const placeBelow = availableAbove < previewHeight;

  return {
    left: Math.max(
      viewportPadding + 88,
      Math.min(
        rect.left + rect.width / 2,
        window.innerWidth - viewportPadding - 88,
      ),
    ),
    top: placeBelow ? rect.bottom + gap : rect.top - gap,
    placeBelow,
  };
}

function ChatAvatar({
  employee = null,
  initials = "U",
  online = false,
  group = false,
  size = "md",
}) {
  const sizeClass = {
    xs: "h-[18px] w-[18px] text-[7px]",
    chat: "h-7 w-7 text-[10px]",
    sm: "h-9 w-9 text-[11px]",
    md: "h-11 w-11 text-xs",
    lg: "h-12 w-12 text-sm",
  }[size] || "h-11 w-11 text-xs";

  const onlineDotClass =
    size === "xs" || size === "chat"
      ? "h-2.5 w-2.5 border-[1.5px]"
      : "h-3 w-3 border-2";

  const avatarRef = useRef(null);
  const profilePictureUrl = group ? "" : getChatProfilePictureUrl(employee);
  const [failedImageUrl, setFailedImageUrl] = useState("");
  const [previewVisible, setPreviewVisible] = useState(false);
  const [previewPosition, setPreviewPosition] = useState(null);
  const canShowProfilePicture =
    Boolean(profilePictureUrl) && failedImageUrl !== profilePictureUrl;

  useEffect(() => {
    setFailedImageUrl("");
  }, [profilePictureUrl]);

  function showPreview() {
    if (group) return;
    setPreviewPosition(getChatAvatarPreviewPosition(avatarRef.current));
    setPreviewVisible(true);
  }

  function hidePreview() {
    setPreviewVisible(false);
  }

  useEffect(() => {
    if (!previewVisible || group) return undefined;

    const updatePreviewPosition = () => {
      setPreviewPosition(getChatAvatarPreviewPosition(avatarRef.current));
    };

    window.addEventListener("resize", updatePreviewPosition);
    window.addEventListener("scroll", updatePreviewPosition, true);

    return () => {
      window.removeEventListener("resize", updatePreviewPosition);
      window.removeEventListener("scroll", updatePreviewPosition, true);
    };
  }, [group, previewVisible]);

  const preview =
    !group &&
    previewVisible &&
    previewPosition &&
    typeof document !== "undefined"
      ? createPortal(
          <span
            className="pointer-events-none fixed z-[38] rounded-2xl border border-sibs-border bg-white p-2 shadow-2xl"
            style={{
              left: previewPosition.left,
              top: previewPosition.top,
              transform: previewPosition.placeBelow
                ? "translate(-50%, 0)"
                : "translate(-50%, -100%)",
            }}
            aria-hidden="true"
          >
            <span className="relative flex h-40 w-40 items-center justify-center overflow-hidden rounded-xl bg-sibs-navy text-[24px] font-extrabold text-white">
              <span>{cleanText(initials).slice(0, 2)}</span>
              {canShowProfilePicture ? (
                <img
                  src={profilePictureUrl}
                  alt=""
                  className="absolute inset-0 h-full w-full object-cover"
                  onError={() => setFailedImageUrl(profilePictureUrl)}
                />
              ) : null}
            </span>
          </span>,
          document.body,
        )
      : null;

  return (
    <>
      <span
        ref={avatarRef}
        className="relative inline-flex shrink-0"
        onMouseEnter={showPreview}
        onMouseLeave={hidePreview}
      >
        <span
          className={`relative inline-flex ${sizeClass} items-center justify-center overflow-hidden rounded-full bg-sibs-navy font-extrabold text-white shadow-sm`}
        >
          {group ? (
            <UsersRound size={18} />
          ) : (
            <>
              <span aria-hidden="true">{cleanText(initials).slice(0, 2)}</span>
              {canShowProfilePicture ? (
                <img
                  src={profilePictureUrl}
                  alt=""
                  loading="lazy"
                  className="absolute inset-0 h-full w-full object-cover"
                  onError={() => setFailedImageUrl(profilePictureUrl)}
                />
              ) : null}
            </>
          )}
        </span>
        {!group && online ? (
          <span
            className={`absolute bottom-0 right-0 rounded-full border-white bg-emerald-500 ${onlineDotClass}`}
          />
        ) : null}
      </span>
      {preview}
    </>
  );
}

function ChatFolderList({
  folders,
  expandedFolders,
  onFoldersChange,
  children,
  nested = false,
  onHelpdeskContact,
  canRequestHelpdesk,
  helpdeskStartingCategory = "",
  helpdeskScopePending = false,
}) {
  return (
    <Accordion
      multiple
      value={folders.filter(({ key }) => expandedFolders[key]).map(({ key }) => key)}
      onValueChange={(openKeys) => onFoldersChange(folders, openKeys)}
    >
      {folders.map((folder) => {
        const { key, label, conversations, unread, subfolders, Icon } = folder;
        return (
          <AccordionItem key={key} value={key} className="border-0!">
            {nested && (key === "it" || key === "taHr") ? (() => {
              const category = key === "it" ? "IT" : "TA_HR";
              const canContact = Boolean(canRequestHelpdesk?.(category));
              const contacting = helpdeskStartingCategory === category;
              const unavailableReason = helpdeskScopePending
                ? "Checking Helpdesk request access…"
                : "You cannot request support from your own Helpdesk team.";
              return (
                <div className="mb-1 flex items-center gap-0.5 rounded-lg pl-4 pr-1 hover:bg-sibs-surface">
                  <button
                    type="button"
                    onClick={() => onHelpdeskContact?.(category)}
                    disabled={!canContact || Boolean(helpdeskStartingCategory)}
                    title={canContact ? `Contact ${label}` : unavailableReason}
                    aria-label={`Contact ${label}`}
                    className="flex min-w-0 flex-1 items-center gap-2 py-2 text-left text-[11px] font-bold text-sibs-navy transition hover:text-sibs-orange disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <Icon size={14} className="shrink-0 text-sibs-orange" />
                    <span className="min-w-0 flex-1 truncate">{label}</span>
                  </button>
                  {canContact ? (
                    <button
                      type="button"
                      onClick={() => onHelpdeskContact?.(category)}
                      disabled={Boolean(helpdeskStartingCategory)}
                      title={`New ${label} request`}
                      aria-label={`New ${label} request`}
                      className="inline-flex h-8 w-7 shrink-0 items-center justify-center rounded-lg text-sibs-orange transition hover:bg-sibs-cream-light disabled:opacity-50"
                    >
                      {contacting ? <Loader2 size={13} className="animate-spin" /> : <Plus size={15} />}
                    </button>
                  ) : null}
                  <AccordionTrigger
                    className="h-8! w-7! shrink-0 justify-center! gap-0! p-0! hover:bg-white/70"
                    title={`${expandedFolders[key] ? "Hide" : "Show"} ${label} conversations`}
                    aria-label={`${expandedFolders[key] ? "Hide" : "Show"} ${label} conversations`}
                    indicator={<ChevronRight aria-hidden="true" className="size-3.5 shrink-0 text-sibs-muted transition-transform duration-200 group-aria-expanded/accordion-trigger:rotate-90 motion-reduce:transition-none" />}
                  />
                </div>
              );
            })() : (
              <AccordionTrigger
                className="mb-1 gap-2! rounded-lg! px-2.5 py-2.5! text-xs! font-extrabold! hover:bg-sibs-surface hover:no-underline focus-visible:outline-offset-[-2px]! focus-visible:outline-sibs-orange!"
                indicator={<ChevronRight aria-hidden="true" className="size-3.5 shrink-0 text-sibs-muted transition-transform duration-200 group-aria-expanded/accordion-trigger:rotate-90 motion-reduce:transition-none" />}
              >
                <Icon size={16} className="shrink-0 text-sibs-orange" />
                <span className="min-w-0 flex-1 truncate">{label}</span>
                {unread > 0 ? (
                  <span title={`${unread} unread messages`} className="inline-flex min-w-5 items-center justify-center rounded-full bg-sibs-orange px-1 py-0.5 text-[9px] font-bold text-white">
                    {unread > 99 ? "99+" : unread}
                  </span>
                ) : null}
                {key !== "helpdesk" ? (
                  <span className="rounded-md bg-sibs-surface px-1.5 py-0.5 text-[10px] font-bold text-sibs-muted">
                    {conversations.length}
                  </span>
                ) : null}
              </AccordionTrigger>
            )}
            <AccordionContent className="pb-0!" panelClassName="data-open:has-[[role=menu]]:overflow-visible">
              {subfolders ? (
                <ChatFolderList
                  folders={subfolders}
                  expandedFolders={expandedFolders}
                  onFoldersChange={onFoldersChange}
                  nested
                  onHelpdeskContact={onHelpdeskContact}
                  canRequestHelpdesk={canRequestHelpdesk}
                  helpdeskStartingCategory={helpdeskStartingCategory}
                  helpdeskScopePending={helpdeskScopePending}
                >
                  {children}
                </ChatFolderList>
              ) : conversations.map((conversation) => children(conversation, nested))}
            </AccordionContent>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
}

function EmptyChatState({
  onNewPrivateChat,
  onNewGroupChat,
  onContactHelpdesk,
  onNewChat,
}) {
  return (
    <div className="flex min-h-0 flex-1 items-center justify-center bg-sibs-canvas px-4 py-8 sm:px-8 text-center overflow-y-auto sibs-scrollbar">
      <div className="w-full max-w-2xl flex flex-col items-center">
        <span className="inline-flex h-16 w-16 items-center justify-center rounded-2xl border border-sibs-orange/20 bg-sibs-cream-light text-sibs-orange shadow-xs">
          <MessageCircleMore size={30} />
        </span>
        <h3 className="mt-4 font-heading text-xl sm:text-2xl font-extrabold text-sibs-navy tracking-tight">
          SiBS Chat Workspace
        </h3>
        <p className="mt-2 max-w-md text-xs sm:text-sm font-medium leading-relaxed text-sibs-muted">
          Connect directly with colleagues, collaborate in shift teams, or get real-time assistance from on-duty Helpdesk staff.
        </p>

        <div className="mt-6 grid w-full grid-cols-1 gap-3 sm:grid-cols-3 text-left">
          <button
            type="button"
            onClick={onNewPrivateChat || onNewChat}
            className="group relative flex flex-col justify-between rounded-2xl border border-sibs-border bg-white p-4 shadow-xs transition hover:border-sibs-navy/30 hover:shadow-md active:scale-[0.99] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sibs-orange"
          >
            <div>
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-slate-100 text-sibs-navy transition group-hover:bg-sibs-navy group-hover:text-white">
                <User size={19} />
              </div>
              <h4 className="mt-3 font-heading text-sm font-extrabold text-sibs-navy">
                Direct Message
              </h4>
              <p className="mt-1 text-[11px] font-medium leading-4 text-sibs-muted">
                1-on-1 private chat with any employee or supervisor.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1 text-[11px] font-bold text-sibs-orange group-hover:translate-x-0.5 transition-transform">
              <span>Start direct chat</span>
              <ArrowRight size={13} />
            </div>
          </button>

          <button
            type="button"
            onClick={onNewGroupChat || onNewChat}
            className="group relative flex flex-col justify-between rounded-2xl border border-sibs-border bg-white p-4 shadow-xs transition hover:border-sibs-navy/30 hover:shadow-md active:scale-[0.99] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sibs-orange"
          >
            <div>
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-700 transition group-hover:bg-emerald-700 group-hover:text-white">
                <UsersRound size={19} />
              </div>
              <h4 className="mt-3 font-heading text-sm font-extrabold text-sibs-navy">
                Team Group
              </h4>
              <p className="mt-1 text-[11px] font-medium leading-4 text-sibs-muted">
                Coordinate shifts, departments, and project handoffs.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1 text-[11px] font-bold text-sibs-orange group-hover:translate-x-0.5 transition-transform">
              <span>Create group</span>
              <ArrowRight size={13} />
            </div>
          </button>

          <button
            type="button"
            onClick={() => onContactHelpdesk?.("IT")}
            className="group relative flex flex-col justify-between rounded-2xl border border-sibs-border bg-white p-4 shadow-xs transition hover:border-sibs-navy/30 hover:shadow-md active:scale-[0.99] focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sibs-orange"
          >
            <div>
              <div className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-orange-50 text-sibs-orange transition group-hover:bg-sibs-orange group-hover:text-white">
                <MonitorCog size={19} />
              </div>
              <h4 className="mt-3 font-heading text-sm font-extrabold text-sibs-navy">
                IT & HR Helpdesk
              </h4>
              <p className="mt-1 text-[11px] font-medium leading-4 text-sibs-muted">
                Directly route support requests to on-duty staff.
              </p>
            </div>
            <div className="mt-4 flex items-center gap-1 text-[11px] font-bold text-sibs-orange group-hover:translate-x-0.5 transition-transform">
              <span>Request support</span>
              <ArrowRight size={13} />
            </div>
          </button>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-center gap-4 text-xs font-semibold text-sibs-muted">
          <span className="inline-flex items-center gap-1.5 text-sibs-muted">
            <Lock size={13} className="text-emerald-600" />
            <span>Employee-isolated session drafts</span>
          </span>
          <span className="h-1 w-1 rounded-full bg-slate-300" aria-hidden="true" />
          <span className="inline-flex items-center gap-1.5 text-sibs-muted">
            <CheckCircle2 size={13} className="text-sibs-navy" />
            <span>Live Kronos on-duty roster sync</span>
          </span>
        </div>
      </div>
    </div>
  );
}

function NewChatOverlay({
  open,
  initialMode = "private",
  onClose,
  onPrivateChat,
  onCreateGroup,
  busy,
}) {
  const [mode, setMode] = useState(initialMode);
  const [query, setQuery] = useState("");
  const [participants, setParticipants] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedIds, setSelectedIds] = useState([]);
  const [groupName, setGroupName] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    if (open) {
      setMode(initialMode);
    }
  }, [open, initialMode]);

  useEffect(() => {
    if (!open) return undefined;

    let active = true;
    const timer = window.setTimeout(async () => {
      setLoading(true);

      try {
        const result = await getChatParticipants(query, 0);
        if (active) {
          setParticipants(result);
          setError("");
        }
      } catch (requestError) {
        if (active) {
          setError(
            requestError?.response?.data?.message ||
              requestError?.message ||
              "Unable to search HRIS users.",
          );
        }
      } finally {
        if (active) setLoading(false);
      }
    }, 220);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [open, query, mode]);

  useEffect(() => {
    if (!open) {
      setMode("private");
      setQuery("");
      setSelectedIds([]);
      setGroupName("");
      setError("");
    }
  }, [open]);

  if (!open) return null;

  function toggleMember(sibsId) {
    setSelectedIds((current) =>
      current.includes(sibsId)
        ? current.filter((id) => id !== sibsId)
        : [...current, sibsId],
    );
  }

  async function handleCreateGroup() {
    if (!cleanText(groupName)) {
      setError("Enter a group name.");
      return;
    }

    if (!selectedIds.length) {
      setError("Select at least one employee for the group.");
      return;
    }

    try {
      setError("");
      await onCreateGroup({
        name: groupName,
        memberSibsIds: selectedIds,
      });
      onClose();
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to create the group chat.",
      );
    }
  }

  return (
    <div className="absolute inset-0 z-30 flex flex-col bg-white">
      <header className="flex items-center gap-3 border-b border-sibs-border bg-white px-4 py-3">
        <button
          type="button"
          onClick={onClose}
          className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-sibs-muted transition hover:bg-sibs-surface hover:text-sibs-navy"
        >
          <ArrowLeft size={18} />
        </button>
        <div className="min-w-0 flex-1">
          <h3 className="font-heading text-base font-extrabold text-sibs-navy">
            New Chat
          </h3>
          <p className="text-[11px] font-semibold text-sibs-muted">
            Private messages and group chats
          </p>
        </div>
      </header>

      <div className="border-b border-sibs-border px-4 py-3">
        <div className="grid grid-cols-2 rounded-xl bg-sibs-surface p-1">
          <button
            type="button"
            onClick={() => setMode("private")}
            className={`rounded-lg px-3 py-2 text-xs font-extrabold transition ${
              mode === "private"
                ? "bg-white text-sibs-navy shadow-sm"
                : "text-sibs-muted"
            }`}
          >
            Private Message
          </button>
          <button
            type="button"
            onClick={() => setMode("group")}
            className={`rounded-lg px-3 py-2 text-xs font-extrabold transition ${
              mode === "group"
                ? "bg-white text-sibs-navy shadow-sm"
                : "text-sibs-muted"
            }`}
          >
            Group Chat
          </button>
        </div>

        {mode === "group" ? (
          <input
            type="text"
            value={groupName}
            onChange={(event) => setGroupName(event.target.value)}
            maxLength={120}
            placeholder="Group name"
            className="mt-3 h-10 w-full rounded-xl border border-sibs-border bg-white px-3 text-sm font-semibold text-sibs-navy outline-none transition focus:border-sibs-orange focus:ring-2 focus:ring-sibs-orange/10"
          />
        ) : null}

        <label className="relative mt-3 block">
          <Search
            size={16}
            className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sibs-faint"
          />
          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search name, SIBS ID, or email..."
            className="h-10 w-full rounded-xl border border-sibs-border bg-sibs-surface pl-9 pr-3 text-sm font-semibold text-sibs-navy outline-none transition focus:border-sibs-orange focus:bg-white focus:ring-2 focus:ring-sibs-orange/10"
          />
        </label>
      </div>

      {error ? (
        <div className="mx-4 mt-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700">
          {error}
        </div>
      ) : null}

      <div className="sibs-scrollbar min-h-0 flex-1 overflow-y-auto px-2 py-2">
        {loading ? (
          <div className="flex h-full items-center justify-center text-sibs-muted">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : participants.length ? (
          participants.map((participant) => {
            const selected = selectedIds.includes(participant.sibsId);

            return (
              <button
                key={participant.sibsId}
                type="button"
                disabled={busy}
                onClick={() => {
                  if (mode === "group") {
                    toggleMember(participant.sibsId);
                    return;
                  }

                  void (async () => {
                    try {
                      setError("");
                      await onPrivateChat(participant.sibsId);
                      onClose();
                    } catch (requestError) {
                      setError(
                        requestError?.response?.data?.message ||
                          requestError?.message ||
                          "Unable to start the private chat.",
                      );
                    }
                  })();
                }}
                className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition hover:bg-sibs-surface disabled:opacity-50"
              >
                <ChatAvatar
                  employee={participant}
                  initials={participant.initials}
                  online={participant.online}
                  size="sm"
                />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-extrabold text-sibs-navy">
                    {participant.displayName}
                  </span>
                  <span className="block truncate text-[11px] font-semibold text-sibs-muted">
                    SIBS ID {participant.sibsId}
                    {participant.account ? ` · ${participant.account}` : ""}
                  </span>
                </span>

                {mode === "group" ? (
                  <span
                    className={`inline-flex h-6 w-6 items-center justify-center rounded-full border transition ${
                      selected
                        ? "border-sibs-orange bg-sibs-orange text-white"
                        : "border-sibs-border bg-white text-transparent"
                    }`}
                  >
                    <Check size={13} />
                  </span>
                ) : null}
              </button>
            );
          })
        ) : (
          <div className="flex h-full items-center justify-center px-8 text-center text-xs font-semibold text-sibs-muted">
            No HRIS users found.
          </div>
        )}
      </div>

      {mode === "group" ? (
        <footer className="border-t border-sibs-border bg-white px-4 py-3">
          <button
            type="button"
            onClick={handleCreateGroup}
            disabled={busy || !selectedIds.length || !cleanText(groupName)}
            className="inline-flex h-10 w-full items-center justify-center gap-2 rounded-xl bg-sibs-orange text-sm font-extrabold text-white transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-40"
          >
            {busy ? <Loader2 size={16} className="animate-spin" /> : <UsersRound size={16} />}
            Create Group ({selectedIds.length})
          </button>
        </footer>
      ) : null}
    </div>
  );
}

function GroupInfoOverlay({
  conversation,
  currentSibsId,
  presence,
  helpdeskDuty,
  helpdeskDutyLoading,
  helpdeskDutyError,
  open,
  onClose,
  onRename,
  onAddMembers,
  onRemoveMember,
  onLeave,
}) {
  const [name, setName] = useState("");
  const [addingMembers, setAddingMembers] = useState(false);
  const [query, setQuery] = useState("");
  const [participants, setParticipants] = useState([]);
  const [selectedIds, setSelectedIds] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  const members = useMemo(
    () => conversation?.members || [],
    [conversation?.members],
  );
  const isHelpdesk = Boolean(conversation?.isHelpdesk);
  // This is computed by the server from the current department/account roster.
  // All helpdesk members have MEMBER as their conversation role, so that alone
  // cannot distinguish support staff from the original requester.
  const isHelpdeskSupportMember = isHelpdesk && Boolean(conversation?.isHelpdeskSupportMember);
  const dutyStatusById = useMemo(() => new Map(
    (helpdeskDuty?.members || []).map((entry) => [cleanText(entry.sibsId), entry]),
  ), [helpdeskDuty]);
  const sortedMembers = useMemo(() => {
    if (!isHelpdesk) return members;
    const rank = {CLOCKED_IN: 0, CLOCKED_OUT: 1, NO_CLOCK_IN: 2, UNAVAILABLE: 3};
    return [...members].sort((a, b) => {
      const aState = dutyStatusById.get(cleanText(a.sibsId));
      const bState = dutyStatusById.get(cleanText(b.sibsId));
      const aRank = aState ? rank[aState.status] ?? 3 : 4;
      const bRank = bState ? rank[bState.status] ?? 3 : 4;
      return aRank - bRank || getChatMemberDisplayName(a).localeCompare(getChatMemberDisplayName(b));
    });
  }, [members, isHelpdesk, dutyStatusById]);
  const isAdmin = !isHelpdesk && cleanText(conversation?.currentUserRole).toUpperCase() === "ADMIN";
  const isCreator = !isHelpdesk &&
    cleanText(conversation?.createdBySibsId) === cleanText(currentSibsId);

  useEffect(() => {
    setName(conversation?.name || conversation?.title || "");
  }, [conversation?.id, conversation?.name, conversation?.title]);

  useEffect(() => {
    if (!open || !addingMembers) return undefined;

    let active = true;
    const timer = window.setTimeout(async () => {
      try {
        const result = await getChatParticipants(query, 0);
        const existing = new Set(members.map((member) => member.sibsId));
        if (active) {
          setParticipants(result.filter((participant) => !existing.has(participant.sibsId)));
        }
      } catch (requestError) {
        if (active) {
          setError(
            requestError?.response?.data?.message ||
              requestError?.message ||
              "Unable to search employees.",
          );
        }
      }
    }, 220);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [addingMembers, members, open, query]);

  if (!open || !conversation?.isGroup) return null;

  async function saveName() {
    if (!isAdmin || cleanText(name) === cleanText(conversation.name)) return;

    try {
      setBusy(true);
      setError("");
      await onRename(conversation.id, name);
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to rename the group.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function addSelectedMembers() {
    if (!isCreator || !selectedIds.length) return;

    try {
      setBusy(true);
      setError("");
      await onAddMembers(conversation.id, selectedIds);
      setSelectedIds([]);
      setQuery("");
      setAddingMembers(false);
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to add group members.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function removeMember(sibsId) {
    if (!isCreator) return;

    try {
      setBusy(true);
      setError("");
      await onRemoveMember(conversation.id, sibsId);
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to remove the group member.",
      );
    } finally {
      setBusy(false);
    }
  }

  async function leaveGroup() {
    if (isHelpdeskSupportMember) return;
    try {
      setBusy(true);
      setError("");
      await onLeave(conversation.id);
    } catch (requestError) {
      setError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to leave the group.",
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-white" data-sibs-chat-info-overlay>
      <header className="flex items-center gap-3 border-b border-sibs-border px-4 py-3">
        <button
          type="button"
          onClick={onClose}
          title="Back to conversation messages"
          aria-label="Back to conversation messages"
          className="inline-flex h-9 w-9 items-center justify-center rounded-xl text-sibs-muted transition hover:bg-sibs-surface hover:text-sibs-navy focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sibs-orange"
        >
          <ArrowLeft size={18} />
        </button>
        <div>
          <h3 className="font-heading text-base font-extrabold text-sibs-navy">
            {isHelpdesk ? "Helpdesk Info" : "Group Info"}
          </h3>
          <p className="text-[11px] font-semibold text-sibs-muted">
            {members.length} member{members.length === 1 ? "" : "s"}
          </p>
        </div>
      </header>

      <div className="sibs-scrollbar min-h-0 flex-1 overflow-y-auto px-4 py-4">
        {error ? (
          <div className="mb-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-xs font-semibold text-red-700">
            {error}
          </div>
        ) : null}

        <section className="rounded-2xl border border-sibs-border bg-sibs-surface p-4">
          <label className="text-[10px] font-extrabold uppercase tracking-[0.1em] text-sibs-faint">
            {isHelpdesk ? "Helpdesk Conversation" : "Group Name"}
          </label>
          <div className="mt-2 flex gap-2">
            <input
              type="text"
              value={name}
              onChange={(event) => setName(event.target.value)}
              disabled={!isAdmin || busy}
              maxLength={120}
              className="h-10 min-w-0 flex-1 rounded-xl border border-sibs-border bg-white px-3 text-sm font-bold text-sibs-navy outline-none disabled:bg-slate-100 disabled:text-sibs-muted"
            />
            {isAdmin ? (
              <button
                type="button"
                onClick={saveName}
                disabled={busy || !cleanText(name)}
                className="rounded-xl bg-sibs-navy px-4 text-xs font-extrabold text-white disabled:opacity-40"
              >
                Save
              </button>
            ) : null}
          </div>
        </section>

        {isHelpdesk ? (
          <div className="mt-4 rounded-2xl border border-sibs-border bg-white p-3">
            <p className="text-xs font-extrabold text-sibs-navy">Today's Helpdesk coverage</p>
            <p className="mt-0.5 text-[10px] font-semibold text-sibs-muted">Kronos attendance · Philippine time</p>
            {helpdeskDutyLoading && !helpdeskDuty ? (
              <p className="mt-3 text-xs font-semibold text-sibs-muted">Checking today's attendance…</p>
            ) : helpdeskDuty ? (
              <div className="mt-3 flex flex-wrap gap-2">
                <span className="rounded-lg bg-emerald-50 px-2.5 py-1.5 text-[11px] font-bold text-emerald-700">
                  {helpdeskDuty.clockedInCount} clocked in / no clock-out
                </span>
                <span className="rounded-lg bg-sky-50 px-2.5 py-1.5 text-[11px] font-bold text-sky-700">
                  {helpdeskDuty.presentCount} present today
                </span>
                <span className="rounded-lg bg-sibs-surface px-2.5 py-1.5 text-[11px] font-bold text-sibs-muted">
                  {helpdeskDuty.supportCount} support members
                </span>
              </div>
            ) : null}
            {helpdeskDutyError ? (
              <p className="mt-2 text-[11px] font-semibold text-amber-700">Attendance is temporarily unavailable. Chat continues working.</p>
            ) : null}
            {helpdeskDuty?.unavailableCount > 0 ? (
              <p className="mt-2 text-[10px] font-semibold text-amber-700">
                Attendance could not be verified for {helpdeskDuty.unavailableCount} member(s).
              </p>
            ) : null}
            <p className="mt-2 text-[10px] leading-relaxed text-sibs-muted">
              Clocked in / no clock-out reflects the latest recorded attendance, not guaranteed availability. Presence in chat is separate.
            </p>
          </div>
        ) : null}

        <section className="mt-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-extrabold text-sibs-navy">{isHelpdesk ? 'Support team & requester' : 'Members'}</p>
            {isCreator ? (
              <button
                type="button"
                onClick={() => setAddingMembers((current) => !current)}
                className="inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1.5 text-[11px] font-extrabold text-sibs-orange transition hover:bg-sibs-cream-light"
              >
                <UserPlus size={14} />
                Add Member
              </button>
            ) : null}
          </div>

          {addingMembers ? (
            <div className="mb-3 rounded-2xl border border-sibs-border bg-white p-3 shadow-sm">
              <label className="relative block">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-sibs-faint" />
                <input
                  type="search"
                  value={query}
                  onChange={(event) => setQuery(event.target.value)}
                  placeholder="Search employees..."
                  className="h-9 w-full rounded-xl border border-sibs-border bg-sibs-surface pl-9 pr-3 text-xs font-semibold outline-none focus:border-sibs-orange"
                />
              </label>

              <div className="mt-2 max-h-48 overflow-y-auto">
                {participants.map((participant) => {
                  const selected = selectedIds.includes(participant.sibsId);
                  return (
                    <button
                      key={participant.sibsId}
                      type="button"
                      onClick={() =>
                        setSelectedIds((current) =>
                          selected
                            ? current.filter((id) => id !== participant.sibsId)
                            : [...current, participant.sibsId],
                        )
                      }
                      className="flex w-full items-center gap-2 rounded-lg px-2 py-2 text-left hover:bg-sibs-surface"
                    >
                      <ChatAvatar
                        employee={participant}
                        initials={participant.initials}
                        online={participant.online}
                        size="sm"
                      />
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-xs font-extrabold text-sibs-navy">
                          {getChatMemberDisplayName(participant)}
                        </span>
                        <span className="block text-[10px] font-semibold text-sibs-muted">
                          SIBS ID {participant.sibsId}
                        </span>
                      </span>
                      <span className={`inline-flex h-5 w-5 items-center justify-center rounded-full border ${selected ? "border-sibs-orange bg-sibs-orange text-white" : "border-sibs-border text-transparent"}`}>
                        <Check size={11} />
                      </span>
                    </button>
                  );
                })}
              </div>

              <button
                type="button"
                onClick={addSelectedMembers}
                disabled={busy || !selectedIds.length}
                className="mt-2 h-9 w-full rounded-xl bg-sibs-orange text-xs font-extrabold text-white disabled:opacity-40"
              >
                Add Selected ({selectedIds.length})
              </button>
            </div>
          ) : null}

          <div className="space-y-1">
            {sortedMembers.map((member) => {
              const online = presence?.[member.sibsId] ?? member.online;
              const isCurrent = member.sibsId === currentSibsId;
              const duty = isHelpdesk ? dutyStatusById.get(cleanText(member.sibsId)) : null;
              const helpdeskRole = isHelpdesk ? cleanText(member.helpdeskRoleLabel) || 'Employee' : '';
              const roleBadgeClass = helpdeskRole === 'Super Admin'
                ? 'border-blue-200 bg-blue-50 text-sibs-navy'
                : helpdeskRole === 'Manager'
                  ? 'border-violet-200 bg-violet-50 text-violet-700'
                  : helpdeskRole === 'IT Support'
                    ? 'border-orange-200 bg-orange-50 text-orange-800'
                    : helpdeskRole === 'TA/HR Support'
                      ? 'border-teal-200 bg-teal-50 text-teal-800'
                      : 'border-slate-200 bg-slate-50 text-slate-700';
              const dutyLabel = duty?.status === 'CLOCKED_IN'
                ? 'Clocked in · No clock-out'
                : duty?.status === 'CLOCKED_OUT'
                  ? 'Present today · Clocked out'
                  : duty?.status === 'NO_CLOCK_IN'
                    ? 'No clock-in recorded today'
                    : duty?.status === 'UNAVAILABLE'
                      ? 'Attendance unavailable'
                      : '';

              return (
                <div
                  key={member.sibsId}
                  className="flex items-center gap-3 rounded-xl px-2 py-2.5 hover:bg-sibs-surface"
                >
                  <ChatAvatar
                    employee={member}
                    initials={member.initials}
                    online={online}
                    size="sm"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="flex min-w-0 items-center gap-2">
                      <p
                        className="min-w-0 truncate text-xs font-extrabold text-sibs-navy"
                        title={getChatMemberDisplayName(member)}
                      >
                        {getChatMemberDisplayName(member)}
                        {isCurrent ? " (You)" : ""}
                      </p>
                      {isHelpdesk ? (
                        <span className={`inline-flex shrink-0 items-center whitespace-nowrap rounded-md border px-2 py-0.5 text-[10px] font-extrabold leading-none ${roleBadgeClass}`}>
                          {helpdeskRole}
                        </span>
                      ) : null}
                    </div>
                    <p className="text-[10px] font-semibold text-sibs-muted">
                      SIBS ID {member.sibsId}
                      {member.memberRole === "ADMIN" ? " · Admin" : ""}
                    </p>
                    {isHelpdesk ? (
                      <p className="mt-1 inline-flex items-center gap-1 text-[10px] font-semibold text-sibs-muted">
                        <MapPin size={11} className="shrink-0" />
                        Assigned site: {member.assignedLocationLabel || "Not assigned"}
                      </p>
                    ) : null}
                    {isHelpdesk && duty ? (
                      <p className={`mt-1 text-[10px] font-extrabold ${
                        duty?.status === 'CLOCKED_IN' ? 'text-emerald-700'
                          : duty?.status === 'CLOCKED_OUT' ? 'text-sky-700'
                            : duty?.status === 'UNAVAILABLE' ? 'text-amber-700' : 'text-sibs-muted'
                      }`}>
                        {helpdeskDutyLoading && !helpdeskDuty ? 'Checking attendance…' : dutyLabel}
                      </p>
                    ) : null}
                  </div>

                  {isCreator && !isCurrent && member.memberRole !== "ADMIN" ? (
                    <button
                      type="button"
                      onClick={() => void removeMember(member.sibsId)}
                      disabled={busy}
                      title="Remove member"
                      className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-lg px-2.5 text-[10px] font-extrabold text-red-600 transition hover:bg-red-50 disabled:opacity-40"
                    >
                      <Trash2 size={13} />
                      Remove
                    </button>
                  ) : null}
                </div>
              );
            })}
          </div>
        </section>
      </div>

      <footer className="border-t border-sibs-border px-4 py-3">
        {isHelpdeskSupportMember ? (
          <p className="text-center text-[10px] font-semibold text-sibs-muted">
            You are assigned to this Helpdesk team. Support members stay in the team's conversations.
          </p>
        ) : (
          <>
            <button
              type="button"
              onClick={() => void leaveGroup()}
              disabled={busy}
              className="h-10 w-full rounded-xl border border-red-200 bg-red-50 text-xs font-extrabold text-red-700 transition hover:bg-red-100 disabled:opacity-50"
            >
              {isHelpdesk ? "Leave Helpdesk" : "Leave Group"}
            </button>
            {isHelpdesk ? (
              <p className="mt-2 text-center text-[10px] font-semibold text-sibs-muted">
                Leave this conversation without deleting its messages. You can reopen your request from Helpdesk.
              </p>
            ) : null}
          </>
        )}
      </footer>
    </div>
  );
}

function MembershipNoticeCard({ notice, onOpenGroup, onDismiss }) {
  if (!notice) return null;

  const added = cleanText(notice.action).toLowerCase() === "added";

  return (
    <div
      role="status"
      aria-live="polite"
      className="w-full rounded-2xl border border-sibs-border bg-white p-3 shadow-xl"
    >
      <div className="flex items-start gap-3">
        <span
          className={`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
            added
              ? "bg-emerald-50 text-emerald-600"
              : "bg-red-50 text-red-600"
          }`}
        >
          {added ? <UserPlus size={17} /> : <UsersRound size={17} />}
        </span>

        <div className="min-w-0 flex-1">
          <p className="text-xs font-extrabold text-sibs-navy">
            {added ? "Added to group" : "Removed from group"}
          </p>
          <p className="mt-0.5 break-words text-[11px] font-semibold leading-4 text-sibs-muted">
            {notice.message}
          </p>

          {added ? (
            <button
              type="button"
              onClick={onOpenGroup}
              className="mt-2 inline-flex h-8 items-center justify-center rounded-lg bg-sibs-orange px-3 text-[10px] font-extrabold text-white transition hover:brightness-95"
            >
              Open Group
            </button>
          ) : null}
        </div>

        <button
          type="button"
          onClick={onDismiss}
          aria-label="Dismiss group notification"
          className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-sibs-faint transition hover:bg-sibs-surface hover:text-sibs-navy"
        >
          <X size={15} />
        </button>
      </div>
    </div>
  );
}

// A chat refresh can update presence, typing, unread counts, or sidebar data
// without changing the messages. Keep the expensive timeline (attachments,
// reactions, avatars and receipts) out of those unrelated React updates.
//
// The callback deliberately is NOT part of the equality check: it is created
// by the parent on each render, but is only executed when a value that affects
// the message rows actually changes. Do not memoize the typing indicator here.
const MemoizedChatMessageRows = memo(
  function MemoizedChatMessageRows({ renderRows }) {
    return renderRows();
  },
  (previous, next) =>
    previous.messages === next.messages &&
    previous.currentSibsId === next.currentSibsId &&
    previous.conversationId === next.conversationId &&
    previous.caseFirstMessageId === next.caseFirstMessageId &&
    previous.caseCode === next.caseCode &&
    previous.isGroup === next.isGroup &&
    previous.showHelpdeskSenderIdentifiers === next.showHelpdeskSenderIdentifiers &&
    previous.helpdeskSenderIdentifierSignature === next.helpdeskSenderIdentifierSignature &&
    previous.membersBySibsId === next.membersBySibsId &&
    previous.seenMembersByMessageId === next.seenMembersByMessageId &&
    previous.chatClockMs === next.chatClockMs &&
    previous.messageActionId === next.messageActionId &&
    previous.reactionPickerMessageId === next.reactionPickerMessageId &&
    previous.reactingMessageId === next.reactingMessageId &&
    previous.unsendingMessageId === next.unsendingMessageId,
);

export default function SiBSChat({
  enabled = true,
  isOpen: controlledOpen,
  onOpenChange,
  hideTrigger = false,
}) {
  const location = useLocation();
  const { user, loading: userLoading } = useUser() || {};
  const chat = useChat();
  const refreshChatConversations = chat?.refreshConversations;
  const selectChatConversation = chat?.selectConversation;

  const [internalOpen, setInternalOpen] = useState(false);
  const isControlled = controlledOpen !== undefined;
  const open = isControlled ? controlledOpen : internalOpen;
  const [isExpanded, setIsExpanded] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [activeCategoryTab, setActiveCategoryTab] = useState("all");
  const [helpdeskSubfilter, setHelpdeskSubfilter] = useState("all");
  const [inboxViewMode, setInboxViewMode] = useState("list");
  const minimizedDockRef = useRef(null);
  const previousActiveConversationIdRef = useRef(null);
  const isInitialStateRestoredRef = useRef(false);
  const [expandedBounds, setExpandedBounds] = useState(null);
  const chatPanelRef = useRef(null);
  const layoutStartRef = useRef(null);
  const layoutAnimationRef = useRef(null);

  const setOpen = useCallback(
    (nextOpen) => {
      const resolvedOpen =
        typeof nextOpen === "function" ? nextOpen(open) : nextOpen;
      if (!isControlled) {
        setInternalOpen(resolvedOpen);
      }
      onOpenChange?.(resolvedOpen);
    },
    [isControlled, open, onOpenChange],
  );
  const [newChatOpen, setNewChatOpen] = useState(false);
  const [newChatInitialMode, setNewChatInitialMode] = useState("private");
  const [isNavigatingBack, setIsNavigatingBack] = useState(false);
  const navigateBackTimerRef = useRef(null);
  const [groupInfoOpen, setGroupInfoOpen] = useState(false);
  const [themeModalOpen, setThemeModalOpen] = useState(false);
  const [conversationSearch, setConversationSearch] = useState("");
  // Start with all folders closed. Once the chat is opened, reveal only the
  // folder containing the conversation currently displayed on the right.
  const [expandedChatFolders, setExpandedChatFolders] = useState({
    private: false,
    groups: false,
    helpdesk: true,
    it: false,
    taHr: false,
  });
  const updateChatFolders = useCallback((folders, openKeys) => {
    setExpandedChatFolders((previous) => {
      const next = { ...previous };
      for (const { key } of folders) next[key] = openKeys.includes(key);
      return next;
    });
  }, []);
  const chatSearchActive = Boolean(cleanText(conversationSearch));

  // Reveal matching folders when a search starts, but let employees freely
  // collapse/expand them afterward even while search remains active.
  useEffect(() => {
    if (!chatSearchActive) return;
    setExpandedChatFolders((previous) => {
      if (Object.values(previous).every(Boolean)) return previous;
      return { private: true, groups: true, helpdesk: true, it: true, taHr: true };
    });
  }, [chatSearchActive]);
  const [draft, setDraft] = useState("");
  const [selectedImages, setSelectedImages] = useState([]);
  const [draggingAttachments, setDraggingAttachments] = useState(false);
  const [attachmentsLoading, setAttachmentsLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [actionBusy, setActionBusy] = useState(false);
  const [helpdeskStartingCategory, setHelpdeskStartingCategory] = useState("");
  const [helpdeskStartError, setHelpdeskStartError] = useState("");
  const helpdeskRequestPendingRef = useRef(false);
  const [localError, setLocalError] = useState("");
  const [attachmentNotice, setAttachmentNotice] = useState("");
  const [documentPreview, setDocumentPreview] = useState(null);
  const closeDocumentPreview = useCallback(() => setDocumentPreview(null), []);
  const [emojiPickerOpen, setEmojiPickerOpen] = useState(false);
  const [gifPickerOpen, setGifPickerOpen] = useState(false);
  const [gifSearch, setGifSearch] = useState("");
  const [gifResults, setGifResults] = useState([]);
  const [gifLoading, setGifLoading] = useState(false);
  const [gifError, setGifError] = useState("");
  const [chatClockMs, setChatClockMs] = useState(() => Date.now());
  const [messageActionId, setMessageActionId] = useState(null);
  const [reactionPickerMessageId, setReactionPickerMessageId] = useState(null);
  const [reactingMessageId, setReactingMessageId] = useState(null);
  const [unsendingMessageId, setUnsendingMessageId] = useState(null);
  const [unsendConfirmMessage, setUnsendConfirmMessage] = useState(null);
  const [conversationActionId, setConversationActionId] = useState(null);
  const [conversationActionBusyId, setConversationActionBusyId] = useState(null);
  const [deleteConversationConfirm, setDeleteConversationConfirm] = useState(null);
  const [nicknameConversation, setNicknameConversation] = useState(null);
  const [nicknameDraft, setNicknameDraft] = useState("");
  const [nicknameSaving, setNicknameSaving] = useState(false);
  const [replyingToMessage, setReplyingToMessage] = useState(null);
  const [launcherPosition, setLauncherPosition] = useState(null);
  const [launcherDragging, setLauncherDragging] = useState(false);
  const [mentionStart, setMentionStart] = useState(null);
  const [mentionEnd, setMentionEnd] = useState(null);
  const [mentionQuery, setMentionQuery] = useState("");
  const [mentionActiveIndex, setMentionActiveIndex] = useState(0);

  const messageScrollRef = useRef(null);
  const messagesListContentRef = useRef(null);
  const messageEndRef = useRef(null);
  const isInitialConversationLoadRef = useRef(true);
  const isNearBottomRef = useRef(true);
  const prevLoadingOlderRef = useRef(false);
  const olderMessagesScrollHeightRef = useRef(0);
  const olderMessagesScrollTopRef = useRef(0);
  const fileInputRef = useRef(null);
  const textareaRef = useRef(null);
  const emojiPickerRef = useRef(null);
  const emojiButtonRef = useRef(null);
  const gifPickerRef = useRef(null);
  const gifButtonRef = useRef(null);
  const gifSearchInputRef = useRef(null);
  const selectedImagesRef = useRef([]);
  // Queue picker/drop/paste batches so two quick actions cannot exceed the
  // same 5-file limit or overwrite each other's selected attachments.
  const attachmentQueueRef = useRef(Promise.resolve());
  const attachmentJobsRef = useRef(0);
  const typingStopTimerRef = useRef(null);
  const typingLastSentAtRef = useRef(0);
  const typingConversationIdRef = useRef(null);
  const previousOpenRef = useRef(false);
  const launcherRef = useRef(null);
  const launcherDragRef = useRef({
    active: false,
    pointerId: null,
    startX: 0,
    startY: 0,
    startLeft: 0,
    startTop: 0,
    moved: false,
  });
  const suppressLauncherClickRef = useRef(false);

  const currentSibsId = getUserSibsId(user);
  const [requestableHelpdeskCategories, setRequestableHelpdeskCategories] = useState(null);
  const [helpdeskRequestScopeError, setHelpdeskRequestScopeError] = useState("");

  useEffect(() => {
    if (!open || !currentSibsId) {
      setRequestableHelpdeskCategories(null);
      setHelpdeskRequestScopeError("");
      return undefined;
    }
    const controller = new AbortController();
    setRequestableHelpdeskCategories(null);
    setHelpdeskRequestScopeError("");
    void getChatHelpdeskRequestableCategories({ signal: controller.signal })
      .then((categories) => {
        if (controller.signal.aborted) return;
        setRequestableHelpdeskCategories(categories);
      })
      .catch((error) => {
        if (controller.signal.aborted || error?.name === "AbortError" || error?.code === "ERR_CANCELED") return;
        setRequestableHelpdeskCategories([]); // Do not show forbidden request actions.
        setHelpdeskRequestScopeError(error?.response?.data?.message || error?.message || "Unable to check Helpdesk request permissions.");
      });
    return () => controller.abort();
  }, [open, currentSibsId]);
  const canRequestHelpdesk = useCallback((category) =>
    Array.isArray(requestableHelpdeskCategories) && requestableHelpdeskCategories.includes(category),
  [requestableHelpdeskCategories]);

  // Restore persisted state for the authenticated employee
  useEffect(() => {
    if (!currentSibsId) {
      isInitialStateRestoredRef.current = false;
      return;
    }
    if (isInitialStateRestoredRef.current) return;
    isInitialStateRestoredRef.current = true;

    cleanupOtherEmployeeChatStates(currentSibsId);
    const saved = loadSavedChatState(currentSibsId);
    if (!saved) return;

    if (typeof saved.isExpanded === "boolean") {
      setIsExpanded(saved.isExpanded);
    }
    if (typeof saved.isMinimized === "boolean") {
      setIsMinimized(saved.isMinimized);
    }
    if (saved.activeCategoryTab) {
      setActiveCategoryTab(saved.activeCategoryTab);
    }
    if (saved.inboxViewMode) {
      setInboxViewMode(saved.inboxViewMode);
    }
    if (saved.activeConversationId && !chat?.activeConversationId) {
      void chat?.selectConversation?.(saved.activeConversationId);
    }
  }, [currentSibsId, chat]);

  // Wipe client-side session state on logout
  useEffect(() => {
    const handleLogout = () => {
      clearChatState();
      setIsMinimized(false);
      setIsExpanded(false);
      setDraft("");
    };
    window.addEventListener("sibs:auth:logout", handleLogout);
    return () => window.removeEventListener("sibs:auth:logout", handleLogout);
  }, []);
  const visible =
    enabled &&
    !userLoading &&
    Boolean(user) &&
    Boolean(chat) &&
    chat?.chatAllowed === true;
  const conversationTheme = chat?.activeConversation?.theme;
  const [imageLuminanceIsDark, setImageLuminanceIsDark] = useState(null);

  useEffect(() => {
    if (conversationTheme?.type !== "IMAGE" || !conversationTheme?.imageUrl) {
      setImageLuminanceIsDark(null);
      return;
    }

    let isMounted = true;
    let objectUrl = null;

    async function analyzeWallpaperLuminance() {
      try {
        const timestamp = conversationTheme.updatedAt
          ? new Date(conversationTheme.updatedAt).getTime()
          : "";
        const separator = conversationTheme.imageUrl.includes("?") ? "&" : "?";
        const cacheBustedPath =
          timestamp && !conversationTheme.imageUrl.includes("t=") && !conversationTheme.imageUrl.includes("v=")
            ? `${conversationTheme.imageUrl}${separator}t=${timestamp}`
            : conversationTheme.imageUrl;

        const blob = await getChatThemeImageBlob(cacheBustedPath);
        if (!isMounted || !blob) return;

        objectUrl = URL.createObjectURL(blob);
        const img = new Image();

        img.onload = () => {
          if (!isMounted) return;
          try {
            const canvas = document.createElement("canvas");
            canvas.width = 32;
            canvas.height = 32;
            const ctx = canvas.getContext("2d", { willReadFrequently: true });
            if (!ctx) return;
            ctx.drawImage(img, 0, 0, 32, 32);
            const data = ctx.getImageData(0, 0, 32, 32).data;
            setImageLuminanceIsDark(calculatePixelLuminanceIsDark(data));
          } catch {
            setImageLuminanceIsDark(false);
          } finally {
            if (objectUrl) {
              URL.revokeObjectURL(objectUrl);
              objectUrl = null;
            }
          }
        };

        img.onerror = () => {
          if (isMounted) setImageLuminanceIsDark(false);
          if (objectUrl) {
            URL.revokeObjectURL(objectUrl);
            objectUrl = null;
          }
        };

        img.src = objectUrl;
      } catch {
        if (isMounted) setImageLuminanceIsDark(false);
      }
    }

    void analyzeWallpaperLuminance();

    return () => {
      isMounted = false;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [conversationTheme?.imageUrl, conversationTheme?.type, conversationTheme?.updatedAt]);

  const themeBackgroundStyle = useMemo(
    () => getChatThemeBackgroundStyle(conversationTheme),
    [conversationTheme],
  );

  const updateExpandedBounds = useCallback(() => {
    const pageHeaderCard = document.querySelector("main .sibs-page-header-in");
    const pageContentBounds =
      pageHeaderCard?.closest("main .mx-auto[class*='max-w-']") ||
      document.querySelector("main .mx-auto[class*='max-w-']");
    const contentBounds =
      pageContentBounds ||
      pageHeaderCard ||
      document.querySelector(".sibs-dashboard-header-inner") ||
      document.querySelector(".app-header-inner") ||
      document.querySelector("main");
    const headerBounds =
      pageHeaderCard ||
      document.querySelector(".sibs-dashboard-header") ||
      document.querySelector(".sibs-dashboard-header-skeleton") ||
      document.querySelector(".app-header");
    const contentRect = contentBounds?.getBoundingClientRect();
    const headerRect = headerBounds?.getBoundingClientRect();
    const workspace = contentRect
      ? { left: contentRect.left, width: contentRect.width }
      : { left: 0, width: window.innerWidth };

    setExpandedBounds(
      getExpandedChatBounds({
        workspace,
        top: pageContentBounds
          ? contentRect?.top ?? headerRect?.top ?? 0
          : pageHeaderCard
          ? headerRect?.top ?? 0
          : headerRect?.bottom ?? 0,
        viewportHeight: window.innerHeight,
        gutter: contentRect ? 0 : 16,
      }),
    );
  }, []);

  useEffect(() => {
    if (!isExpanded || !open) return undefined;

    const pageHeaderCard = document.querySelector("main .sibs-page-header-in");
    const pageContentBounds =
      pageHeaderCard?.closest("main .mx-auto[class*='max-w-']") ||
      document.querySelector("main .mx-auto[class*='max-w-']");
    const contentBounds =
      pageContentBounds ||
      pageHeaderCard ||
      document.querySelector(".sibs-dashboard-header-inner") ||
      document.querySelector(".app-header-inner") ||
      document.querySelector("main");
    const headerBounds =
      pageHeaderCard ||
      document.querySelector(".sibs-dashboard-header") ||
      document.querySelector(".sibs-dashboard-header-skeleton") ||
      document.querySelector(".app-header");
    updateExpandedBounds();
    window.addEventListener("resize", updateExpandedBounds);

    const resizeObserver =
      typeof ResizeObserver !== "undefined"
        ? new ResizeObserver(updateExpandedBounds)
        : null;
    if (contentBounds) resizeObserver?.observe(contentBounds);
    if (headerBounds && headerBounds !== contentBounds) {
      resizeObserver?.observe(headerBounds);
    }

    return () => {
      window.removeEventListener("resize", updateExpandedBounds);
      resizeObserver?.disconnect();
    };
  }, [isExpanded, location.pathname, open, updateExpandedBounds]);

  useEffect(() => {
    if (!open) {
      setIsExpanded(false);
      setIsMinimized(false);
      setExpandedBounds(null);
      setIsNavigatingBack(false);
      explicitlyViewingListRef.current = true;
      setNewChatOpen(false);
      setGroupInfoOpen(false);
      if (navigateBackTimerRef.current) {
        clearTimeout(navigateBackTimerRef.current);
        navigateBackTimerRef.current = null;
      }
    }
  }, [open]);

  useEffect(() => {
    return () => {
      if (navigateBackTimerRef.current) {
        clearTimeout(navigateBackTimerRef.current);
      }
    };
  }, []);

  useLayoutEffect(() => {
    const panel = chatPanelRef.current;
    const from = layoutStartRef.current;
    if (!panel || !from) return;

    layoutStartRef.current = null;
    const to = panel.getBoundingClientRect();
    if (
      window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches ||
      typeof panel.animate !== "function"
    ) {
      return;
    }

    const { translateX, translateY, scaleX, scaleY } = getChatLayoutFlip(from, to);
    const styles = window.getComputedStyle(panel);
    const duration = Number.parseFloat(styles.getPropertyValue("--resize-dur")) || 300;
    const easing =
      styles.getPropertyValue("--resize-ease").trim() ||
      "cubic-bezier(0.22, 1, 0.36, 1)";

    layoutAnimationRef.current = panel.animate(
      [
        {
          transformOrigin: "top left",
          transform: `translate(${translateX}px, ${translateY}px) scale(${scaleX}, ${scaleY})`,
        },
        {
          transformOrigin: "top left",
          transform: "translate(0px, 0px) scale(1, 1)",
        },
      ],
      { duration, easing },
    );
    layoutAnimationRef.current.onfinish = () => {
      layoutAnimationRef.current = null;
    };
  }, [expandedBounds, isExpanded]);

  const toggleExpanded = useCallback(() => {
    // Mobile Chat is always full screen; expansion is only for desktop.
    if (window.matchMedia?.("(max-width: 639px)")?.matches) return;
    const panel = chatPanelRef.current;
    layoutStartRef.current = panel?.getBoundingClientRect() ?? null;
    layoutAnimationRef.current?.cancel();
    layoutAnimationRef.current = null;

    if (isExpanded) {
      setIsExpanded(false);
      setExpandedBounds(null);
      if (currentSibsId) {
        saveChatState(currentSibsId, { isExpanded: false });
      }
      return;
    }

    updateExpandedBounds();
    setIsExpanded(true);
    if (currentSibsId) {
      saveChatState(currentSibsId, { isExpanded: true });
    }
  }, [currentSibsId, isExpanded, updateExpandedBounds]);

  const handleMinimize = useCallback(() => {
    setIsMinimized(true);
    if (currentSibsId) {
      saveChatState(currentSibsId, {
        isMinimized: true,
        isExpanded,
        activeConversationId: chat?.activeConversationId || null,
        activeCategoryTab,
      });
    }
  }, [currentSibsId, isExpanded, chat?.activeConversationId, activeCategoryTab]);

  const handleRestoreFromMinimized = useCallback(() => {
    setIsMinimized(false);
    if (!open) {
      setOpen(true);
    }
    if (currentSibsId) {
      saveChatState(currentSibsId, { isMinimized: false, isOpen: true });
    }
    window.requestAnimationFrame(() => {
      chatPanelRef.current?.focus?.();
    });
  }, [currentSibsId, open, setOpen]);

  const handleClose = useCallback(() => {
    setOpen(false);
    setIsMinimized(false);
    if (currentSibsId) {
      saveChatState(currentSibsId, { isOpen: false, isMinimized: false });
    }
    window.requestAnimationFrame(() => {
      const launcherBtn =
        document.querySelector('[data-sibs-assistant-trigger="true"]') ||
        launcherRef.current;
      launcherBtn?.focus?.();
    });
  }, [currentSibsId, setOpen]);

  useEffect(() => {
    setReplyingToMessage(null);
  }, [chat?.activeConversationId]);

  useEffect(() => {
    if (!launcherPosition) return undefined;

    function keepLauncherInsideViewport() {
      const element = launcherRef.current;
      if (!element) return;

      const margin = 8;
      const maxLeft = Math.max(margin, window.innerWidth - element.offsetWidth - margin);
      const maxTop = Math.max(margin, window.innerHeight - element.offsetHeight - margin);

      setLauncherPosition((current) => {
        if (!current) return current;

        const left = Math.min(Math.max(margin, current.left), maxLeft);
        const top = Math.min(Math.max(margin, current.top), maxTop);

        if (left === current.left && top === current.top) return current;
        return { left, top };
      });
    }

    window.addEventListener("resize", keepLauncherInsideViewport);
    return () => window.removeEventListener("resize", keepLauncherInsideViewport);
  }, [launcherPosition]);

  useEffect(() => {
    chat?.setChatWindowOpen?.(open);

    if (typeof window !== "undefined") {
      window.__SIBS_CHAT_OPEN__ = Boolean(open);
      window.dispatchEvent(
        new CustomEvent("sibs-chat-open-change", {
          detail: { open: Boolean(open) },
        }),
      );
    }
  }, [chat?.setChatWindowOpen, open]);

  useEffect(() => {
    return () => {
      chat?.setChatWindowOpen?.(false);

      if (typeof window !== "undefined") {
        window.__SIBS_CHAT_OPEN__ = false;
        window.dispatchEvent(
          new CustomEvent("sibs-chat-open-change", {
            detail: { open: false },
          }),
        );
      }
    };
  }, [chat?.setChatWindowOpen]);

  useEffect(() => {
    if (typeof document === "undefined" || !isMobileChatDevice()) {
      return undefined;
    }

    const handleMobileVisibilityChange = () => {
      if (document.visibilityState === "visible") return;

      // Locking/sleeping the phone should end the current "viewed" session.
      // When the user wakes the phone, the unread badge stays until SiBS Chat
      // is deliberately opened again.
      setOpen(false);
      chat?.setChatWindowOpen?.(false);
    };

    document.addEventListener("visibilitychange", handleMobileVisibilityChange);

    return () => {
      document.removeEventListener(
        "visibilitychange",
        handleMobileVisibilityChange,
      );
    };
  }, [chat?.setChatWindowOpen]);

  useEffect(() => {
    if (typeof window === "undefined") return undefined;

    let cancelled = false;

    const openChatConversation = async (conversationId) => {
      const id = Number(conversationId || 0);
      if (!id || cancelled) return;

      setOpen(true);
      setNewChatOpen(false);
      setGroupInfoOpen(false);
      explicitlyViewingListRef.current = false;

      try {
        await refreshChatConversations?.();

        if (!cancelled) {
          await selectChatConversation?.(id);
        }
      } catch {
        // The user can still open SiBS Chat manually if navigation fails.
      }
    };

    const handleServiceWorkerMessage = (event) => {
      const payload = event?.data || {};

      if (payload?.type !== "SIBS_CHAT_OPEN_CONVERSATION") return;
      void openChatConversation(payload?.conversationId);
    };

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.addEventListener(
        "message",
        handleServiceWorkerMessage,
      );
    }

    const currentUrl = new URL(window.location.href);
    const shouldOpenFromNotification =
      currentUrl.searchParams.get("sibsChat") === "1";
    const notificationConversationId = Number(
      currentUrl.searchParams.get("conversationId") || 0,
    );

    if (shouldOpenFromNotification && notificationConversationId) {
      currentUrl.searchParams.delete("sibsChat");
      currentUrl.searchParams.delete("conversationId");

      window.history.replaceState(
        window.history.state,
        "",
        `${currentUrl.pathname}${currentUrl.search}${currentUrl.hash}`,
      );

      void openChatConversation(notificationConversationId);
    }

    return () => {
      cancelled = true;

      if ("serviceWorker" in navigator) {
        navigator.serviceWorker.removeEventListener(
          "message",
          handleServiceWorkerMessage,
        );
      }
    };
  }, [refreshChatConversations, selectChatConversation]);

  useEffect(() => {
    if (!open) return;

    // If permission was already granted, refresh/save the Push subscription
    // whenever SiBS Chat opens. The launcher click below remains the user
    // gesture that can request permission the first time.
    void ensureSibsChatSystemNotifications();
  }, [open]);

  useEffect(() => {
    if (
      typeof Notification !== "undefined" &&
      Notification.permission === "granted"
    ) {
      void ensureSibsChatSystemNotifications();
    }
  }, []);

  useEffect(() => {
    const justOpened = open && !previousOpenRef.current;
    previousOpenRef.current = open;

    if (!justOpened || !chat?.activeConversationId || explicitlyViewingListRef.current) return;

    // Re-load the visible conversation when the panel is opened. This is the
    // point where its unread messages become read. Messages received while
    // the panel is closed remain unread and keep the notification badge.
    void chat.selectConversation(chat.activeConversationId);
  }, [chat?.activeConversationId, chat?.selectConversation, open]);

  useEffect(() => {
    if (!open) return undefined;

    setChatClockMs(Date.now());

    // Timestamp labels have minute-level precision. A one-second clock was
    // repainting the entire conversation + all message bubbles 60 times per
    // minute even if there were no new messages. Update only on minute
    // boundaries. New incoming messages still repaint immediately through
    // ChatContext, independent of this display-only clock.
    let timerId;
    let stopped = false;
    const scheduleNextMinute = () => {
      const delay = 60_000 - (Date.now() % 60_000) + 20;
      timerId = window.setTimeout(() => {
        if (stopped) return;
        setChatClockMs(Date.now());
        scheduleNextMinute();
      }, delay);
    };
    scheduleNextMinute();

    return () => {
      stopped = true;
      window.clearTimeout(timerId);
    };
  }, [open]);

  useEffect(() => {
    if (!messageActionId) return undefined;

    function closeMessageActions(event) {
      if (event.key === "Escape") {
        setMessageActionId(null);
        return;
      }

      if (event.type === "pointerdown") {
        const element = event.target?.closest?.("[data-chat-message-actions]");
        if (!element) setMessageActionId(null);
      }
    }

    document.addEventListener("pointerdown", closeMessageActions);
    document.addEventListener("keydown", closeMessageActions);

    return () => {
      document.removeEventListener("pointerdown", closeMessageActions);
      document.removeEventListener("keydown", closeMessageActions);
    };
  }, [messageActionId]);

  useEffect(() => {
    if (!conversationActionId) return undefined;

    function closeConversationActions(event) {
      if (event.key === "Escape") {
        setConversationActionId(null);
        return;
      }

      if (event.type === "pointerdown") {
        const element = event.target?.closest?.("[data-chat-conversation-actions]");
        if (!element) setConversationActionId(null);
      }
    }

    document.addEventListener("pointerdown", closeConversationActions);
    document.addEventListener("keydown", closeConversationActions);

    return () => {
      document.removeEventListener("pointerdown", closeConversationActions);
      document.removeEventListener("keydown", closeConversationActions);
    };
  }, [conversationActionId]);

  useEffect(() => {
    if (!deleteConversationConfirm) return undefined;

    function handleDeleteConversationKeyDown(event) {
      if (event.key === "Escape" && !conversationActionBusyId) {
        setDeleteConversationConfirm(null);
      }
    }

    document.addEventListener("keydown", handleDeleteConversationKeyDown);
    return () => document.removeEventListener("keydown", handleDeleteConversationKeyDown);
  }, [conversationActionBusyId, deleteConversationConfirm]);

  useEffect(() => {
    if (!nicknameConversation) return undefined;

    function handleNicknameKeyDown(event) {
      if (event.key === "Escape" && !nicknameSaving) {
        setNicknameConversation(null);
        setNicknameDraft("");
      }
    }

    document.addEventListener("keydown", handleNicknameKeyDown);
    return () => document.removeEventListener("keydown", handleNicknameKeyDown);
  }, [nicknameConversation, nicknameSaving]);

  useEffect(() => {
    if (!reactionPickerMessageId) return undefined;

    function closeReactionPicker(event) {
      if (event.key === "Escape") {
        setReactionPickerMessageId(null);
        return;
      }

      if (event.type === "pointerdown") {
        const element = event.target?.closest?.("[data-chat-reaction-picker]");
        if (!element) setReactionPickerMessageId(null);
      }
    }

    document.addEventListener("pointerdown", closeReactionPicker);
    document.addEventListener("keydown", closeReactionPicker);

    return () => {
      document.removeEventListener("pointerdown", closeReactionPicker);
      document.removeEventListener("keydown", closeReactionPicker);
    };
  }, [reactionPickerMessageId]);

  useEffect(() => {
    if (!unsendConfirmMessage) return undefined;

    function handleUnsendModalKeyDown(event) {
      if (event.key === "Escape" && !unsendingMessageId) {
        setUnsendConfirmMessage(null);
      }
    }

    document.addEventListener("keydown", handleUnsendModalKeyDown);
    return () => document.removeEventListener("keydown", handleUnsendModalKeyDown);
  }, [unsendConfirmMessage, unsendingMessageId]);

  useEffect(() => {
    if (!emojiPickerOpen) return undefined;

    function handleEmojiPickerPointerDown(event) {
      const target = event.target;

      if (emojiPickerRef.current?.contains(target)) return;
      if (emojiButtonRef.current?.contains(target)) return;

      setEmojiPickerOpen(false);
    }

    function handleEmojiPickerKeyDown(event) {
      if (event.key === "Escape") {
        setEmojiPickerOpen(false);
        window.requestAnimationFrame(() => textareaRef.current?.focus());
      }
    }

    document.addEventListener("mousedown", handleEmojiPickerPointerDown);
    document.addEventListener("keydown", handleEmojiPickerKeyDown);

    return () => {
      document.removeEventListener("mousedown", handleEmojiPickerPointerDown);
      document.removeEventListener("keydown", handleEmojiPickerKeyDown);
    };
  }, [emojiPickerOpen]);

  useEffect(() => {
    if (!gifPickerOpen) return undefined;

    function handleGifPickerPointerDown(event) {
      const target = event.target;

      if (gifPickerRef.current?.contains(target)) return;
      if (gifButtonRef.current?.contains(target)) return;

      setGifPickerOpen(false);
    }

    function handleGifPickerKeyDown(event) {
      if (event.key === "Escape") {
        setGifPickerOpen(false);
        window.requestAnimationFrame(() => textareaRef.current?.focus());
      }
    }

    document.addEventListener("mousedown", handleGifPickerPointerDown);
    document.addEventListener("keydown", handleGifPickerKeyDown);

    return () => {
      document.removeEventListener("mousedown", handleGifPickerPointerDown);
      document.removeEventListener("keydown", handleGifPickerKeyDown);
    };
  }, [gifPickerOpen]);

  useEffect(() => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    textarea.style.height = "auto";
    const minH = isExpanded ? 40 : 36;
    const nextHeight = Math.min(Math.max(textarea.scrollHeight, minH), 112);
    textarea.style.height = `${nextHeight}px`;
    textarea.style.overflowY = textarea.scrollHeight > 112 ? "auto" : "hidden";
  }, [draft, isExpanded]);

  useEffect(() => {
    if (!gifPickerOpen) return undefined;

    const controller = new AbortController();
    const query = cleanText(gifSearch);

    const timer = window.setTimeout(async () => {
      try {
        setGifLoading(true);
        setGifError("");

        const results = query
          ? await searchChatGifs(query, { signal: controller.signal })
          : await getTrendingChatGifs({ signal: controller.signal });

        setGifResults(results);
      } catch (error) {
        if (error?.name === "AbortError") return;
        setGifResults([]);
        setGifError(error?.message || "Unable to load online GIFs.");
      } finally {
        if (!controller.signal.aborted) {
          setGifLoading(false);
        }
      }
    }, query ? 350 : 0);

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [gifPickerOpen, gifSearch]);

  useEffect(() => {
    if (open) return;
    setEmojiPickerOpen(false);
    setGifPickerOpen(false);
  }, [open]);

  const filteredConversations = useMemo(() => {
    const query = cleanText(conversationSearch).toLowerCase();
    const todayKey = getManilaDateKey(new Date(chatClockMs));

    return (chat?.conversations || []).filter((conversation) => {
      // Scope only the IT / TA-HR Helpdesk folders to today's activity.
      // A case worked across midnight is counted on both Philippine dates.
      if (!shouldShowHelpdeskInSibsChat(conversation, currentSibsId)) return false;
      if (conversation?.isHelpdesk || cleanText(conversation?.conversationType).toUpperCase() === "HELPDESK") {
        const category = cleanText(conversation?.helpdeskCategory).toUpperCase();
        if (!canRequestHelpdesk(category)) return false;
      }
      if (!isHelpdeskConversationVisibleOnDay(conversation, todayKey)) return false;
      if (!query) return true;

      const haystack = [
        conversation.title,
        conversation.name,
        conversation.requester?.displayName,
        conversation.requester?.sibsId,
        ...(conversation.members || []).flatMap((member) => [
          member.displayName,
          member.sibsId,
          member.email,
        ]),
      ]
        .join(" ")
        .toLowerCase();

      return haystack.includes(query);
    });
  }, [chat?.conversations, conversationSearch, chatClockMs, currentSibsId, canRequestHelpdesk]);

  const categoryConversations = useMemo(() => {
    const privateChats = [];
    const groupChats = [];
    const itChats = [];
    const taHrChats = [];

    for (const conversation of filteredConversations) {
      const type = cleanText(conversation?.conversationType).toUpperCase();
      if (conversation?.isHelpdesk || type === "HELPDESK") {
        const category = cleanText(conversation?.helpdeskCategory).toUpperCase();
        if (category === "IT") {
          itChats.push(conversation);
        } else {
          taHrChats.push(conversation);
        }
      } else if (conversation?.isGroup || type === "GROUP") {
        groupChats.push(conversation);
      } else {
        privateChats.push(conversation);
      }
    }

    return {
      all: filteredConversations,
      private: privateChats,
      groups: groupChats,
      helpdesk: [...itChats, ...taHrChats],
      it: itChats,
      taHr: taHrChats,
    };
  }, [filteredConversations]);

  const unreadCounts = useMemo(() => {
    const sum = (items) =>
      items.reduce(
        (total, c) => total + Math.max(0, Number(c?.unreadCount) || 0),
        0,
      );

    return {
      all: sum(categoryConversations.all),
      private: sum(categoryConversations.private),
      groups: sum(categoryConversations.groups),
      helpdesk: sum(categoryConversations.helpdesk),
      it: sum(categoryConversations.it),
      taHr: sum(categoryConversations.taHr),
    };
  }, [categoryConversations]);

  const activeDisplayConversations = useMemo(() => {
    if (activeCategoryTab === "private") {
      return categoryConversations.private;
    }
    if (activeCategoryTab === "groups") {
      return categoryConversations.groups;
    }
    if (activeCategoryTab === "helpdesk") {
      if (helpdeskSubfilter === "it") return categoryConversations.it;
      if (helpdeskSubfilter === "taHr") return categoryConversations.taHr;
      return categoryConversations.helpdesk;
    }
    return categoryConversations.all;
  }, [activeCategoryTab, categoryConversations, helpdeskSubfilter]);

  const chatSidebarFolders = useMemo(() => {
    const makeFolder = (key, label, Icon, conversations, subfolders) => ({
      key, label, Icon, conversations, subfolders,
      unread: conversations.reduce((total, conversation) =>
        total + Math.max(0, Number(conversation?.unreadCount) || 0), 0),
    });
    const isVisible = ({ conversations }) => !chatSearchActive || conversations.length > 0;
    const helpdeskSubfolders = [
      makeFolder("it", "IT Support", MonitorCog, categoryConversations.it),
      makeFolder("taHr", "TA/HR Concerns", HeartHandshake, categoryConversations.taHr),
    ].filter(isVisible);

    return [
      makeFolder("private", "Private Messages", MessageCircleMore, categoryConversations.private),
      makeFolder("groups", "Group Chats", UsersRound, categoryConversations.groups),
      makeFolder("helpdesk", "Helpdesk", Headset, categoryConversations.helpdesk, helpdeskSubfolders),
    ].filter(isVisible);
  }, [categoryConversations, chatSearchActive]);

  // A support-account thread must not bypass the Helpdesk dashboard by
  // remaining selected in the shared ChatContext from an earlier visit.
  const candidateActiveConversation = chat?.activeConversation;
  const activeConversation = shouldShowHelpdeskInSibsChat(candidateActiveConversation, currentSibsId) &&
    (!candidateActiveConversation?.isHelpdesk ||
      canRequestHelpdesk(cleanText(candidateActiveConversation?.helpdeskCategory).toUpperCase()))
    ? candidateActiveConversation || null : null;

  // Synchronize draft when active conversation changes
  useEffect(() => {
    const prevId = previousActiveConversationIdRef.current;
    const currentId = activeConversation?.id;

    if (prevId && prevId !== currentId && currentSibsId && cleanText(draft)) {
      saveConversationDraft(currentSibsId, prevId, draft);
    }

    if (currentId && currentSibsId) {
      const savedDraft = getConversationDraft(currentSibsId, currentId);
      setDraft(savedDraft);
    } else if (!currentId) {
      setDraft("");
    }

    previousActiveConversationIdRef.current = currentId || null;
  }, [activeConversation?.id, currentSibsId]);

  // The selected conversation can arrive before/after the refreshed list.
  // Compare IDs instead of depending on the entire conversation object so
  // two-second presence/unread updates never reopen or collapse folders.
  const selectedConversationId = Number(
    chat?.activeConversationId || activeConversation?.id || 0,
  );
  const selectedFolderConversation = (chat?.conversations || []).find(
    (conversation) => Number(conversation?.id) === selectedConversationId,
  ) || (Number(activeConversation?.id) === selectedConversationId ? activeConversation : null);
  const selectedFolderType = cleanText(selectedFolderConversation?.conversationType).toUpperCase();
  const selectedFolder = selectedFolderConversation?.isHelpdesk || selectedFolderType === "HELPDESK"
    ? cleanText(selectedFolderConversation.helpdeskCategory).toUpperCase() === "IT" ? "it" : "taHr"
    : selectedFolderConversation?.isGroup || selectedFolderType === "GROUP"
      ? "groups"
      : selectedFolderConversation ? "private" : "";

  useEffect(() => {
    // Preserve the current folder expansion when returning to the list.
    // Collapsing all sections makes the conversation list look empty.
    if (!open || chatSearchActive || !selectedConversationId) return;
    setExpandedChatFolders((previous) => {
      const next = {
        private: selectedFolder === "private",
        groups: selectedFolder === "groups",
        helpdesk: selectedFolder === "it" || selectedFolder === "taHr" || previous.helpdesk,
        it: selectedFolder === "it",
        taHr: selectedFolder === "taHr",
      };
      return Object.keys(next).every((key) => previous[key] === next[key])
        ? previous
        : next;
    });
  }, [open, chatSearchActive, selectedConversationId, selectedFolder]);

  // Keep the compact three-person duty preview independent from incoming chat
  // messages and two-minute Kronos refreshes. Reset only when the thread changes.
  const [dutyRosterExpanded, setDutyRosterExpanded] = useState(false);
  const activeHelpdeskId = open && activeConversation?.isHelpdesk
    ? Number(activeConversation.id || 0) : 0;
  // Ticket details are separate from the conversation; load the real assignee
  // before enabling status actions. A visible participant is not necessarily
  // authorized to resolve the case.
  const [helpdeskStatusTicket, setHelpdeskStatusTicket] = useState(null);
  const [helpdeskStatusLoading, setHelpdeskStatusLoading] = useState(false);
  const [helpdeskStatusMenuOpen, setHelpdeskStatusMenuOpen] = useState(false);
  const [helpdeskCloseConfirm, setHelpdeskCloseConfirm] = useState(false);
  const [helpdeskStatusSaving, setHelpdeskStatusSaving] = useState(false);
  const helpdeskStatusMenuRef = useRef(null);
  const helpdeskStatusSavingRef = useRef(false);
  const activeHelpdeskIdRef = useRef(activeHelpdeskId);
  activeHelpdeskIdRef.current = activeHelpdeskId;

  useEffect(() => {
    setHelpdeskStatusMenuOpen(false);
    setHelpdeskCloseConfirm(false);
    if (!activeHelpdeskId || !activeConversation?.caseCode) {
      setHelpdeskStatusTicket(null);
      setHelpdeskStatusLoading(false);
      return undefined;
    }

    let active = true;
    const controller = new AbortController();
    setHelpdeskStatusTicket(null);
    setHelpdeskStatusLoading(true);
    void getHelpdeskTicketDetails(activeHelpdeskId, { signal: controller.signal })
      .then((ticket) => {
        if (active) setHelpdeskStatusTicket(ticket ? { ...ticket, conversationId: activeHelpdeskId } : null);
      })
      .catch((error) => {
        if (active && error?.name !== 'CanceledError' && error?.name !== 'AbortError') {
          // Leave the current status readable; never enable editing without
          // fresh server-confirmed ownership.
          setHelpdeskStatusTicket(null);
        }
      })
      .finally(() => {
        if (active) setHelpdeskStatusLoading(false);
      });
    return () => { active = false; controller.abort(); };
  }, [activeHelpdeskId, activeConversation?.caseCode, activeConversation?.caseStatus]);

  useEffect(() => {
    if (!helpdeskStatusMenuOpen) return undefined;
    function closeMenu(event) {
      if (event.type === 'keydown' && event.key === 'Escape') {
        if (!helpdeskStatusSavingRef.current) {
          setHelpdeskStatusMenuOpen(false);
          setHelpdeskCloseConfirm(false);
        }
      } else if (event.type === 'pointerdown' &&
        !helpdeskStatusMenuRef.current?.contains(event.target) &&
        !helpdeskStatusSavingRef.current) {
        setHelpdeskStatusMenuOpen(false);
        setHelpdeskCloseConfirm(false);
      }
    }
    document.addEventListener('pointerdown', closeMenu);
    document.addEventListener('keydown', closeMenu);
    return () => {
      document.removeEventListener('pointerdown', closeMenu);
      document.removeEventListener('keydown', closeMenu);
    };
  }, [helpdeskStatusMenuOpen]);

  // The close confirmation is a modal: it does not close on backdrop clicks.
  // Escape dismisses it without changing the status (except during submission).
  useEffect(() => {
    if (!helpdeskCloseConfirm) return undefined;
    const handleCloseCaseEscape = (event) => {
      if (event.key === 'Escape' && !helpdeskStatusSavingRef.current) {
        event.stopPropagation();
        setHelpdeskCloseConfirm(false);
      }
    };
    document.addEventListener('keydown', handleCloseCaseEscape);
    return () => document.removeEventListener('keydown', handleCloseCaseEscape);
  }, [helpdeskCloseConfirm]);

  useEffect(() => {
    if (!open || isMinimized) return undefined;

    function handlePanelEscapeKey(event) {
      if (event.key !== "Escape") return;
      if (
        emojiPickerOpen ||
        gifPickerOpen ||
        helpdeskStatusMenuOpen ||
        conversationActionId ||
        messageActionId ||
        reactionPickerMessageId ||
        groupInfoOpen ||
        themeModalOpen ||
        newChatOpen ||
        nicknameConversation ||
        helpdeskCloseConfirm ||
        deleteConversationConfirm ||
        unsendConfirmMessage ||
        documentPreview
      ) {
        return;
      }
      if (
        document.activeElement &&
        (document.activeElement.tagName === "TEXTAREA" ||
          document.activeElement.tagName === "INPUT")
      ) {
        return;
      }
      handleMinimize();
    }

    window.addEventListener("keydown", handlePanelEscapeKey);
    return () => window.removeEventListener("keydown", handlePanelEscapeKey);
  }, [
    open,
    isMinimized,
    emojiPickerOpen,
    gifPickerOpen,
    helpdeskStatusMenuOpen,
    conversationActionId,
    messageActionId,
    reactionPickerMessageId,
    groupInfoOpen,
    themeModalOpen,
    newChatOpen,
    nicknameConversation,
    helpdeskCloseConfirm,
    deleteConversationConfirm,
    unsendConfirmMessage,
    documentPreview,
    handleMinimize,
  ]);

  const activeStatusTicket = helpdeskStatusTicket?.conversationId === activeHelpdeskId
    ? helpdeskStatusTicket : null;
  const helpdeskCaseStatus = cleanText(
    activeStatusTicket?.status || activeConversation?.caseStatus || 'OPEN',
  ).toUpperCase();
  const helpdeskCaseStatusLabel = {
    OPEN: 'Open', IN_PROGRESS: 'In Progress', PENDING: 'Pending',
    RESOLVED: 'Case Closed', REJECTED: 'Rejected',
  }[helpdeskCaseStatus] || 'Status';
  const canChangeHelpdeskStatus = Boolean(activeHelpdeskId && activeStatusTicket &&
    cleanText(activeStatusTicket.acceptedBySibsId) === currentSibsId &&
    ['IN_PROGRESS', 'PENDING'].includes(helpdeskCaseStatus) && !helpdeskStatusSaving);

  async function changeHelpdeskCaseStatus(nextStatus) {
    const targetId = activeHelpdeskId;
    if (!canChangeHelpdeskStatus || helpdeskStatusSavingRef.current ||
      !['IN_PROGRESS', 'PENDING', 'RESOLVED'].includes(nextStatus) ||
      nextStatus === helpdeskCaseStatus) return;
    helpdeskStatusSavingRef.current = true;
    setHelpdeskStatusSaving(true);
    setLocalError('');
    try {
      // This is the same endpoint used by Helpdesk Request Details. The
      // backend verifies department membership and accepted-by ownership,
      // writes the ticket history, and notifies all conversation members.
      const nextTicket = await updateHelpdeskTicketStatus(targetId, nextStatus);
      if (activeHelpdeskIdRef.current === targetId) {
        setHelpdeskStatusTicket(nextTicket ? { ...nextTicket, conversationId: targetId } : null);
        setHelpdeskStatusMenuOpen(false);
        setHelpdeskCloseConfirm(false);
      }
      await chat?.refreshConversations?.({ silent: true });
    } catch (error) {
      if (activeHelpdeskIdRef.current === targetId) {
        setLocalError(error?.response?.data?.message || error?.message ||
          'Unable to update case status. Please try again.');
        // Avoid displaying stale ownership or status after a rejected update.
        try {
          const ticket = await getHelpdeskTicketDetails(targetId);
          if (activeHelpdeskIdRef.current === targetId) {
            setHelpdeskStatusTicket(ticket ? { ...ticket, conversationId: targetId } : null);
          }
        } catch { /* The next conversation refresh will reconcile it. */ }
      }
    } finally {
      helpdeskStatusSavingRef.current = false;
      setHelpdeskStatusSaving(false);
    }
  }

  const [helpdeskDuty, setHelpdeskDuty] = useState(null);
  const [helpdeskDutyLoading, setHelpdeskDutyLoading] = useState(false);
  const [helpdeskDutyError, setHelpdeskDutyError] = useState(false);
  const [helpdeskDutyCheckedAt, setHelpdeskDutyCheckedAt] = useState(null);
  useEffect(() => {
    setDutyRosterExpanded(false);
  }, [activeHelpdeskId]);

  const isPersonalHelpdeskRequest = Boolean(activeConversation?.isHelpdesk &&
    cleanText(activeConversation.createdBySibsId) === currentSibsId);
  const visibleHelpdeskDuty = helpdeskDuty?.conversationId === activeHelpdeskId
    ? helpdeskDuty : null;

  // Attendance is displayed to both the requester and support team. It is
  // NEVER inferred from chat-online presence: only Kronos clock-in without a
  // clock-out qualifies as currently on duty. Refresh while this chat is open,
  // including after returning to the browser tab; a short server-side cache
  // protects Kronos from excessive traffic.
  useEffect(() => {
    if (!activeHelpdeskId) {
      setHelpdeskDuty(null);
      setHelpdeskDutyLoading(false);
      setHelpdeskDutyError(false);
      setHelpdeskDutyCheckedAt(null);
      return undefined;
    }
    let active = true;
    let inProgress = false;
    let controller = null;
    setHelpdeskDuty(null);
    setHelpdeskDutyCheckedAt(null);
    setHelpdeskDutyLoading(true);
    setHelpdeskDutyError(false);

    async function refreshAttendance() {
      if (!active || inProgress || document.visibilityState === 'hidden') return;
      inProgress = true;
      controller = new AbortController();
      try {
        const result = await getChatHelpdeskDuty(activeHelpdeskId, controller.signal);
        if (active) {
          setHelpdeskDuty(result);
          setHelpdeskDutyError(!result);
          if (result) setHelpdeskDutyCheckedAt(Date.now());
        }
      } catch (error) {
        if (active && error?.name !== 'CanceledError' && error?.name !== 'AbortError') {
          // Preserve the last known roster, but flag failed refreshes. Never
          // convert an API failure into 'no on-duty support'.
          setHelpdeskDutyError(true);
        }
      } finally {
        inProgress = false;
        if (active) setHelpdeskDutyLoading(false);
      }
    }

    function refreshWhenVisible() {
      if (document.visibilityState === 'visible') void refreshAttendance();
    }
    void refreshAttendance();
    const interval = window.setInterval(refreshWhenVisible, 30_000);
    document.addEventListener('visibilitychange', refreshWhenVisible);
    window.addEventListener('focus', refreshWhenVisible);
    return () => {
      active = false;
      window.clearInterval(interval);
      document.removeEventListener('visibilitychange', refreshWhenVisible);
      window.removeEventListener('focus', refreshWhenVisible);
      controller?.abort();
    };
  }, [activeHelpdeskId]);

  const onDutySupportMembers = useMemo(() => {
    if (!visibleHelpdeskDuty) return [];
    const chatMembersById = new Map((activeConversation?.members || [])
      .map((member) => [cleanText(member.sibsId), member]));
    // Use the attendance roster as the source of truth. Every clocked-in
    // support employee must appear, even if their chat profile is still loading.
    return (visibleHelpdeskDuty.members || [])
      .filter((member) => member.onDutyNow === true)
      .map((member) => {
        const sibsId = cleanText(member.sibsId);
        return {
          ...member,
          ...chatMembersById.get(sibsId),
          sibsId,
        };
      });
  }, [activeConversation?.members, visibleHelpdeskDuty]);

  const activeTypingMembers = useMemo(() => {
    const conversationId = Number(activeConversation?.id || 0);
    if (!conversationId) return [];

    const typingIds = Array.isArray(chat?.typingByConversation?.[conversationId])
      ? chat.typingByConversation[conversationId]
      : [];

    const members = Array.isArray(activeConversation?.members)
      ? activeConversation.members
      : [];

    return typingIds
      .map((sibsId) =>
        members.find(
          (member) => cleanText(member?.sibsId) === cleanText(sibsId),
        ),
      )
      .filter(Boolean)
      .filter((member) => cleanText(member?.sibsId) !== currentSibsId);
  }, [
    activeConversation,
    chat?.typingByConversation,
    currentSibsId,
  ]);

  const typingLabel = useMemo(() => {
    const names = activeTypingMembers
      .map((member) => getChatMemberDisplayName(member))
      .filter(Boolean);

    if (!names.length) return "";
    if (names.length === 1) return `${names[0]} is typing...`;
    if (names.length === 2) return `${names[0]} and ${names[1]} are typing...`;

    return `${names[0]}, ${names[1]}, and ${names.length - 2} other${
      names.length - 2 === 1 ? "" : "s"
    } are typing...`;
  }, [activeTypingMembers]);

  const mentionCandidates = useMemo(() => {
    if (!activeConversation?.isGroup || mentionStart === null) return [];

    const query = cleanText(mentionQuery).toLowerCase();
    const members = Array.isArray(activeConversation?.members)
      ? activeConversation.members
      : [];

    const everyoneCandidate = {
      mentionEveryone: true,
      sibsId: "__everyone__",
      displayName: "Everyone",
      initials: "ALL",
    };

    const candidates = [
      everyoneCandidate,
      ...members.filter((member) => cleanText(member?.sibsId) !== currentSibsId),
    ];

    return candidates
      .filter((member) => {
        if (!query) return true;

        const haystack = member?.mentionEveryone
          ? "everyone all group members"
          : [
              getChatMentionLabel(member),
              getChatMemberDisplayName(member),
              member?.sibsId,
              member?.email,
            ]
              .map(cleanText)
              .join(" ")
              .toLowerCase();

        return haystack.includes(query);
      })
      .slice(0, 8);
  }, [
    activeConversation?.isGroup,
    activeConversation?.members,
    currentSibsId,
    mentionQuery,
    mentionStart,
  ]);

  const seenMembersByMessageId = useMemo(
    () =>
      calculateSeenMembersByMessageId({
        members: activeConversation?.members,
        currentMessages: chat?.messages,
        currentSibsId,
      }),
    [activeConversation?.members, chat?.messages, currentSibsId],
  );

  const membersBySibsId = useMemo(() => {
    const map = new Map();
    const members = Array.isArray(activeConversation?.members)
      ? activeConversation.members
      : [];

    members.forEach((member) => {
      const sibsId = cleanText(member?.sibsId);
      if (sibsId) {
        map.set(sibsId, member);
      }
    });

    if (activeConversation?.otherMember?.sibsId) {
      map.set(
        cleanText(activeConversation.otherMember.sibsId),
        activeConversation.otherMember,
      );
    }

    return map;
  }, [activeConversation?.members, activeConversation?.otherMember]);

  // The support-role map is small. Stabilize it as a string so every chat
  // polling refresh does not remount/re-render the entire message timeline.
  const helpdeskSenderIdentifierSignature = useMemo(
    () => Object.entries(activeConversation?.helpdeskSenderIdentifiers || {})
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([id, role]) => `${id}:${role}`).join("|"),
    [activeConversation?.helpdeskSenderIdentifiers],
  );

  // An explicit Back action should keep the list visible until the user chooses
  // another thread. Otherwise the desktop auto-selection effect immediately
  // reopens the first conversation after selectConversation(null).
  // The floating launcher opens the conversation list, never an empty/right
  // conversation panel. Explicit selections and notification deep links reset
  // this flag when they intentionally open a conversation.
  const explicitlyViewingListRef = useRef(true);
  // Clear this guard only when the employee selects a conversation again
  // (handleSelectConversation), not when an old active ID is emitted during
  // Back navigation. Otherwise the desktop first-chat auto-selection can
  // immediately undo Back and reopen the same conversation.

  // Do not auto-open the first chat on desktop. A conversation pane must open
  // only after the employee selects a thread, starts a chat, or follows a
  // targeted notification. Back must always return to the sidebar list.

  // When the selected chat is revoked on the server, also dismiss its info
  // overlay instead of leaving a stale Helpdesk/Group membership screen open.
  useEffect(() => {
    if (!chat?.activeConversationId) setGroupInfoOpen(false);
  }, [chat?.activeConversationId]);

  const scrollToLatest = useCallback(() => {
    const scroller = messageScrollRef.current;
    if (!scroller) return;
    scroller.scrollTop = scroller.scrollHeight;
  }, []);

  function navigateToLatestMessageAfterSend() {
    isInitialConversationLoadRef.current = false;
    isNearBottomRef.current = true;
    window.requestAnimationFrame(scrollToLatest);
  }

  // When active conversation changes, mark as initial load and lock nearBottom
  useEffect(() => {
    isInitialConversationLoadRef.current = true;
    isNearBottomRef.current = true;
  }, [chat?.activeConversationId]);

  // Adjust scroll position after prepending older messages
  useEffect(() => {
    if (prevLoadingOlderRef.current && !chat?.loadingOlderMessages) {
      const scroller = messageScrollRef.current;
      if (scroller && olderMessagesScrollHeightRef.current > 0) {
        scroller.scrollTop = calculatePrependScrollTop(
          olderMessagesScrollTopRef.current,
          olderMessagesScrollHeightRef.current,
          scroller.scrollHeight,
        );
      }
    }
    prevLoadingOlderRef.current = Boolean(chat?.loadingOlderMessages);
  }, [chat?.loadingOlderMessages]);

  const latestMessageId = Number(
    chat?.messages?.[chat.messages.length - 1]?.id || 0,
  );

  // Synchronous and multi-pass bottom anchoring effect on message updates
  useEffect(() => {
    if (!open || chat?.messagesLoading || !latestMessageId) return undefined;

    let cancelled = false;

    const performScroll = () => {
      if (cancelled) return;
      if (shouldSnapToBottom(isInitialConversationLoadRef.current, isNearBottomRef.current)) {
        scrollToLatest();
      }
    };

    // Immediate attempt
    performScroll();

    // Multi-frame settling
    const frameId1 = window.requestAnimationFrame(() => {
      performScroll();
      const frameId2 = window.requestAnimationFrame(performScroll);
      return () => window.cancelAnimationFrame(frameId2);
    });

    const timer1 = window.setTimeout(performScroll, 60);
    const timer2 = window.setTimeout(performScroll, 180);
    const timer3 = window.setTimeout(performScroll, 350);

    return () => {
      cancelled = true;
      window.cancelAnimationFrame(frameId1);
      window.clearTimeout(timer1);
      window.clearTimeout(timer2);
      window.clearTimeout(timer3);
    };
  }, [
    chat?.activeConversationId,
    chat?.messagesLoading,
    latestMessageId,
    open,
    scrollToLatest,
  ]);

  // ResizeObserver to track asynchronous height shifts (images, GIFs, media decoding, reactions)
  useEffect(() => {
    const contentEl = messagesListContentRef.current;
    const scrollerEl = messageScrollRef.current;
    if (!contentEl || !scrollerEl) return undefined;

    const resizeObserver = new ResizeObserver(() => {
      if (shouldSnapToBottom(isInitialConversationLoadRef.current, isNearBottomRef.current)) {
        scrollerEl.scrollTop = scrollerEl.scrollHeight;
      }
    });

    resizeObserver.observe(contentEl);

    return () => {
      resizeObserver.disconnect();
    };
  }, [chat?.activeConversationId, chat?.messages?.length]);

  const handleMessagesScroll = useCallback((event) => {
    const target = event.currentTarget;
    if (!target) return;

    const nearBottom = checkIsNearBottom(
      target.scrollTop,
      target.scrollHeight,
      target.clientHeight,
      80,
    );
    isNearBottomRef.current = nearBottom;

    if (!nearBottom) {
      isInitialConversationLoadRef.current = false;
    }
  }, []);

  useEffect(() => {
    selectedImagesRef.current = selectedImages;
  }, [selectedImages]);

  useEffect(() => {
    if (!open && typingConversationIdRef.current) {
      stopTypingIndicator(typingConversationIdRef.current);
    }
  }, [open]);

  useEffect(() => {
    const currentTypingConversationId = Number(
      typingConversationIdRef.current || 0,
    );
    const nextConversationId = Number(activeConversation?.id || 0);

    if (
      currentTypingConversationId &&
      currentTypingConversationId !== nextConversationId
    ) {
      stopTypingIndicator(currentTypingConversationId);
    }
  }, [activeConversation?.id]);

  useEffect(() => {
    return () => {
      selectedImagesRef.current.forEach((item) =>
        item.previewUrl && URL.revokeObjectURL(item.previewUrl),
      );
    };
  }, []);

  useEffect(() => {
    setMentionStart(null);
    setMentionEnd(null);
    setMentionQuery("");
    setMentionActiveIndex(0);
  }, [chat?.activeConversationId]);

  useEffect(() => {
    if (!attachmentNotice) return undefined;

    const timer = window.setTimeout(() => {
      setAttachmentNotice("");
    }, 5000);

    return () => window.clearTimeout(timer);
  }, [attachmentNotice]);


  if (!visible) return null;

  function isMemberOnline(member) {
    if (!member?.sibsId) return false;
    return chat.presence?.[member.sibsId] ?? member.online ?? false;
  }

  function stopTypingIndicator(conversationId = null) {
    if (typingStopTimerRef.current) {
      window.clearTimeout(typingStopTimerRef.current);
      typingStopTimerRef.current = null;
    }

    const targetConversationId = Number(
      conversationId ||
        typingConversationIdRef.current ||
        activeConversation?.id ||
        0,
    );

    if (targetConversationId) {
      void chat?.setTypingStatus?.(targetConversationId, false);
    }

    typingConversationIdRef.current = null;
    typingLastSentAtRef.current = 0;
  }

  function updateTypingIndicator(nextValue) {
    const conversationId = Number(activeConversation?.id || 0);
    if (!conversationId) return;

    if (!String(nextValue ?? "").length) {
      stopTypingIndicator(conversationId);
      return;
    }

    const now = Date.now();
    const changedConversation =
      Number(typingConversationIdRef.current || 0) !== conversationId;
    const heartbeatDue =
      now - Number(typingLastSentAtRef.current || 0) >= 800;

    if (changedConversation || heartbeatDue) {
      typingConversationIdRef.current = conversationId;
      typingLastSentAtRef.current = now;
      void chat?.setTypingStatus?.(conversationId, true);
    }

    if (typingStopTimerRef.current) {
      window.clearTimeout(typingStopTimerRef.current);
    }

    typingStopTimerRef.current = window.setTimeout(() => {
      stopTypingIndicator(conversationId);
    }, 2200);
  }

  // File picker, drag-and-drop and clipboard screenshots share one validation
  // and one upload queue. Selecting media never calls chat.sendMessage().
  function queueChatAttachments(files) {
    const incoming = Array.from(files || []).filter(Boolean);
    if (!incoming.length) return;
    if (!activeConversation || sending) {
      setAttachmentNotice("Open a conversation and wait for the current message to finish before attaching files.");
      return;
    }

    attachmentJobsRef.current += 1;
    setAttachmentsLoading(true);
    attachmentQueueRef.current = attachmentQueueRef.current
      .catch(() => undefined)
      .then(async () => {
        const availableSlots = Math.max(0, MAX_ATTACHMENTS_PER_MESSAGE - selectedImagesRef.current.length);
        const accepted = [];
        const problems = [];

        for (const file of incoming.slice(0, availableSlots)) {
          if (!file.size) {
            problems.push(`${file.name || "This file"} is empty.`);
            continue;
          }
          if (file.size > MAX_ATTACHMENT_BYTES) {
            problems.push(`${file.name} exceeds the 10 MB per-file limit.`);
            continue;
          }

          const detectedMimeType = await validateAttachmentBeforeSelection(file);
          if (!detectedMimeType) {
            problems.push(`${file.name} is not a supported or valid image (including HEIC), audio, video, Word, Excel, PDF, or CSV file.`);
            continue;
          }
          accepted.push({
            file,
            detectedMimeType,
            previewUrl: isChatDocumentMime(detectedMimeType) || isChatHeicImage(file) ? "" : URL.createObjectURL(file),
          });
        }

        if (incoming.length > availableSlots) {
          problems.push(`You can attach up to ${MAX_ATTACHMENTS_PER_MESSAGE} files per message.`);
        }
        if (accepted.length) {
          const updated = [...selectedImagesRef.current, ...accepted];
          selectedImagesRef.current = updated;
          setSelectedImages(updated);
        }
        if (problems.length) {
          setLocalError(problems.join(" "));
          setAttachmentNotice(problems.join(" "));
        } else if (accepted.length) {
          setLocalError("");
          setAttachmentNotice("");
        }
      })
      .catch(() => {
        setAttachmentNotice("Unable to prepare attachments. Please try again.");
      })
      .finally(() => {
        attachmentJobsRef.current -= 1;
        setAttachmentsLoading(attachmentJobsRef.current > 0);
      });
  }

  function handleFiles(event) {
    const incoming = Array.from(event.target.files || []);
    event.target.value = "";
    queueChatAttachments(incoming);
  }

  function hasDraggedChatFiles(event) {
    return Array.from(event.dataTransfer?.types || []).includes("Files");
  }

  function handleChatDragOver(event) {
    if (!hasDraggedChatFiles(event)) return;
    event.preventDefault(); // Prevent the browser from opening a dropped file.
    event.dataTransfer.dropEffect = activeConversation && !sending ? "copy" : "none";
    setDraggingAttachments(true);
  }

  function handleChatDragLeave(event) {
    if (event.currentTarget.contains(event.relatedTarget)) return;
    setDraggingAttachments(false);
  }

  function handleChatDrop(event) {
    if (!hasDraggedChatFiles(event)) return;
    event.preventDefault();
    event.stopPropagation();
    setDraggingAttachments(false);
    queueChatAttachments(event.dataTransfer?.files);
  }

  function handleChatPaste(event) {
    if (!activeConversation || sending) return;
    // Text-only Ctrl+V retains normal textarea insertion. Clipboard image
    // items are staged exactly like a picker-selected image (never auto-sent).
    const clipboard = event.clipboardData;
    const images = Array.from(clipboard?.files || []).filter((file) => file.type.startsWith("image/"));
    if (!images.length) {
      for (const item of Array.from(clipboard?.items || [])) {
        if (item.kind !== "file" || !item.type.startsWith("image/")) continue;
        const image = item.getAsFile?.();
        if (image) images.push(image);
      }
    }
    if (!images.length) return;
    event.preventDefault(); // Don't insert a binary image or copied HTML into the textbox.
    queueChatAttachments(images);
  }

  function removeSelectedImage(index) {
    const current = selectedImagesRef.current;
    const target = current[index];
    if (target?.previewUrl) URL.revokeObjectURL(target.previewUrl);
    const remaining = current.filter((_, currentIndex) => currentIndex !== index);
    selectedImagesRef.current = remaining;
    setSelectedImages(remaining);
  }

  function closeMentionPicker() {
    setMentionStart(null);
    setMentionEnd(null);
    setMentionQuery("");
    setMentionActiveIndex(0);
  }

  function updateMentionPicker(nextValue, cursorPosition) {
    if (!activeConversation?.isGroup) {
      closeMentionPicker();
      return;
    }

    const cursor = Math.max(0, Number(cursorPosition ?? nextValue.length));
    const beforeCursor = nextValue.slice(0, cursor);
    const match = /(^|\s)@([^\s@]*)$/.exec(beforeCursor);

    if (!match) {
      closeMentionPicker();
      return;
    }

    const query = match[2] || "";
    const atIndex = beforeCursor.length - query.length - 1;

    setMentionStart(atIndex);
    setMentionEnd(cursor);
    setMentionQuery(query);
    setMentionActiveIndex(0);
  }

  function insertMention(member) {
    if (mentionStart === null) return;

    const label = getChatMentionLabel(member);
    if (!label) return;

    const end = Number.isFinite(Number(mentionEnd))
      ? Number(mentionEnd)
      : mentionStart + 1 + mentionQuery.length;
    const replacement = `@${label} `;
    const nextDraft = `${draft.slice(0, mentionStart)}${replacement}${draft.slice(end)}`.slice(0, 5000);
    const nextCaret = Math.min(mentionStart + replacement.length, nextDraft.length);

    setDraft(nextDraft);
    updateTypingIndicator(nextDraft);
    closeMentionPicker();

    window.requestAnimationFrame(() => {
      const textarea = textareaRef.current;
      if (!textarea) return;
      textarea.focus();
      textarea.setSelectionRange(nextCaret, nextCaret);
    });
  }

  function insertEmoji(emoji) {
    const input = textareaRef.current;
    const selectionStart = input?.selectionStart ?? draft.length;
    const selectionEnd = input?.selectionEnd ?? selectionStart;

    const nextDraft = `${draft.slice(0, selectionStart)}${emoji}${draft.slice(selectionEnd)}`.slice(0, 5000);
    const nextCaret = Math.min(selectionStart + emoji.length, nextDraft.length);

    setDraft(nextDraft);
    updateTypingIndicator(nextDraft);

    window.requestAnimationFrame(() => {
      const textarea = textareaRef.current;
      if (!textarea) return;

      textarea.focus();
      textarea.setSelectionRange(nextCaret, nextCaret);
    });
  }

  async function submitGif(gif) {
    const gifUrl = cleanText(gif?.gifUrl);
    if (!gifUrl || sending || !activeConversation) return;
    if (activeConversation?.isHelpdesk && (activeConversation.caseStatus === "REJECTED" ||
        (activeConversation.caseStatus === "RESOLVED" && cleanText(activeConversation.createdBySibsId) !== currentSibsId))) {
      setLocalError("This Helpdesk case is closed. Support replies are disabled.");
      return;
    }

    try {
      setSending(true);
      setLocalError("");

      await chat.sendMessage({
        gifUrl,
        replyToMessageId: replyingToMessage?.id || null,
      });

      navigateToLatestMessageAfterSend();
      setReplyingToMessage(null);
      stopTypingIndicator(activeConversation.id);
      setGifPickerOpen(false);
      setGifSearch("");
      setGifResults([]);
      window.requestAnimationFrame(() => textareaRef.current?.focus());
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to send the GIF.",
      );
    } finally {
      setSending(false);
    }
  }

  async function submitMessage() {
    const text = cleanText(draft);
    if (activeConversation?.isHelpdesk && (activeConversation.caseStatus === "REJECTED" ||
        (activeConversation.caseStatus === "RESOLVED" && cleanText(activeConversation.createdBySibsId) !== currentSibsId))) {
      setLocalError("This case is closed. Support replies are disabled. The requester can open a new case.");
      return;
    }
    if ((!text && !selectedImages.length) || sending || attachmentJobsRef.current > 0 || !activeConversation) return;

    try {
      setSending(true);
      setLocalError("");
      await chat.sendMessage({
        message: text,
        images: selectedImages.map((item) => item.file),
        replyToMessageId: replyingToMessage?.id || null,
      });

      navigateToLatestMessageAfterSend();
      setReplyingToMessage(null);
      selectedImages.forEach((item) => { if (item.previewUrl) URL.revokeObjectURL(item.previewUrl); });
      selectedImagesRef.current = [];
      setSelectedImages([]);
      setDraft("");
      if (currentSibsId && activeConversation?.id) {
        clearConversationDraft(currentSibsId, activeConversation.id);
      }
      stopTypingIndicator(activeConversation.id);
      setEmojiPickerOpen(false);
      setGifPickerOpen(false);
      window.requestAnimationFrame(() => textareaRef.current?.focus());
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to send the message.",
      );
    } finally {
      setSending(false);
    }
  }

  function handleComposerKeyDown(event) {
    if (mentionStart !== null && mentionCandidates.length) {
      if (event.key === "ArrowDown") {
        event.preventDefault();
        setMentionActiveIndex((current) =>
          (current + 1) % mentionCandidates.length,
        );
        return;
      }

      if (event.key === "ArrowUp") {
        event.preventDefault();
        setMentionActiveIndex((current) =>
          (current - 1 + mentionCandidates.length) % mentionCandidates.length,
        );
        return;
      }

      if (event.key === "Enter" || event.key === "Tab") {
        event.preventDefault();
        insertMention(
          mentionCandidates[
            Math.min(mentionActiveIndex, mentionCandidates.length - 1)
          ],
        );
        return;
      }

      if (event.key === "Escape") {
        event.preventDefault();
        closeMentionPicker();
        return;
      }
    }

    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      void submitMessage();
    }
  }

  function handleReplyMessage(message) {
    if (!message?.id || message?.unsent) return;

    const messageType = cleanText(message?.messageType).toUpperCase();
    if (messageType === "MEMBER_ADDED" || messageType === "MEMBER_REMOVED") {
      return;
    }

    setReplyingToMessage(message);
    setMessageActionId(null);
    setReactionPickerMessageId(null);
    setEmojiPickerOpen(false);
    setGifPickerOpen(false);
    closeMentionPicker();

    window.requestAnimationFrame(() => textareaRef.current?.focus());
  }

  function scrollToRepliedMessage(messageId) {
    const targetId = Number(messageId || 0);
    const scroller = messageScrollRef.current;
    if (!targetId || !scroller) return;

    const target = scroller.querySelector(`[data-chat-message-id="${targetId}"]`);
    if (!target) return;

    target.scrollIntoView({ behavior: "smooth", block: "center" });
  }

  async function handleMessageReaction(message, reaction) {
    if (!message?.id || message?.unsent || !chat?.reactToMessage) return;

    const messageType = cleanText(message.messageType).toUpperCase();
    if (messageType === "MEMBER_ADDED" || messageType === "MEMBER_REMOVED") {
      return;
    }

    const selectedReaction = cleanText(reaction);
    const myReaction = (Array.isArray(message.reactions) ? message.reactions : []).find(
      (item) => Boolean(item?.reactedByMe),
    )?.reaction;
    const nextReaction = myReaction === selectedReaction ? "" : selectedReaction;

    try {
      setReactingMessageId(Number(message.id));
      setLocalError("");
      await chat.reactToMessage(message.id, nextReaction);
      setReactionPickerMessageId(null);
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to react to the message.",
      );
    } finally {
      setReactingMessageId(null);
    }
  }

  function handleUnsendMessage(message) {
    if (
      !message?.id ||
      cleanText(message.senderSibsId) !== currentSibsId ||
      message?.unsent
    ) {
      return;
    }

    setMessageActionId(null);
    setUnsendConfirmMessage(message);
  }

  async function confirmUnsendMessage() {
    const message = unsendConfirmMessage;
    if (!message?.id || Number(unsendingMessageId) === Number(message.id)) return;

    try {
      setUnsendingMessageId(Number(message.id));
      setLocalError("");
      await chat.unsendMessage(message.id);
      setUnsendConfirmMessage(null);
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to unsend the message.",
      );
    } finally {
      setUnsendingMessageId(null);
    }
  }

  function handleSetNickname(conversation) {
    if (!conversation?.id || conversation?.isGroup) return;

    setConversationActionId(null);
    setNicknameConversation(conversation);
    setNicknameDraft(
      cleanText(
        conversation?.otherMember?.chatNickname ||
          conversation?.otherMember?.chat_nickname,
      ),
    );
  }

  async function savePrivateNickname() {
    const conversationId = Number(nicknameConversation?.id || 0);
    if (
      !conversationId ||
      nicknameConversation?.isGroup ||
      nicknameSaving ||
      !chat?.setPrivateNickname
    ) {
      return;
    }

    try {
      setNicknameSaving(true);
      setLocalError("");
      await chat.setPrivateNickname(conversationId, nicknameDraft);
      setNicknameConversation(null);
      setNicknameDraft("");
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to update the nickname.",
      );
    } finally {
      setNicknameSaving(false);
    }
  }

  async function handleHideConversation(conversation) {
    const conversationId = Number(conversation?.id || 0);
    if (!conversationId || conversation?.isGroup || !chat?.hidePrivateConversation) return;

    try {
      setConversationActionBusyId(conversationId);
      setLocalError("");
      await chat.hidePrivateConversation(conversationId);
      setConversationActionId(null);
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to hide the conversation.",
      );
    } finally {
      setConversationActionBusyId(null);
    }
  }

  function handleDeleteConversation(conversation) {
    if (!conversation?.id || conversation?.isGroup) return;
    setConversationActionId(null);
    setDeleteConversationConfirm(conversation);
  }

  async function confirmDeleteConversation() {
    const conversation = deleteConversationConfirm;
    const conversationId = Number(conversation?.id || 0);

    if (
      !conversationId ||
      conversation?.isGroup ||
      Number(conversationActionBusyId) === conversationId ||
      !chat?.deletePrivateConversation
    ) {
      return;
    }

    try {
      setConversationActionBusyId(conversationId);
      setLocalError("");
      await chat.deletePrivateConversation(conversationId);
      setDeleteConversationConfirm(null);
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to delete the conversation.",
      );
    } finally {
      setConversationActionBusyId(null);
    }
  }

  async function runAction(action) {
    try {
      setActionBusy(true);
      setLocalError("");
      return await action();
    } catch (requestError) {
      setLocalError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to complete the chat action.",
      );
      throw requestError;
    } finally {
      setActionBusy(false);
    }
  }

  function clampLauncherPosition(left, top) {
    const element = launcherRef.current;
    const margin = 8;
    const width = element?.offsetWidth || 140;
    const height = element?.offsetHeight || 52;
    const maxLeft = Math.max(margin, window.innerWidth - width - margin);
    const maxTop = Math.max(margin, window.innerHeight - height - margin);

    return {
      left: Math.min(Math.max(margin, left), maxLeft),
      top: Math.min(Math.max(margin, top), maxTop),
    };
  }

  function handleLauncherPointerDown(event) {
    if (event.pointerType === "mouse" && event.button !== 0) return;

    const rect = event.currentTarget.getBoundingClientRect();

    launcherDragRef.current = {
      active: true,
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      startLeft: rect.left,
      startTop: rect.top,
      moved: false,
    };

    suppressLauncherClickRef.current = false;
    event.currentTarget.setPointerCapture?.(event.pointerId);
  }

  function handleLauncherPointerMove(event) {
    const drag = launcherDragRef.current;
    if (!drag.active || drag.pointerId !== event.pointerId) return;

    const deltaX = event.clientX - drag.startX;
    const deltaY = event.clientY - drag.startY;

    if (!drag.moved && Math.hypot(deltaX, deltaY) < 5) return;

    drag.moved = true;
    suppressLauncherClickRef.current = true;
    setLauncherDragging(true);
    setLauncherPosition(
      clampLauncherPosition(drag.startLeft + deltaX, drag.startTop + deltaY),
    );
  }

  function finishLauncherDrag(event) {
    const drag = launcherDragRef.current;
    if (!drag.active || drag.pointerId !== event.pointerId) return;

    event.currentTarget.releasePointerCapture?.(event.pointerId);
    launcherDragRef.current = {
      ...drag,
      active: false,
      pointerId: null,
    };
    setLauncherDragging(false);
  }

  function handleLauncherClick(event) {
    if (suppressLauncherClickRef.current) {
      suppressLauncherClickRef.current = false;
      event.preventDefault();
      return;
    }

    if (!open) {
      void ensureSibsChatSystemNotifications();
      // Reopening the launcher starts in the conversation list even if the
      // ChatContext remembered a previously selected conversation.
      explicitlyViewingListRef.current = true;
      setNewChatOpen(false);
      setGroupInfoOpen(false);
    }

    setOpen((current) => !current);
  }

  async function openMembershipNoticeGroup() {
    const notice = chat?.membershipNotice;
    const conversationId = Number(notice?.conversationId || 0);

    if (!conversationId || cleanText(notice?.action).toLowerCase() !== "added") {
      chat?.dismissMembershipNotice?.();
      return;
    }

    setOpen(true);
    setNewChatOpen(false);
    setGroupInfoOpen(false);
    explicitlyViewingListRef.current = false;

    try {
      await chat.refreshConversations?.();
      await chat.selectConversation?.(conversationId);
    } finally {
      chat?.dismissMembershipNotice?.();
    }
  }

  const activeOtherMember = activeConversation?.otherMember;
  const activePrivateOnline = activeOtherMember
    ? isMemberOnline(activeOtherMember)
    : false;
  const activePrivateNickname = cleanText(
    activeOtherMember?.chatNickname || activeOtherMember?.chat_nickname,
  );
  const activePrivateFullName = activeOtherMember
    ? getChatMemberFullName(activeOtherMember)
    : "";
  const activePrivateLastSeen = formatChatLastSeen(
    activeOtherMember?.lastSeenAt || activeOtherMember?.last_seen_at,
    chatClockMs,
  );
  const activePrivateStatus = activePrivateOnline
    ? "Active now"
    : activePrivateLastSeen
      ? `Offline · ${activePrivateLastSeen}`
      : "Offline";

  const isCustomTheme = isChatThemeCustom(conversationTheme);
  const isThemeDark = isChatThemeDark(conversationTheme, imageLuminanceIsDark);

  // Desktop and mobile use the same explicit selection rule. The desktop
  // window widens to reveal the messages; mobile slides between full panes.
  const hasActiveMobileView = Boolean(
    (newChatOpen || (activeConversation && !explicitlyViewingListRef.current)) &&
      !isNavigatingBack,
  );
  // Preserve the v31 close-button rule in this updated SiBSChat version.
  // During the Back slide-out, keep the sidebar X hidden until the conversation
  // pane has finished collapsing; show it once the sidebar is visible alone.
  const showSidebarCloseButton = !hasActiveMobileView && !isNavigatingBack;

  function handleBackToList() {
    // If a Helpdesk/Group Info overlay is visible, Back first returns to the
    // conversation messages. This also protects keyboard/focus navigation if
    // the underlying conversation-header button receives a click.
    if (groupInfoOpen) {
      setGroupInfoOpen(false);
      return;
    }
    if (currentSibsId && activeConversation?.id && cleanText(draft)) {
      saveConversationDraft(currentSibsId, activeConversation.id, draft);
    }
    explicitlyViewingListRef.current = true;
    setHelpdeskStatusMenuOpen(false);
    setHelpdeskCloseConfirm(false);
    setGroupInfoOpen(false);
    // Keep the conversation mounted for the slide-out, then clear the
    // selection. Without this, the right pane instantly swaps to an empty
    // state before the sidebar finishes expanding into view.
    setIsNavigatingBack(true);
    if (navigateBackTimerRef.current) {
      clearTimeout(navigateBackTimerRef.current);
    }
    navigateBackTimerRef.current = setTimeout(() => {
      void chat?.selectConversation?.(null);
      if (currentSibsId) {
        saveChatState(currentSibsId, { activeConversationId: null });
      }
      setIsNavigatingBack(false);
      navigateBackTimerRef.current = null;
    }, 250);
  }

  function handleCloseNewChat() {
    if (!activeConversation || explicitlyViewingListRef.current) {
      setIsExpanded(false);
      setExpandedBounds(null);
    }
    if (typeof window !== "undefined" && window.matchMedia?.("(max-width: 639px)")?.matches) {
      setIsNavigatingBack(true);
      if (navigateBackTimerRef.current) {
        clearTimeout(navigateBackTimerRef.current);
      }
      navigateBackTimerRef.current = setTimeout(() => {
        setNewChatOpen(false);
        setIsNavigatingBack(false);
        navigateBackTimerRef.current = null;
      }, 300);
    } else {
      setNewChatOpen(false);
    }
  }

  // Direct Helpdesk contact from the sidebar. Opening an existing draft or
  // creating a thread does not open a case; the first message does that.
  // Use the same endpoint and permissions as the former New Chat Helpdesk tab.
  async function handleContactHelpdesk(category) {
    if (!canRequestHelpdesk(category)) {
      setHelpdeskStartError("This Helpdesk category is handled by your support team. Choose the other Helpdesk category for a personal request.");
      return;
    }
    if (helpdeskRequestPendingRef.current) return;
    helpdeskRequestPendingRef.current = true;
    setHelpdeskStartingCategory(category);
    setHelpdeskStartError("");
    try {
      const result = await chat.startHelpdeskConversation(category);
      if (!Number(result?.id)) {
        throw new Error("Unable to open the Helpdesk request.");
      }
      explicitlyViewingListRef.current = false;
      if (navigateBackTimerRef.current) {
        clearTimeout(navigateBackTimerRef.current);
        navigateBackTimerRef.current = null;
      }
      setIsNavigatingBack(false);
      setNewChatOpen(false);
      setExpandedChatFolders((previous) => ({
        ...previous,
        helpdesk: true,
        [category === "IT" ? "it" : "taHr"]: true,
      }));
    } catch (requestError) {
      setHelpdeskStartError(
        requestError?.response?.data?.message ||
          requestError?.message ||
          "Unable to contact the Helpdesk. Please try again.",
      );
    } finally {
      helpdeskRequestPendingRef.current = false;
      setHelpdeskStartingCategory("");
    }
  }

  function handleSelectConversation(conversationId) {
    if (currentSibsId && activeConversation?.id && cleanText(draft)) {
      saveConversationDraft(currentSibsId, activeConversation.id, draft);
    }
    explicitlyViewingListRef.current = false;
    if (navigateBackTimerRef.current) {
      clearTimeout(navigateBackTimerRef.current);
      navigateBackTimerRef.current = null;
    }
    setIsNavigatingBack(false);
    setConversationActionId(null);
    if (currentSibsId) {
      saveChatState(currentSibsId, {
        activeConversationId: conversationId,
        isOpen: true,
      });
    }
    void chat?.selectConversation?.(conversationId);
  }

  function renderConversationRow(conversation, { nested = false, showCategoryBadge = false } = {}) {
    const selected = Number(chat.activeConversationId) === Number(conversation.id);
    const otherMember = conversation.otherMember;
    const online = otherMember ? isMemberOnline(otherMember) : false;
    const isHelpdeskThread = Boolean(conversation.isHelpdesk);
    const helpdeskLabel = isHelpdeskThread
      ? getHelpdeskCategoryLabel(conversation.helpdeskCategory) : "";
    const conversationTypingIds = Array.isArray(
      chat?.typingByConversation?.[Number(conversation.id)],
    )
      ? chat.typingByConversation[Number(conversation.id)]
      : [];

    const conversationMembers = Array.isArray(conversation?.members)
      ? conversation.members
      : [];

    const conversationTypingNames = conversationTypingIds
      .map((sibsId) =>
        conversationMembers.find(
          (member) =>
            cleanText(member?.sibsId) === cleanText(sibsId),
        ),
      )
      .filter(Boolean)
      .filter(
        (member) =>
          cleanText(member?.sibsId) !== cleanText(currentSibsId),
      )
      .map((member) => getChatMemberDisplayName(member))
      .filter(Boolean);

    const conversationTypingLabel =
      conversationTypingNames.length === 1
        ? `${conversationTypingNames[0]} is typing...`
        : conversationTypingNames.length === 2
          ? `${conversationTypingNames[0]} and ${conversationTypingNames[1]} are typing...`
          : conversationTypingNames.length > 2
            ? `${conversationTypingNames[0]}, ${conversationTypingNames[1]}, and ${
                conversationTypingNames.length - 2
              } other${
                conversationTypingNames.length - 2 === 1 ? "" : "s"
              } are typing...`
            : "";

    const preview =
      conversationTypingLabel ||
      conversation.lastMessageText ||
      (conversation.lastMessageType?.includes("DOCUMENT")
        ? "Sent a document"
        : conversation.lastMessageType?.includes("VIDEO")
        ? "Sent a video"
        : conversation.lastMessageType?.includes("MEDIA")
          ? "Sent media"
          : conversation.lastMessageType?.includes("IMAGE")
            ? "Sent an image"
            : conversation.lastMessageType === "GIF"
              ? "GIF"
              : "No messages yet");

    const actionMenuOpen =
      Number(conversationActionId) === Number(conversation.id);
    const actionBusy =
      Number(conversationActionBusyId) === Number(conversation.id);
    const categoryBadge = showCategoryBadge ? getConversationCategoryBadge(conversation) : null;
    const fullDateStr = formatConversationFullDate(conversation.lastMessageAt || conversation.updatedAt);

    return (
      <div
        key={conversation.id}
        role="listitem"
        className={`group relative mb-1 flex items-center rounded-xl border-l-[3px] transition ${
          nested ? "ml-2 w-[calc(100%-0.5rem)]" : "w-full"
        } ${
          selected
            ? "border-l-sibs-orange bg-sibs-cream-subtle border-y border-r border-sibs-border/60"
            : "border-l-transparent hover:bg-sibs-surface"
        }`}
      >
        <button
          type="button"
          onClick={() => handleSelectConversation(conversation.id)}
          aria-selected={selected}
          className="flex min-w-0 flex-1 items-center gap-3 px-3 py-2.5 text-left"
        >
          {isHelpdeskThread ? (
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sibs-cream-light text-sibs-orange">
              {cleanText(conversation.helpdeskCategory).toUpperCase() === "IT"
                ? <MonitorCog size={18} /> : <HeartHandshake size={18} />}
            </span>
          ) : (
            <ChatAvatar
              employee={conversation.isGroup ? null : otherMember}
              initials={conversation.initials}
              online={online}
              group={conversation.isGroup}
              size="md"
            />
          )}
          <span className="min-w-0 flex-1">
            {isHelpdeskThread ? (
              <>
                <span className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 truncate">
                    <span className="truncate text-[10px] font-extrabold text-sibs-orange">
                      My {helpdeskLabel} request
                    </span>
                    {categoryBadge ? (
                      <span className={`inline-flex shrink-0 items-center rounded-md border px-1.5 py-0.2 text-[9px] font-bold ${categoryBadge.color}`}>
                        {categoryBadge.label}
                      </span>
                    ) : null}
                  </span>
                  <time
                    dateTime={new Date(conversation.lastMessageAt || conversation.updatedAt || Date.now()).toISOString()}
                    title={fullDateStr}
                    className="shrink-0 text-[9px] font-medium text-sibs-faint"
                  >
                    {formatConversationTime(conversation.lastMessageAt || conversation.updatedAt, chatClockMs)}
                  </time>
                </span>
                <span className="mt-0.5 block truncate text-xs font-extrabold text-sibs-navy">
                  {getHelpdeskCaseLabel(conversation)}
                </span>
                <span className="mt-0.5 flex min-w-0 items-center gap-2">
                  <span className={`min-w-0 flex-1 truncate text-[10px] ${conversationTypingLabel ? "font-bold text-sibs-orange" : "text-sibs-muted"}`}>
                    {preview}
                  </span>
                  {conversation.unreadCount > 0 ? (
                    <span className="inline-flex min-w-5 shrink-0 items-center justify-center rounded-full bg-sibs-orange px-1.5 py-0.5 text-[9px] font-black text-white">
                      {conversation.unreadCount > 99 ? "99+" : conversation.unreadCount}
                    </span>
                  ) : null}
                </span>
              </>
            ) : (
              <>
                <span className="flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 truncate">
                    <span className="truncate text-sm font-bold text-sibs-navy">
                      {!conversation.isGroup
                        ? cleanText(
                            otherMember?.chatNickname ||
                              otherMember?.chat_nickname,
                          ) ||
                          cleanText(otherMember?.displayName) ||
                          conversation.title
                        : conversation.title}
                    </span>
                    {categoryBadge ? (
                      <span className={`inline-flex shrink-0 items-center rounded-md border px-1.5 py-0.2 text-[9px] font-bold ${categoryBadge.color}`}>
                        {categoryBadge.label}
                      </span>
                    ) : null}
                  </span>
                  <time
                    dateTime={new Date(conversation.lastMessageAt || conversation.updatedAt || Date.now()).toISOString()}
                    title={fullDateStr}
                    className="shrink-0 text-[11px] font-medium text-sibs-faint"
                  >
                    {formatConversationTime(conversation.lastMessageAt || conversation.updatedAt, chatClockMs)}
                  </time>
                </span>
                <span className="mt-0.5 flex items-center gap-2">
                  <span
                    className={`min-w-0 flex-1 truncate text-xs ${
                      conversationTypingLabel
                        ? "font-extrabold text-sibs-orange"
                        : conversation.unreadCount
                          ? "font-extrabold text-sibs-navy"
                          : "font-normal text-sibs-muted"
                    }`}
                  >
                    {preview}
                  </span>
                  {conversation.unreadCount > 0 ? (
                    <span className="inline-flex min-w-5 items-center justify-center rounded-full bg-sibs-orange px-1.5 py-0.5 text-[9px] font-black text-white">
                      {conversation.unreadCount > 99 ? "99+" : conversation.unreadCount}
                    </span>
                  ) : null}
                </span>
              </>
            )}
          </span>
        </button>

        {!conversation.isGroup ? (
          <div
            data-chat-conversation-actions
            className="relative mr-1.5 shrink-0"
          >
            <button
              type="button"
              aria-label={`Conversation options for ${conversation.title}`}
              aria-haspopup="menu"
              aria-expanded={actionMenuOpen}
              disabled={actionBusy}
              onClick={() =>
                setConversationActionId((current) =>
                  Number(current) === Number(conversation.id)
                    ? null
                    : conversation.id,
                )
              }
              className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-sibs-faint transition hover:bg-white hover:text-sibs-navy disabled:cursor-not-allowed disabled:opacity-50"
            >
              {actionBusy ? (
                <Loader2 size={14} className="animate-spin" />
              ) : (
                <MoreHorizontal size={16} />
              )}
            </button>

            {actionMenuOpen ? (
              <div
                role="menu"
                className="absolute right-0 top-8 z-40 w-44 overflow-hidden rounded-xl border border-sibs-border bg-white p-1.5 shadow-[0_12px_32px_rgba(4,44,81,0.18)]"
              >
                <button
                  type="button"
                  role="menuitem"
                  disabled={actionBusy}
                  onClick={() => handleSetNickname(conversation)}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[10px] font-extrabold text-sibs-navy transition hover:bg-sibs-surface disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <Pencil size={14} />
                  Set nickname
                </button>
                <button
                  type="button"
                  role="menuitem"
                  disabled={actionBusy}
                  onClick={() => void handleHideConversation(conversation)}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[10px] font-extrabold text-sibs-navy transition hover:bg-sibs-surface disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <EyeOff size={14} />
                  Hide conversation
                </button>
                <button
                  type="button"
                  role="menuitem"
                  disabled={actionBusy}
                  onClick={() => handleDeleteConversation(conversation)}
                  className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[10px] font-extrabold text-red-600 transition hover:bg-red-50 disabled:cursor-not-allowed disabled:opacity-50"
                >
                  <Trash2 size={14} />
                  Delete conversation
                </button>
              </div>
            ) : null}
          </div>
        ) : null}
      </div>
    );
  }

  const chatUi = (
    <>
      {chat?.membershipNotice && !open ? (
        <div
          className="fixed right-4 z-[35] w-[min(340px,calc(100vw-2rem))] sm:right-6"
          style={{
            bottom: hideTrigger
              ? "calc(4.75rem + env(safe-area-inset-bottom, 0px))"
              : "calc(9.75rem + env(safe-area-inset-bottom, 0px))",
          }}
        >
          <MembershipNoticeCard
            notice={chat.membershipNotice}
            onOpenGroup={() => void openMembershipNoticeGroup()}
            onDismiss={() => chat.dismissMembershipNotice?.()}
          />
        </div>
      ) : null}

      {/* Minimized Floating Dock Chip */}
      {open && isMinimized ? (
        <aside
          ref={minimizedDockRef}
          aria-label="Minimized SiBS Chat"
          data-testid="sibs-chat-minimized-dock"
          className="fixed z-[35] flex items-center gap-1.5 rounded-2xl border border-sibs-border bg-sibs-navy px-2.5 py-1.5 font-jakarta text-white shadow-2xl transition-all right-4 sm:right-6"
          style={{
            bottom: "calc(1.5rem + env(safe-area-inset-bottom, 0px))",
          }}
        >
          <button
            type="button"
            onClick={handleRestoreFromMinimized}
            title={
              activeConversation
                ? `Restore chat: ${activeConversation.title || "Conversation"}`
                : "Restore SiBS Chat"
            }
            aria-label={
              activeConversation
                ? `Restore chat with ${activeConversation.title || "active conversation"}`
                : "Restore SiBS Chat"
            }
            className="flex items-center gap-2 rounded-xl px-2 py-1 text-left text-xs font-bold text-white transition hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-white"
          >
            <span className="relative inline-flex h-7 w-7 items-center justify-center rounded-lg bg-sibs-orange text-white">
              <MessageCircleMore size={15} />
              {chat.totalUnread > 0 ? (
                <span className="absolute -right-1.5 -top-1.5 inline-flex min-h-4 min-w-4 items-center justify-center rounded-full bg-red-600 px-1 text-[8px] font-black text-white">
                  {chat.totalUnread > 99 ? "99+" : chat.totalUnread}
                </span>
              ) : null}
            </span>
            <span className="max-w-[160px] truncate sm:max-w-[200px]">
              {activeConversation
                ? (activeConversation.isHelpdesk
                    ? getPersonalHelpdeskChatTitle(activeConversation.helpdeskCategory)
                    : activeConversation.title)
                : "SiBS Chat"}
            </span>
          </button>
          <button
            type="button"
            onClick={handleRestoreFromMinimized}
            title="Restore chat window"
            aria-label="Restore chat window"
            className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
          >
            <Maximize2 size={13} />
          </button>
          <button
            type="button"
            onClick={handleClose}
            title="Close chat"
            aria-label="Close chat"
            className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
          >
            <X size={14} />
          </button>
        </aside>
      ) : null}

      {!hideTrigger && !open ? (
        <button
          ref={launcherRef}
          type="button"
          onClick={handleLauncherClick}
          onPointerDown={handleLauncherPointerDown}
          onPointerMove={handleLauncherPointerMove}
          onPointerUp={finishLauncherDrag}
          onPointerCancel={finishLauncherDrag}
          aria-label={chat.totalUnread > 0 ? `Open SiBS Chat, ${chat.totalUnread} unread message${chat.totalUnread === 1 ? "" : "s"}` : "Open SiBS Chat"}
          aria-expanded={open}
          className={`fixed z-[35] inline-flex select-none items-center gap-2 rounded-2xl border border-white/10 bg-sibs-navy px-3 py-2.5 font-jakarta text-sm font-extrabold text-white shadow-xl transition hover:bg-sibs-tertiary-2 ${
            launcherPosition ? "" : "right-4 sm:right-6"
          } ${launcherDragging ? "cursor-grabbing" : "cursor-grab"} ${
            open ? "opacity-0 pointer-events-none" : "opacity-100"
          }`}
          style={
            launcherPosition
              ? {
                  left: `${launcherPosition.left}px`,
                  top: `${launcherPosition.top}px`,
                  right: "auto",
                  bottom: "auto",
                  touchAction: "none",
                }
              : {
                  bottom: "calc(5.5rem + env(safe-area-inset-bottom, 0px))",
                  touchAction: "none",
                }
          }
        >
          <span className="relative inline-flex h-8 w-8 items-center justify-center rounded-xl bg-sibs-orange">
            <MessageCircleMore size={17} />
            {chat.totalUnread > 0 ? (
              <span className="absolute -right-2 -top-2 inline-flex min-h-5 min-w-5 items-center justify-center rounded-full border-2 border-white bg-red-600 px-1 text-[9px] font-black text-white">
                {chat.totalUnread > 99 ? "99+" : chat.totalUnread}
              </span>
            ) : null}
          </span>
          <span className="hidden sm:inline">SiBS Chat</span>
        </button>
      ) : null}

      <section
        ref={chatPanelRef}
        id="sibs-chat-panel"
        role="region"
        aria-label="SiBS Chat"
        data-expanded={isExpanded}
        data-minimized={isMinimized}
        onDragEnter={handleChatDragOver}
        onDragOver={handleChatDragOver}
        onDragLeave={handleChatDragLeave}
        onDrop={handleChatDrop}
        onDragEnd={() => setDraggingAttachments(false)}
        className={`font-jakarta fixed z-[35] flex overflow-hidden rounded-2xl border border-sibs-border bg-white shadow-2xl transition-all duration-300 ease-[cubic-bezier(0.22,1,0.36,1)] motion-reduce:transition-none max-sm:!inset-0 max-sm:!h-[100dvh] max-sm:!w-screen max-sm:!rounded-none max-sm:!border-0 ${
          isMinimized
            ? "pointer-events-none opacity-0 invisible translate-y-4 scale-95"
            : open
              ? "pointer-events-auto translate-y-0 scale-100 opacity-100"
              : "pointer-events-none max-sm:translate-y-full max-sm:opacity-0 sm:translate-y-3 sm:scale-[0.98] sm:opacity-0 invisible"
        } ${
          isExpanded
            ? "w-[min(1100px,calc(100vw-3rem))] h-[min(820px,calc(100dvh-5rem))]"
            : "w-[min(440px,calc(100vw-2rem))] h-[min(680px,calc(100dvh-3rem))]"
        } right-4 sm:right-6 bottom-4 sm:bottom-6`}
        style={
          isExpanded && expandedBounds && !(typeof window !== "undefined" && window.matchMedia("(max-width: 639px)").matches)
            ? {
                left: `${expandedBounds.left}px`,
                right: "auto",
                top: `${expandedBounds.top}px`,
                bottom: "auto",
                width: `${expandedBounds.width}px`,
                height: `${expandedBounds.height}px`,
              }
            : undefined
        }
      >
        {open && draggingAttachments ? (
          <div className="pointer-events-none absolute inset-0 z-[210] flex items-center justify-center rounded-2xl border-[3px] border-dashed border-sibs-orange bg-sibs-navy/80 p-6 text-center backdrop-blur-[2px]" role="status" aria-live="polite">
            <div className="rounded-2xl border border-white/20 bg-sibs-navy px-5 py-6 text-white shadow-2xl">
              <ImagePlus size={30} className="mx-auto mb-3 text-sibs-orange" aria-hidden="true" />
              <p className="text-base font-extrabold">{activeConversation && !sending ? "Drop files to attach" : "Select a chat to attach files"}</p>
              <p className="mt-1 text-xs font-medium text-white/80">Up to 5 files per message · 10 MB per file · Send when ready</p>
            </div>
          </div>
        ) : null}
        {chat?.membershipNotice && open ? (
          <div className="pointer-events-none absolute left-1/2 top-3 z-50 w-[min(340px,90%)] -translate-x-1/2">
            <div className="pointer-events-auto">
              <MembershipNoticeCard
                notice={chat.membershipNotice}
                onOpenGroup={() => void openMembershipNoticeGroup()}
                onDismiss={() => chat.dismissMembershipNotice?.()}
              />
            </div>
          </div>
        ) : null}

        <aside
          className={`flex flex-col bg-white overflow-hidden transition-all duration-200 ${
            isExpanded
              ? "w-[320px] shrink-0 border-r border-sibs-border h-full"
              : hasActiveMobileView
                ? "hidden"
                : "w-full flex-1 h-full"
          }`}
        >
          <header className="border-b border-white/10 bg-sibs-navy px-3 py-3 text-white sm:px-4">
            <div className="flex items-center gap-2 sm:gap-2.5">
              <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-sibs-orange text-white shadow-xs">
                <MessageCircleMore size={18} />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="truncate font-heading text-sm font-extrabold text-white sm:text-base">SiBS Chat</h2>
                  {chat.totalUnread > 0 ? (
                    <span className="rounded-full bg-sibs-orange px-2 py-0.5 text-[10px] font-extrabold text-white">
                      {chat.totalUnread}
                    </span>
                  ) : null}
                </div>
                <p className="truncate text-[10px] font-semibold text-white/70">
                  {activeCategoryTab === "private"
                    ? "Private Messages"
                    : activeCategoryTab === "groups"
                      ? "Group Chats"
                      : activeCategoryTab === "helpdesk"
                        ? "IT Support & TA/HR Concerns"
                        : "Recent conversations"}
                </p>
              </div>

              {activeCategoryTab === "private" ? (
                <button
                  type="button"
                  onClick={() => setNewChatOpen(true)}
                  title="Start private message"
                  aria-label="Start private message"
                  className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                >
                  <Plus size={17} />
                </button>
              ) : activeCategoryTab === "groups" ? (
                <button
                  type="button"
                  onClick={() => setNewChatOpen(true)}
                  title="Create group chat"
                  aria-label="Create group chat"
                  className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                >
                  <Plus size={17} />
                </button>
              ) : activeCategoryTab === "helpdesk" ? (
                <button
                  type="button"
                  onClick={() => handleContactHelpdesk(helpdeskSubfilter === "taHr" ? "TA_HR" : "IT")}
                  title={helpdeskSubfilter === "taHr" ? "New TA/HR concern" : "New IT Support request"}
                  aria-label={helpdeskSubfilter === "taHr" ? "New TA/HR concern" : "New IT Support request"}
                  className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                >
                  <Plus size={17} />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setNewChatOpen(true)}
                  title="New chat"
                  aria-label="New chat"
                  className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                >
                  <Plus size={17} />
                </button>
              )}

              {(!isExpanded || !activeConversation) ? (
                <>
                  <button
                    type="button"
                    onClick={handleMinimize}
                    title="Minimize chat"
                    aria-label="Minimize chat"
                    className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                  >
                    <Minus size={16} />
                  </button>
                  <button
                    type="button"
                    onClick={toggleExpanded}
                    title={isExpanded ? "Restore compact size" : "Expand chat"}
                    aria-label={isExpanded ? "Restore compact size" : "Expand chat"}
                    aria-expanded={isExpanded}
                    aria-controls="sibs-chat-panel"
                    className="hidden h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white sm:inline-flex"
                  >
                    {isExpanded ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
                  </button>
                  <button
                    type="button"
                    onClick={handleClose}
                    title="Close SiBS Chat"
                    aria-label="Close SiBS Chat"
                    className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                  >
                    <X size={17} />
                  </button>
                </>
              ) : null}
            </div>
          </header>

          <div className="border-b border-sibs-border px-3 py-2.5">
            <label className="relative block">
              <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sibs-faint" />
              <input
                type="search"
                value={conversationSearch}
                onChange={(event) => setConversationSearch(event.target.value)}
                placeholder="Search chats..."
                aria-label="Search chats"
                className="h-9 w-full rounded-xl border border-sibs-border bg-sibs-surface pl-9 pr-3 text-xs font-semibold text-sibs-navy outline-none transition placeholder:text-sibs-faint hover:border-sibs-border focus:border-sibs-orange focus:bg-white focus:ring-2 focus:ring-sibs-orange/10"
              />
            </label>
          </div>

          {/* Category Filter Tabs & View Mode Switcher */}
          <div className="border-b border-sibs-border bg-sibs-surface/60 px-2.5 py-1.5">
            <div className="flex items-center justify-between gap-1">
              <div className="flex min-w-0 flex-1 items-center gap-1 overflow-x-auto no-scrollbar">
                {[
                  { id: "all", label: "Recent", count: unreadCounts.all },
                  { id: "private", label: "Private", count: unreadCounts.private },
                  { id: "groups", label: "Groups", count: unreadCounts.groups },
                  { id: "helpdesk", label: "Helpdesk", count: unreadCounts.helpdesk },
                ].map((tab) => {
                  const active = activeCategoryTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => {
                        setActiveCategoryTab(tab.id);
                        if (currentSibsId) {
                          saveChatState(currentSibsId, { activeCategoryTab: tab.id });
                        }
                      }}
                      aria-selected={active}
                      className={`inline-flex shrink-0 items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] font-bold transition ${
                        active
                          ? "bg-white text-sibs-navy shadow-xs border border-sibs-border/80"
                          : "text-sibs-muted hover:bg-white/60 hover:text-sibs-navy"
                      }`}
                    >
                      <span>{tab.label}</span>
                      {tab.count > 0 ? (
                        <span className="inline-flex min-h-4 min-w-4 items-center justify-center rounded-full bg-sibs-orange px-1 text-[8px] font-black text-white">
                          {tab.count > 99 ? "99+" : tab.count}
                        </span>
                      ) : null}
                    </button>
                  );
                })}
              </div>

              <div className="flex shrink-0 items-center rounded-lg border border-sibs-border bg-white p-0.5">
                <button
                  type="button"
                  onClick={() => setInboxViewMode("list")}
                  title="List view"
                  aria-label="List view"
                  className={`inline-flex h-6 w-6 items-center justify-center rounded-md text-xs transition ${
                    inboxViewMode === "list"
                      ? "bg-sibs-navy text-white shadow-xs"
                      : "text-sibs-muted hover:text-sibs-navy"
                  }`}
                >
                  <ListFilter size={13} />
                </button>
                <button
                  type="button"
                  onClick={() => setInboxViewMode("folders")}
                  title="Folder view"
                  aria-label="Folder view"
                  className={`inline-flex h-6 w-6 items-center justify-center rounded-md text-xs transition ${
                    inboxViewMode === "folders"
                      ? "bg-sibs-navy text-white shadow-xs"
                      : "text-sibs-muted hover:text-sibs-navy"
                  }`}
                >
                  <FolderTree size={13} />
                </button>
              </div>
            </div>

            {activeCategoryTab === "helpdesk" ? (
              <div className="mt-1.5 flex items-center gap-1.5 pt-1 border-t border-sibs-border/50">
                {[
                  { id: "all", label: "All Helpdesk", count: categoryConversations.helpdesk.length },
                  { id: "it", label: "IT Support", count: categoryConversations.it.length },
                  { id: "taHr", label: "TA/HR Concerns", count: categoryConversations.taHr.length },
                ].map((sub) => {
                  const subActive = helpdeskSubfilter === sub.id;
                  return (
                    <button
                      key={sub.id}
                      type="button"
                      onClick={() => setHelpdeskSubfilter(sub.id)}
                      className={`inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold transition ${
                        subActive
                          ? "bg-sibs-orange/15 text-sibs-orange font-extrabold"
                          : "text-sibs-muted hover:bg-white"
                      }`}
                    >
                      <span>{sub.label}</span>
                      <span className="text-[9px] opacity-75">({sub.count})</span>
                    </button>
                  );
                })}
              </div>
            ) : null}
          </div>

          {helpdeskRequestScopeError ? (
            <p role="alert" className="mx-3 mt-2 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-[11px] font-semibold text-amber-800">
              {helpdeskRequestScopeError}
            </p>
          ) : null}
          {open && !requestableHelpdeskCategories ? (
            <p className="mx-3 mt-2 text-[10px] font-semibold text-sibs-muted">Checking Helpdesk access…</p>
          ) : null}
          {helpdeskStartError ? (
            <div role="alert" className="mx-3 mt-2 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-[11px] font-semibold text-red-700">
              {helpdeskStartError}
            </div>
          ) : null}

          <div className="sibs-scrollbar min-h-0 flex-1 overflow-y-auto p-2">
            {chat.conversationsLoading && !chat.conversations.length ? (
              <div className="flex items-center gap-2 px-3 py-2 text-[10px] font-semibold text-sibs-muted">
                <Loader2 size={13} className="animate-spin" /> Loading conversations…
              </div>
            ) : null}

            {inboxViewMode === "folders" ? (
              <ChatFolderList
                folders={chatSidebarFolders}
                expandedFolders={expandedChatFolders}
                onFoldersChange={updateChatFolders}
                onHelpdeskContact={handleContactHelpdesk}
                canRequestHelpdesk={canRequestHelpdesk}
                helpdeskStartingCategory={helpdeskStartingCategory}
                helpdeskScopePending={!Array.isArray(requestableHelpdeskCategories)}
              >
                {(conversation, nested) => renderConversationRow(conversation, { nested, showCategoryBadge: false })}
              </ChatFolderList>
            ) : (
              <div className="space-y-0.5" role="list" aria-label="Conversation list">
                {activeCategoryTab === "private" && (
                  <button
                    type="button"
                    onClick={() => setNewChatOpen(true)}
                    className="mb-2 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-sibs-border bg-sibs-surface px-3 py-2 text-[11px] font-bold text-sibs-orange transition hover:border-sibs-orange hover:bg-sibs-cream-light"
                  >
                    <Plus size={14} /> Start private message
                  </button>
                )}
                {activeCategoryTab === "groups" && (
                  <button
                    type="button"
                    onClick={() => setNewChatOpen(true)}
                    className="mb-2 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-sibs-border bg-sibs-surface px-3 py-2 text-[11px] font-bold text-sibs-navy transition hover:border-sibs-navy hover:bg-slate-100"
                  >
                    <Plus size={14} /> Create group chat
                  </button>
                )}
                {activeCategoryTab === "helpdesk" && (
                  <div className="mb-2 grid grid-cols-2 gap-1.5">
                    {canRequestHelpdesk("IT") && (
                      <button
                        type="button"
                        onClick={() => handleContactHelpdesk("IT")}
                        className="flex items-center justify-center gap-1 rounded-xl border border-amber-200 bg-amber-50/70 px-2 py-1.5 text-[10px] font-extrabold text-amber-800 transition hover:bg-amber-100"
                      >
                        <Plus size={13} /> New IT Support
                      </button>
                    )}
                    {canRequestHelpdesk("TA_HR") && (
                      <button
                        type="button"
                        onClick={() => handleContactHelpdesk("TA_HR")}
                        className="flex items-center justify-center gap-1 rounded-xl border border-blue-200 bg-blue-50/70 px-2 py-1.5 text-[10px] font-extrabold text-blue-800 transition hover:bg-blue-100"
                      >
                        <Plus size={13} /> New TA/HR concern
                      </button>
                    )}
                  </div>
                )}

                {activeDisplayConversations.length ? (
                  activeDisplayConversations.map((conversation) =>
                    renderConversationRow(conversation, {
                      nested: false,
                      showCategoryBadge: activeCategoryTab === "all",
                    }),
                  )
                ) : (
                  <div className="flex flex-col items-center justify-center px-4 py-8 text-center">
                    <p className="text-xs font-bold text-sibs-navy">No conversations found</p>
                    <p className="mt-1 text-[11px] text-sibs-muted">
                      {conversationSearch
                        ? "No chats matched your search query."
                        : activeCategoryTab === "private"
                          ? "Start a direct conversation with a colleague."
                          : activeCategoryTab === "groups"
                            ? "Create a group chat to collaborate."
                            : activeCategoryTab === "helpdesk"
                              ? "No Helpdesk cases submitted yet."
                              : "Start a new conversation to get started."}
                    </p>
                  </div>
                )}
              </div>
            )}

            {chatSearchActive && !filteredConversations.length ? (
              <p className="px-3 py-4 text-center text-[11px] font-semibold text-sibs-muted">
                No matching conversations.
              </p>
            ) : null}
          </div>
        </aside>

        <div
          className={`relative flex min-w-0 flex-col bg-white overflow-hidden transition-all duration-200 ${
            isExpanded
              ? "flex-1 h-full"
              : hasActiveMobileView
                ? "w-full flex-1 h-full"
                : "hidden"
          }`}
        >
          {activeConversation ? (
            <>
              <header className={`relative z-30 flex h-[68px] shrink-0 items-center border-b border-white/10 bg-sibs-navy text-white shadow-xs ${
                isExpanded ? "gap-2.5 px-4" : "gap-1.5 px-3"
              }`}>
                <button
                  type="button"
                  onClick={handleBackToList}
                  title="Back to conversations"
                  aria-label="Back to conversations"
                  className={`inline-flex ${isExpanded ? "h-9 w-9" : "h-8 w-8"} shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white ${
                    isExpanded ? "hidden sm:hidden" : ""
                  }`}
                >
                  <ArrowLeft size={18} />
                </button>
                {activeConversation.isHelpdesk ? (
                  <span
                    className={`inline-flex ${isExpanded ? "h-9 w-9" : "h-8 w-8"} shrink-0 items-center justify-center rounded-full border border-white/20 bg-white/10 text-sibs-orange`}
                    aria-hidden="true"
                  >
                    {cleanText(activeConversation.helpdeskCategory).toUpperCase() === "IT"
                      ? <MonitorCog size={18} />
                      : <HeartHandshake size={18} />}
                  </span>
                ) : (
                  <div className="shrink-0 rounded-full ring-1 ring-white/25 bg-white/10">
                    <ChatAvatar
                      employee={activeConversation.isGroup ? null : activeOtherMember}
                      initials={activeConversation.initials}
                      online={activePrivateOnline}
                      group={activeConversation.isGroup}
                      size="sm"
                    />
                  </div>
                )}
                <div className="min-w-0 flex-1 flex flex-col justify-center">
                  <h3 className={`truncate font-heading font-extrabold text-white leading-tight ${isExpanded ? "text-base" : "text-sm"}`}>
                    {activeConversation.isHelpdesk
                      ? getPersonalHelpdeskChatTitle(activeConversation.helpdeskCategory)
                      : activeConversation.title}
                  </h3>
                  {activeConversation.isHelpdesk ? (
                    <p className="mt-0.5 truncate text-[10px] font-semibold text-white/75 whitespace-nowrap">
                      Your request · {getHelpdeskCaseLabel(activeConversation)}
                    </p>
                  ) : activeConversation.isGroup ? (
                    <button
                      type="button"
                      onClick={() => setGroupInfoOpen(true)}
                      title="View group members"
                      className="mt-0.5 inline-flex items-center gap-1 text-left text-[10px] font-semibold text-white/75 transition hover:text-white truncate whitespace-nowrap"
                    >
                      <span className="truncate whitespace-nowrap">
                        {activeConversation.members?.length || 0} member
                        {(activeConversation.members?.length || 0) === 1 ? "" : "s"}
                      </span>
                    </button>
                  ) : (
                    <p className="mt-0.5 truncate text-[10px] font-semibold text-white/75 whitespace-nowrap">
                      {activePrivateStatus}
                    </p>
                  )}
                </div>
                <div className="flex shrink-0 items-center gap-0.5 sm:gap-1">
                  <button
                    type="button"
                    onClick={() => setThemeModalOpen(true)}
                    title="Chat theme & wallpaper"
                    aria-label="Chat theme & wallpaper"
                    className={`inline-flex ${isExpanded ? "h-9 w-9" : "h-8 w-8"} items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white`}
                  >
                    <Palette size={16} />
                  </button>
                {activeConversation.isHelpdesk ? (
                  activeConversation.caseCode ? (
                    <div className="relative shrink-0" ref={helpdeskStatusMenuRef}>
                      <button
                        type="button"
                        aria-label={`Case status: ${helpdeskCaseStatusLabel}${canChangeHelpdeskStatus ? '. Change status' : ''}`}
                        aria-haspopup={canChangeHelpdeskStatus ? 'menu' : undefined}
                        aria-expanded={canChangeHelpdeskStatus ? helpdeskStatusMenuOpen : undefined}
                        title={canChangeHelpdeskStatus
                          ? 'Update this case status'
                          : ['RESOLVED', 'REJECTED'].includes(helpdeskCaseStatus)
                            ? 'This case is closed'
                            : helpdeskStatusLoading
                              ? 'Checking the accepted support employee…'
                              : 'Only the support employee who accepted this request can change its status'}
                        disabled={!canChangeHelpdeskStatus}
                        onClick={() => {
                          setHelpdeskStatusMenuOpen((previous) => !previous);
                          setHelpdeskCloseConfirm(false);
                        }}
                        className={`inline-flex min-h-8 ${isExpanded ? "max-w-[140px]" : "max-w-[105px]"} items-center gap-1 rounded-lg border px-2 py-1 text-[10px] font-extrabold transition focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white disabled:cursor-default ${
                          helpdeskCaseStatus === 'RESOLVED'
                            ? 'border-emerald-300/60 bg-emerald-900/40 text-emerald-100'
                            : helpdeskCaseStatus === 'PENDING'
                              ? 'border-amber-300/60 bg-amber-950/30 text-amber-100'
                              : 'border-white/35 bg-white/10 text-white'
                        } ${canChangeHelpdeskStatus ? 'hover:bg-white/20' : ''}`}
                      >
                        {helpdeskStatusSaving || helpdeskStatusLoading ? (
                          <Loader2 size={12} className="shrink-0 animate-spin" />
                        ) : ['RESOLVED', 'REJECTED'].includes(helpdeskCaseStatus) ? (
                          <CheckCircle2 size={12} className="shrink-0" />
                        ) : null}
                        <span className="min-w-0 truncate">{helpdeskCaseStatusLabel}</span>
                        {canChangeHelpdeskStatus ? <ChevronDown size={12} className="shrink-0" /> : null}
                      </button>
                      {helpdeskStatusMenuOpen && canChangeHelpdeskStatus ? (
                        <div
                          role="menu"
                          aria-label="Update case status"
                          className="absolute right-0 top-full z-50 mt-2 w-[230px] max-w-[85vw] rounded-xl border border-sibs-border bg-white p-2 text-sibs-navy shadow-[0_14px_38px_rgba(4,44,81,0.25)]"
                        >
                          <>
                              <p className="px-2 pb-1 pt-0.5 text-[10px] font-extrabold uppercase tracking-wide text-sibs-muted">Change status</p>
                              {[
                                ['IN_PROGRESS', 'In Progress'],
                                ['PENDING', 'Pending'],
                                ['RESOLVED', 'Case Closed'],
                              ].map(([status, label]) => (
                                <button
                                  key={status}
                                  type="button"
                                  role="menuitem"
                                  disabled={helpdeskStatusSaving || status === helpdeskCaseStatus}
                                  onClick={() => {
                                    if (status === 'RESOLVED') {
                                      setHelpdeskStatusMenuOpen(false);
                                      setHelpdeskCloseConfirm(true);
                                    } else void changeHelpdeskCaseStatus(status);
                                  }}
                                  className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[11px] font-bold transition disabled:cursor-default ${
                                    status === 'RESOLVED'
                                      ? 'text-sibs-orange hover:bg-orange-50'
                                      : 'text-sibs-navy hover:bg-sibs-surface'
                                  } ${status === helpdeskCaseStatus ? 'bg-sibs-surface opacity-60' : ''}`}
                                >
                                  {status === 'RESOLVED' ? <CheckCircle2 size={14} /> : <span className="h-3.5 w-3.5 rounded-full border-2 border-current" />}
                                  <span className="flex-1">{label}</span>
                                  {status === helpdeskCaseStatus ? <Check size={13} /> : null}
                                </button>
                              ))}
                          </>
                        </div>
                      ) : null}
                    </div>
                  ) : null
                ) : activeConversation.isGroup ? (
                  <button
                    type="button"
                    onClick={() => setGroupInfoOpen(true)}
                    title="Group info"
                    aria-label="Group info"
                    className={`inline-flex ${isExpanded ? "h-9 w-9" : "h-8 w-8"} items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white`}
                  >
                    <Settings2 size={16} />
                  </button>
                ) : (
                  <span className={`inline-flex ${isExpanded ? "h-9 w-9" : "h-8 w-8"} items-center justify-center rounded-lg text-white/40`}>
                    <MoreHorizontal size={17} />
                  </span>
                )}
                  <button
                    type="button"
                    onClick={handleMinimize}
                    title="Minimize chat"
                    aria-label="Minimize chat"
                    className={`inline-flex ${isExpanded ? "h-9 w-9" : "h-8 w-8"} shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white`}
                  >
                    <Minus size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={toggleExpanded}
                    title={isExpanded ? "Restore compact size" : "Expand chat"}
                    aria-label={isExpanded ? "Restore compact size" : "Expand chat"}
                    aria-expanded={isExpanded}
                    aria-controls="sibs-chat-panel"
                    className={`hidden ${isExpanded ? "h-9 w-9" : "h-8 w-8"} shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white sm:inline-flex`}
                  >
                    {isExpanded ? <Minimize2 size={15} /> : <Maximize2 size={15} />}
                  </button>
                  <button
                    type="button"
                    onClick={handleClose}
                    title="Close SiBS Chat"
                    aria-label="Close SiBS Chat"
                    className={`inline-flex ${isExpanded ? "h-9 w-9" : "h-8 w-8"} shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white`}
                  >
                    <X size={16} />
                  </button>
                </div>
              </header>


              {activeConversation.isHelpdesk &&
                cleanText(activeConversation.createdBySibsId) !== currentSibsId ? (
                <div className="shrink-0 border-b border-emerald-100 bg-emerald-50 px-3 py-2 text-[11px] sm:px-4">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-extrabold text-emerald-800">Support on duty</span>
                    <button
                      type="button"
                      onClick={() => setGroupInfoOpen(true)}
                      className="shrink-0 rounded-lg px-2 py-1 font-extrabold text-emerald-800 hover:bg-emerald-100"
                    >
                      All members
                    </button>
                  </div>
                  <div id="sibs-chat-helpdesk-duty-grid" className="mt-1.5 grid grid-cols-3 items-stretch gap-2">
                    {helpdeskDutyLoading && !visibleHelpdeskDuty ? (
                      <span className="col-span-3 font-semibold text-sibs-muted">Checking Kronos attendance…</span>
                    ) : helpdeskDutyError && !visibleHelpdeskDuty ? (
                      <span className="col-span-3 font-semibold text-sibs-muted">Attendance temporarily unavailable</span>
                    ) : onDutySupportMembers.length ? (
                      <>
                        {(dutyRosterExpanded ? onDutySupportMembers : onDutySupportMembers.slice(0, 3)).map((member) => (
                          <span
                            key={member.sibsId}
                            className="flex min-w-0 items-start gap-1.5 rounded-lg border border-emerald-100 bg-white/80 px-2 py-1.5"
                          >
                            <ChatAvatar
                              employee={member}
                              initials={member.initials || cleanText(member.sibsId).slice(0, 2)}
                              size="chat"
                            />
                            <span className="flex min-w-0 flex-1 flex-col gap-1">
                              <span className="min-w-0 break-words text-[10px] font-semibold leading-snug text-sibs-navy">
                                {getChatMemberFullName(member)}
                              </span>
                              <span className="flex min-w-0 items-start gap-1 break-words text-[10px] font-semibold leading-tight text-sibs-muted">
                                <MapPin size={11} className="mt-px shrink-0" />
                                <span>Assigned: {member.assignedLocationLabel || "Not assigned"}</span>
                              </span>
                            </span>
                          </span>
                        ))}
                      </>
                    ) : (
                      <span className="col-span-3 font-semibold text-sibs-muted">No clocked-in support staff confirmed</span>
                    )}
                  </div>
                  {onDutySupportMembers.length > 3 ? (
                    <button
                      type="button"
                      onClick={() => setDutyRosterExpanded((expanded) => !expanded)}
                      aria-expanded={dutyRosterExpanded}
                      aria-controls="sibs-chat-helpdesk-duty-grid"
                      className="mx-auto mt-1.5 flex min-h-7 items-center justify-center gap-1.5 rounded-lg px-3 py-1 text-[11px] font-bold text-emerald-800 transition-colors hover:bg-emerald-100 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-emerald-600"
                    >
                      {dutyRosterExpanded ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
                      {dutyRosterExpanded ? "Show less" : `Show ${onDutySupportMembers.length - 3} more`}
                    </button>
                  ) : null}
                </div>
              ) : null}

              {isPersonalHelpdeskRequest ? (
                <>
                  <div className="shrink-0 border-b border-sibs-border bg-sibs-cream-subtle px-4 py-2.5">
                    <p className="text-[11px] font-semibold leading-relaxed text-sibs-navy">
                      <span className="font-extrabold text-sibs-orange">Helpdesk notice: </span>
                      For employees with genuine work-related issues or concerns. Requests outside the team's support scope may be rejected with a reason.
                    </p>
                    {cleanText(activeConversation?.caseStatus).toUpperCase() === "REJECTED" && (
                      <div role="status" className="mt-2 rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-[11px] font-semibold text-rose-800">
                        <strong>Request rejected.</strong> {activeConversation?.caseRejectionReason || "Contact the appropriate support team for your concern."}
                        <span className="mt-1 block text-[10px]">This conversation is archived. Use Helpdesk on the left to start a new request.</span>
                      </div>
                    )}
                  </div>
                  <section className="shrink-0 border-b border-emerald-100 bg-emerald-50/80 px-3 py-2.5 text-[11px] sm:px-4" aria-label="Live support attendance">
                    <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1">
                      <span className="inline-flex items-center gap-1.5 font-extrabold text-sibs-navy">
                        <span className="inline-block h-2 w-2 rounded-full bg-emerald-500" aria-hidden="true" />
                        {cleanText(activeConversation.helpdeskCategory).toUpperCase() === 'IT' ? 'IT Support' : 'TA/HR Support'} on duty
                      </span>
                      <span className="text-[10px] font-semibold text-emerald-800">
                        {visibleHelpdeskDuty
                          ? `${visibleHelpdeskDuty.clockedInCount} clocked in`
                          : helpdeskDutyLoading ? 'Checking attendance…' : 'Attendance not verified'}
                      </span>
                    </div>
                    <div role="status" aria-live="polite" className="mt-1.5">
                      {helpdeskDutyLoading && !visibleHelpdeskDuty ? (
                        <span className="text-[10px] font-semibold text-sibs-muted">Checking Kronos attendance for available support…</span>
                      ) : !visibleHelpdeskDuty ? (
                        <span className="text-[10px] font-semibold text-sibs-muted">Support availability is temporarily unavailable. You can still send your concern.</span>
                      ) : onDutySupportMembers.length ? (
                        <div className="flex flex-wrap items-center gap-1.5">
                          {(dutyRosterExpanded ? onDutySupportMembers : onDutySupportMembers.slice(0, 3)).map((member) => (
                            <span key={member.sibsId} className="inline-flex max-w-full items-center gap-1.5 rounded-lg border border-emerald-200 bg-white px-2 py-1" title={`${getChatMemberFullName(member)} · Clocked in · SiBS ID ${member.sibsId}`}>
                              <span className="min-w-0 max-w-[260px] whitespace-normal break-words text-[10px] font-bold leading-4 text-sibs-navy">
                                {getChatMemberFullName(member)}
                              </span>
                              <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-emerald-500" aria-label="Clocked in" />
                            </span>
                          ))}
                          {onDutySupportMembers.length > 3 && (
                            <button
                              type="button"
                              onClick={() => setDutyRosterExpanded((expanded) => !expanded)}
                              aria-expanded={dutyRosterExpanded}
                              className="rounded-lg px-2 py-1 text-[10px] font-bold text-emerald-800 hover:bg-emerald-100"
                            >
                              {dutyRosterExpanded ? 'Show less' : `+${onDutySupportMembers.length - 3} more`}
                            </button>
                          )}
                        </div>
                      ) : (
                        <span className="text-[10px] font-semibold text-sibs-muted">
                          {visibleHelpdeskDuty.unavailableCount > 0
                            ? 'Some attendance records could not be verified. Current availability is uncertain.'
                            : 'No support members are currently confirmed clocked in. You can still send your concern.'}
                        </span>
                      )}
                    </div>
                    <p className="mt-1.5 text-[9px] font-medium text-sibs-muted">
                      Based on Kronos clock-in without clock-out · refreshes approximately every 30 seconds
                      {helpdeskDutyCheckedAt ? ` · Last checked ${chatClockFormatter.format(new Date(helpdeskDutyCheckedAt))} PHT` : ''}
                      {helpdeskDutyError && visibleHelpdeskDuty ? ' · Latest refresh unavailable' : ''}
                    </p>
                  </section>
                </>
              ) : null}

              {(localError || chat.error) ? (
                <div className="border-b border-red-100 bg-red-50 px-4 py-2 text-[11px] font-semibold text-red-700">
                  {localError || chat.error}
                </div>
              ) : null}

              <div
                data-chat-custom-theme={isCustomTheme ? "true" : "false"}
                data-chat-theme-dark={isThemeDark ? "true" : "false"}
                className={`relative flex min-h-0 flex-1 flex-col overflow-hidden transition-colors duration-300 ${
                  isCustomTheme ? "" : "bg-sibs-canvas"
                }`}
                style={themeBackgroundStyle}
              >
                {isCustomTheme ? (
                  <div
                    className="pointer-events-none absolute inset-0 bg-slate-900/10 dark:bg-slate-950/20 backdrop-blur-[0.5px]"
                    aria-hidden="true"
                  />
                ) : null}

                <div
                  ref={messageScrollRef}
                  onScroll={handleMessagesScroll}
                  className="sibs-scrollbar relative z-10 min-h-0 flex-1 overflow-x-hidden overflow-y-auto px-2.5 py-3 sm:px-5 sm:py-4 [overflow-anchor:auto]"
                >
                {chat.messagesLoading ? (
                  <div className="flex h-full items-center justify-center text-sibs-muted">
                    <Loader2 size={22} className="animate-spin" />
                  </div>
                ) : chat.messages.length ? (
                  <div ref={messagesListContentRef} className="flex flex-col">
                    {chat.hasMoreMessages ? (
                      <div className="mb-3 flex justify-center [overflow-anchor:none]">
                        <button
                          type="button"
                          onClick={() => {
                            const scroller = messageScrollRef.current;
                            if (scroller) {
                              olderMessagesScrollHeightRef.current = scroller.scrollHeight;
                              olderMessagesScrollTopRef.current = scroller.scrollTop;
                            }
                            void chat.loadOlderMessages();
                          }}
                          disabled={chat.loadingOlderMessages}
                          className="inline-flex items-center gap-2 rounded-full border border-sibs-border bg-white px-3 py-1.5 text-[10px] font-extrabold text-sibs-muted shadow-sm transition hover:text-sibs-navy disabled:opacity-50"
                        >
                          {chat.loadingOlderMessages ? (
                            <Loader2 size={12} className="animate-spin" />
                          ) : null}
                          Load earlier messages
                        </button>
                      </div>
                    ) : null}
                    <MemoizedChatMessageRows
                      messages={chat.messages}
                      currentSibsId={currentSibsId}
                      conversationId={activeConversation?.id}
                      caseFirstMessageId={activeConversation?.caseFirstMessageId}
                      caseCode={activeConversation?.caseCode}
                      isGroup={activeConversation?.isGroup}
                      showHelpdeskSenderIdentifiers={activeConversation?.showHelpdeskSenderIdentifiers === true}
                      helpdeskSenderIdentifierSignature={helpdeskSenderIdentifierSignature}
                      membersBySibsId={membersBySibsId}
                      seenMembersByMessageId={seenMembersByMessageId}
                      chatClockMs={chatClockMs}
                      messageActionId={messageActionId}
                      reactionPickerMessageId={reactionPickerMessageId}
                      reactingMessageId={reactingMessageId}
                      unsendingMessageId={unsendingMessageId}
                      renderRows={() => chat.messages.map((message, index) => {
                      const mine = cleanText(message.senderSibsId) === currentSibsId;
                      const previous = chat.messages[index - 1];
                      const next = chat.messages[index + 1];
                      const showDate =
                        !previous || !isSameDay(previous.createdAt, message.createdAt);
                      const prevTimestamp = previous ? new Date(previous.createdAt).getTime() : 0;
                      const currTimestamp = new Date(message.createdAt).getTime();
                      const timeGapMs =
                        prevTimestamp && currTimestamp
                          ? Math.max(0, currTimestamp - prevTimestamp)
                          : 0;
                      const isSignificantGap = timeGapMs >= 15 * 60 * 1000;
                      const shouldShowCenterTime = showDate || isSignificantGap;
                      const isCaseOpeningMessage = Boolean(
                        activeConversation?.isHelpdesk &&
                        activeConversation?.caseCode &&
                        Number(activeConversation?.caseFirstMessageId) > 0 &&
                        Number(activeConversation.caseFirstMessageId) === Number(message.id)
                      );
                      const normalizedMessageType = cleanText(
                        message.messageType,
                      ).toUpperCase();
                      const membershipActivity =
                        normalizedMessageType === "MEMBER_ADDED" ||
                        normalizedMessageType === "MEMBER_REMOVED";
                      const previousMessageType = cleanText(
                        previous?.messageType,
                      ).toUpperCase();
                      const nextMessageType = cleanText(
                        next?.messageType,
                      ).toUpperCase();
                      const previousMembershipActivity =
                        previousMessageType === "MEMBER_ADDED" ||
                        previousMessageType === "MEMBER_REMOVED";
                      const nextMembershipActivity =
                        nextMessageType === "MEMBER_ADDED" ||
                        nextMessageType === "MEMBER_REMOVED";
                      const sameSenderAsPrevious =
                        Boolean(previous) &&
                        !showDate &&
                        !isSignificantGap &&
                        !membershipActivity &&
                        !previousMembershipActivity &&
                        cleanText(previous?.senderSibsId) ===
                          cleanText(message.senderSibsId);
                      const nextTimestamp = next ? new Date(next.createdAt).getTime() : 0;
                      const nextGapMs =
                        nextTimestamp && currTimestamp
                          ? Math.max(0, nextTimestamp - currTimestamp)
                          : 0;
                      const nextSignificantGap = nextGapMs >= 15 * 60 * 1000;
                      const sameSenderAsNext =
                        Boolean(next) &&
                        !membershipActivity &&
                        !nextMembershipActivity &&
                        !nextSignificantGap &&
                        isSameDay(message.createdAt, next?.createdAt) &&
                        cleanText(next?.senderSibsId) ===
                          cleanText(message.senderSibsId);
                      const groupStart = !sameSenderAsPrevious;
                      const groupEnd = !sameSenderAsNext;
                      const showSender =
                        activeConversation.isGroup &&
                        groupStart &&
                        (!mine || activeConversation.showHelpdeskSenderIdentifiers === true);
                      const unsent =
                        Boolean(message.unsent) ||
                        normalizedMessageType === "UNSENT";
                      const canUnsend =
                        mine &&
                        !unsent &&
                        !membershipActivity;
                      const canReact = !unsent && !membershipActivity;
                      const canReply = !unsent && !membershipActivity;
                      const reactions = Array.isArray(message.reactions)
                        ? message.reactions.filter((item) => Number(item?.count || 0) > 0)
                        : [];
                      const myReaction = reactions.find((item) => item?.reactedByMe)?.reaction || "";
                      const gifUrl =
                        !unsent &&
                        cleanText(message.messageType).toUpperCase() === "GIF"
                          ? cleanText(message.gifUrl)
                          : "";
                      const gifOnly = Boolean(gifUrl);
                      const emojiOnly =
                        !unsent &&
                        !gifOnly &&
                        !message.attachments?.length &&
                        isEmojiOnlyMessage(message.messageText);
                      const seenMembers =
                        seenMembersByMessageId.get(Number(message.id)) || [];
                      const senderEmployee =
                        membersBySibsId.get(cleanText(message.senderSibsId)) ||
                        message.sender ||
                        null;
                      const senderDisplayName =
                        cleanText(
                          senderEmployee?.preferredName ||
                            senderEmployee?.preferred_name ||
                            message.sender?.preferredName ||
                            message.sender?.preferred_name,
                        ) ||
                        senderEmployee?.displayName ||
                        message.sender?.displayName ||
                        `SIBS ID ${message.senderSibsId}`;
                      const senderIdentifier = getHelpdeskSenderIdentifier(
                        activeConversation,
                        message.senderSibsId,
                      );
                      const senderInitials =
                        senderEmployee?.initials ||
                        cleanText(senderDisplayName).slice(0, 2).toUpperCase() ||
                        "U";

                      return (
                        <div
                          key={message.id}
                          data-chat-message-id={message.id}
                          className={
                            membershipActivity
                              ? "my-2"
                              : groupStart
                                ? "mt-2.5"
                                : "mt-0.5"
                          }
                        >
                          {shouldShowCenterTime || isCaseOpeningMessage ? (
                            <div className="my-2.5 flex items-center justify-center">
                              <span className="chat-theme-date-pill">
                                {isCaseOpeningMessage
                                  ? `Case Opened #${activeConversation.caseCode.split("-").at(-1)} (${formatHelpdeskCaseOpenedAt(activeConversation.caseOpenedAt || message.createdAt).replace("Today at ", "Today ")})`
                                  : formatMessengerCenterTimestamp(message.createdAt, previous?.createdAt)}
                              </span>
                            </div>
                          ) : null}

                          {membershipActivity ? (
                            <div className="my-2 flex justify-center px-3">
                              <div className="inline-flex max-w-[92%] items-center gap-1.5 rounded-full border border-sibs-border bg-white px-3 py-1.5 text-center text-[10px] font-semibold text-sibs-muted shadow-sm">
                                {normalizedMessageType === "MEMBER_ADDED" ? (
                                  <UserPlus size={12} className="shrink-0 text-sibs-orange" />
                                ) : (
                                  <Trash2 size={12} className="shrink-0 text-sibs-faint" />
                                )}
                                <span className="break-words">
                                  {message.messageText}
                                </span>
                                <span className="shrink-0 text-[9px] text-sibs-faint">
                                  · {formatMessageTime(message.createdAt, chatClockMs)}
                                </span>
                              </div>
                            </div>
                          ) : (
                            <>
                              <div
                                className={`group/message flex items-end gap-2 ${
                                  mine ? "justify-end" : "justify-start"
                                }`}
                              >
                            {/* Avatar on LEFT for incoming messages */}
                            {!mine ? (
                              <div className="flex h-7 w-7 shrink-0 items-end self-end mb-0.5">
                                {groupEnd ? (
                                  <ChatAvatar
                                    employee={senderEmployee}
                                    initials={senderInitials}
                                    size="chat"
                                  />
                                ) : null}
                              </div>
                            ) : null}

                            {/* Message content container */}
                            <div className={`max-w-[88%] sm:max-w-[68%] flex flex-col ${mine ? "items-end" : "items-start"}`}>
                              {showSender ? (
                                <div className={`mb-1 flex max-w-full flex-wrap items-center gap-1.5 ${mine ? "justify-end" : "justify-start"}`}>
                                  <span
                                    className="chat-theme-sender-name min-w-0 truncate"
                                    title={
                                      senderEmployee?.displayName &&
                                      senderEmployee.displayName !== senderDisplayName
                                        ? `Full name: ${senderEmployee.displayName}`
                                        : undefined
                                    }
                                  >
                                    {senderDisplayName}
                                  </span>
                                  {senderIdentifier ? (
                                    <span
                                      className={`inline-flex shrink-0 items-center rounded-md border px-1.5 py-0.5 text-[9px] font-bold leading-none shadow-sm ${
                                        senderIdentifier === "Super Admin"
                                          ? "border-blue-200 bg-blue-50/95 text-sibs-navy"
                                          : senderIdentifier === "Employee"
                                            ? "border-sibs-border bg-white/95 text-sibs-navy"
                                            : senderIdentifier === "Management"
                                              ? "border-slate-200 bg-slate-100/95 text-slate-700"
                                              : "border-orange-200 bg-orange-50/95 text-orange-800"
                                      }`}
                                      title={`Message role: ${senderIdentifier}`}
                                    >
                                      {senderIdentifier}
                                    </span>
                                  ) : null}
                                </div>
                              ) : null}

                              {message.replyTo ? (
                                <button
                                  type="button"
                                  onClick={() => scrollToRepliedMessage(message.replyTo.id)}
                                  className={`mb-1.5 block max-w-full overflow-hidden rounded-xl border-l-[3px] px-2.5 py-2 text-left shadow-sm transition hover:brightness-[0.98] ${
                                    mine
                                      ? "border-sibs-orange bg-orange-50 text-sibs-navy"
                                      : "border-sibs-navy bg-slate-100 text-sibs-navy"
                                  }`}
                                  title="Go to replied message"
                                >
                                  <span className="block truncate text-[9px] font-extrabold text-sibs-orange">
                                    {getReplySenderName(message.replyTo, currentSibsId)}
                                  </span>
                                  <span className="mt-0.5 block truncate text-[10px] font-semibold text-sibs-muted">
                                    {getReplyPreviewLabel(message.replyTo)}
                                  </span>
                                </button>
                              ) : null}

                              {/* Bubble + Actions Flex Row */}
                              <div className={`flex items-center gap-1.5 ${mine ? "justify-end" : "justify-start"}`}>
                                {/* Actions on LEFT for outgoing messages */}
                                {mine && (canReact || canReply || canUnsend) ? (
                                  <div
                                    className={`flex items-center gap-0.5 shrink-0 transition ${
                                      Number(reactionPickerMessageId) === Number(message.id) ||
                                      Number(messageActionId) === Number(message.id) ||
                                      myReaction
                                        ? "opacity-100"
                                        : "opacity-0 group-hover/message:opacity-100 group-focus-within/message:opacity-100"
                                    }`}
                                  >
                                    {canUnsend ? (
                                      <div
                                        className="relative shrink-0"
                                        data-chat-message-actions
                                      >
                                        <button
                                          type="button"
                                          onClick={() =>
                                            setMessageActionId((current) =>
                                              Number(current) === Number(message.id)
                                                ? null
                                                : Number(message.id),
                                            )
                                          }
                                          disabled={
                                            Number(unsendingMessageId) === Number(message.id)
                                          }
                                          className={`chat-theme-action-btn disabled:opacity-40 ${
                                            Number(messageActionId) === Number(message.id)
                                              ? "bg-white text-sibs-navy shadow-sm"
                                              : ""
                                          }`}
                                          title="Message options"
                                          aria-label="Message options"
                                        >
                                          {Number(unsendingMessageId) === Number(message.id) ? (
                                            <Loader2 size={14} className="animate-spin" />
                                          ) : (
                                            <MoreHorizontal size={15} />
                                          )}
                                        </button>

                                        {Number(messageActionId) === Number(message.id) ? (
                                          <div className="absolute bottom-full right-0 z-30 mb-1 min-w-[118px] rounded-xl border border-sibs-border bg-white p-1.5 shadow-xl">
                                            <button
                                              type="button"
                                              onClick={() => void handleUnsendMessage(message)}
                                              className="flex w-full items-center rounded-lg px-3 py-2 text-left text-[11px] font-extrabold text-sibs-navy transition hover:bg-sibs-surface"
                                            >
                                              Unsend message
                                            </button>
                                          </div>
                                        ) : null}
                                      </div>
                                    ) : null}

                                    {canReply ? (
                                      <button
                                        type="button"
                                        onClick={() => handleReplyMessage(message)}
                                        className="chat-theme-action-btn shrink-0"
                                        title="Reply"
                                        aria-label="Reply to message"
                                      >
                                        <Reply size={15} />
                                      </button>
                                    ) : null}

                                    {canReact ? (
                                      <div
                                        className="relative shrink-0"
                                        data-chat-reaction-picker
                                      >
                                        <button
                                          type="button"
                                          onClick={() =>
                                            setReactionPickerMessageId((current) =>
                                              Number(current) === Number(message.id)
                                                ? null
                                                : Number(message.id),
                                            )
                                          }
                                          disabled={
                                            Number(reactingMessageId) === Number(message.id)
                                          }
                                          className={`chat-theme-action-btn disabled:opacity-40 ${
                                            Number(reactionPickerMessageId) === Number(message.id) || myReaction
                                              ? "bg-white text-sibs-orange shadow-sm"
                                              : ""
                                          }`}
                                          title={myReaction ? `Your reaction: ${myReaction}` : "React"}
                                          aria-label="React to message"
                                        >
                                          {Number(reactingMessageId) === Number(message.id) ? (
                                            <Loader2 size={14} className="animate-spin" />
                                          ) : myReaction ? (
                                            <span className="text-sm leading-none">{myReaction}</span>
                                          ) : (
                                            <Smile size={15} />
                                          )}
                                        </button>

                                        {Number(reactionPickerMessageId) === Number(message.id) ? (
                                          <div className="absolute bottom-full right-0 z-40 mb-1 grid w-[224px] grid-cols-6 gap-1 rounded-2xl border border-sibs-border bg-white p-2 shadow-xl">
                                            {MESSAGE_REACTIONS.map((reaction) => (
                                              <button
                                                key={reaction}
                                                type="button"
                                                onClick={() => void handleMessageReaction(message, reaction)}
                                                disabled={
                                                  Number(reactingMessageId) === Number(message.id)
                                                }
                                                className={`inline-flex h-8 w-8 items-center justify-center rounded-full text-lg leading-none transition hover:scale-110 hover:bg-sibs-surface disabled:opacity-40 ${
                                                  myReaction === reaction
                                                    ? "bg-sibs-cream-light ring-1 ring-sibs-orange/40"
                                                    : ""
                                                }`}
                                                title={
                                                  myReaction === reaction
                                                    ? `Remove ${reaction} reaction`
                                                    : `React ${reaction}`
                                                }
                                              >
                                                {reaction}
                                              </button>
                                            ))}
                                          </div>
                                        ) : null}
                                      </div>
                                    ) : null}
                                  </div>
                                ) : null}

                                {unsent ? (
                                <div
                                  title={formatMessageTime(message.createdAt, chatClockMs)}
                                  className="rounded-2xl border border-sibs-border bg-white px-3 py-2 text-[11px] font-semibold italic text-sibs-muted"
                                >
                                  {mine
                                    ? "You unsent a message"
                                    : "This message was unsent"}
                                </div>
                              ) : gifOnly ? (
                                <button
                                  type="button"
                                  onClick={() =>
                                    window.open(gifUrl, "_blank", "noopener,noreferrer")
                                  }
                                  className="block max-w-full overflow-hidden rounded-2xl bg-slate-100 shadow-sm"
                                  title={formatMessageTime(message.createdAt, chatClockMs)}
                                >
                                  <img
                                    src={gifUrl}
                                    alt="GIF"
                                    className="max-h-64 w-auto max-w-full object-contain"
                                    loading="lazy"
                                    onLoad={() => {
                                      if (shouldSnapToBottom(isInitialConversationLoadRef.current, isNearBottomRef.current)) {
                                        scrollToLatest();
                                      }
                                    }}
                                  />
                                </button>
                              ) : emojiOnly ? (
                                <div
                                  title={formatMessageTime(message.createdAt, chatClockMs)}
                                  className="px-0.5 py-0.5"
                                >
                                  <p
                                    className={`leading-none ${getEmojiOnlySizeClass(
                                      message.messageText,
                                    )}`}
                                    aria-label={message.messageText}
                                  >
                                    {message.messageText}
                                  </p>
                                </div>
                              ) : (
                                <div
                                  title={formatMessageTime(message.createdAt, chatClockMs)}
                                  className={`overflow-hidden min-w-[34px] ${getMessageBubbleRadiusClass({
                                    mine,
                                    groupStart,
                                    groupEnd,
                                  })} ${
                                    mine
                                      ? "bg-sibs-orange text-white"
                                      : "border border-sibs-border bg-white text-sibs-navy shadow-xs"
                                  } ${message.attachments?.length ? "p-1.5" : "px-3 py-2"}`}
                                >
                                  {message.attachments?.length ? (
                                    <div className={`grid gap-1 ${message.attachments.length > 1 ? "grid-cols-2" : "grid-cols-1"}`}>
                                      {message.attachments.map((attachment) => {
                                        const attachmentUrl = getChatAttachmentUrl(attachment.url);
                                        const attachmentMimeType = cleanText(attachment.mimeType)
                                          .toLowerCase();
                                        const isVideo = attachmentMimeType.startsWith("video/");
                                        const isAudio = attachmentMimeType.startsWith("audio/");
                                        const isDocument = !isChatHeicImage(attachment) && isChatDocumentMime(attachmentMimeType);

                                        if (isDocument) {
                                          const isExcel = /spreadsheet|ms-excel|text\/csv/.test(attachmentMimeType);
                                          const AttachmentIcon = isExcel ? FileSpreadsheet : FileText;
                                          return (
                                            <div key={attachment.id}
                                              className="col-span-full flex w-full min-w-0 flex-wrap items-center gap-2 rounded-xl border border-sibs-border bg-white px-3 py-2.5 text-sibs-navy">
                                              <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-blue-50 text-sibs-navy">
                                                <AttachmentIcon size={20} />
                                              </span>
                                              <span className="min-w-0 flex-1">
                                                <span className="block truncate text-xs font-bold" title={attachment.originalName || "Document"}>{attachment.originalName || "Document"}</span>
                                                <span className="block text-[10px] text-sibs-muted">{(Number(attachment.fileSize || 0) / 1024 / 1024).toFixed(2)} MB</span>
                                              </span>
                                              <div className="flex shrink-0 items-center gap-1.5" role="group" aria-label={`${attachment.originalName || "Document"} options`}>
                                                <button type="button" onClick={() => setDocumentPreview({ ...attachment, downloadUrl: attachmentUrl })}
                                                  className="inline-flex h-8 items-center gap-1 rounded-lg border border-blue-200 bg-blue-50 px-2 text-[11px] font-bold text-sibs-navy transition hover:border-sibs-orange hover:bg-orange-50"
                                                  title="Preview file" aria-label={`View ${attachment.originalName || "document"} in SiBS Chat`}>
                                                  <Eye size={14} /> View
                                                </button>
                                                <a href={attachmentUrl} target="_blank" rel="noopener noreferrer"
                                                  download={attachment.originalName || undefined}
                                                  className="inline-flex h-8 items-center gap-1 rounded-lg border border-orange-200 bg-orange-50 px-2 text-[11px] font-bold text-sibs-orange transition hover:bg-orange-100"
                                                  title="Download original file" aria-label={`Download ${attachment.originalName || "document"}`}>
                                                  <Download size={14} /> Download
                                                </a>
                                              </div>
                                            </div>
                                          );
                                        }

                                        if (isVideo) {
                                          return (
                                            <ChatVideoPlayer
                                              key={attachment.id}
                                              attachment={attachment}
                                            />
                                          );
                                        }

                                        if (isAudio) {
                                          return (
                                            <ChatAudioPlayer
                                              key={attachment.id}
                                              attachment={attachment}
                                              mine={mine}
                                            />
                                          );
                                        }

                                        return (
                                          <button
                                            key={attachment.id}
                                            type="button"
                                            onClick={() => setDocumentPreview({ ...attachment, downloadUrl: attachmentUrl })}
                                            className="overflow-hidden rounded-xl bg-slate-100 transition hover:opacity-95"
                                            title={attachment.originalName || "View image"}
                                            aria-label={`View ${attachment.originalName || "image"} in SiBS Chat`}
                                          >
                                            {isChatHeicImage(attachment) ? (
                                              <ChatHeicThumbnail
                                                attachmentId={attachment.id}
                                                alt={attachment.originalName || "HEIC image"}
                                                className="max-h-56 w-full object-cover"
                                              />
                                            ) : (
                                              <img
                                                src={attachmentUrl}
                                                alt={attachment.originalName || "Chat attachment"}
                                                className="max-h-56 w-full object-cover"
                                                loading="lazy"
                                                onLoad={() => {
                                                  if (shouldSnapToBottom(isInitialConversationLoadRef.current, isNearBottomRef.current)) {
                                                    scrollToLatest();
                                                  }
                                                }}
                                              />
                                            )}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  ) : null}

                                  {message.messageText ? (
                                    <p className={`whitespace-pre-wrap break-words text-xs font-semibold leading-5 ${message.attachments?.length ? "px-1.5 pb-1 pt-2" : ""}`}>
                                      {renderChatMessageText(
                                        message.messageText,
                                        activeConversation?.members || [],
                                        mine,
                                      )}
                                    </p>
                                  ) : null}
                                </div>
                              )}

                              {/* Actions on RIGHT for incoming messages */}
                              {!mine && (canReact || canReply) ? (
                                <div
                                  className={`flex items-center gap-0.5 shrink-0 transition ${
                                    Number(reactionPickerMessageId) === Number(message.id) ||
                                    Number(messageActionId) === Number(message.id) ||
                                    myReaction
                                      ? "opacity-100"
                                      : "opacity-0 group-hover/message:opacity-100 group-focus-within/message:opacity-100"
                                  }`}
                                >
                                  {canReact ? (
                                    <div
                                      className="relative shrink-0"
                                      data-chat-reaction-picker
                                    >
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setReactionPickerMessageId((current) =>
                                            Number(current) === Number(message.id)
                                              ? null
                                              : Number(message.id),
                                          )
                                        }
                                        disabled={
                                          Number(reactingMessageId) === Number(message.id)
                                        }
                                        className={`inline-flex h-7 w-7 items-center justify-center rounded-full transition hover:bg-white hover:text-sibs-orange hover:shadow-sm disabled:opacity-40 ${
                                          Number(reactionPickerMessageId) === Number(message.id) || myReaction
                                            ? "bg-white text-sibs-orange shadow-sm"
                                            : "text-sibs-faint"
                                        }`}
                                        title={myReaction ? `Your reaction: ${myReaction}` : "React"}
                                        aria-label="React to message"
                                      >
                                        {Number(reactingMessageId) === Number(message.id) ? (
                                          <Loader2 size={14} className="animate-spin" />
                                        ) : myReaction ? (
                                          <span className="text-sm leading-none">{myReaction}</span>
                                        ) : (
                                          <Smile size={15} />
                                        )}
                                      </button>

                                      {Number(reactionPickerMessageId) === Number(message.id) ? (
                                        <div className="absolute bottom-full left-0 z-40 mb-1 grid w-[224px] grid-cols-6 gap-1 rounded-2xl border border-sibs-border bg-white p-2 shadow-xl">
                                          {MESSAGE_REACTIONS.map((reaction) => (
                                            <button
                                              key={reaction}
                                              type="button"
                                              onClick={() => void handleMessageReaction(message, reaction)}
                                              disabled={
                                                Number(reactingMessageId) === Number(message.id)
                                              }
                                              className={`inline-flex h-8 w-8 items-center justify-center rounded-full text-lg leading-none transition hover:scale-110 hover:bg-sibs-surface disabled:opacity-40 ${
                                                myReaction === reaction
                                                  ? "bg-sibs-cream-light ring-1 ring-sibs-orange/40"
                                                  : ""
                                              }`}
                                              title={
                                                myReaction === reaction
                                                  ? `Remove ${reaction} reaction`
                                                  : `React ${reaction}`
                                              }
                                            >
                                              {reaction}
                                            </button>
                                          ))}
                                        </div>
                                      ) : null}
                                    </div>
                                  ) : null}

                                  {canReply ? (
                                    <button
                                      type="button"
                                      onClick={() => handleReplyMessage(message)}
                                      className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sibs-faint transition hover:bg-white hover:text-sibs-navy hover:shadow-sm"
                                      title="Reply"
                                      aria-label="Reply to message"
                                    >
                                      <Reply size={15} />
                                    </button>
                                  ) : null}
                                </div>
                              ) : null}
                            </div>

                              {reactions.length ? (
                                <div
                                  className={`mt-1 flex flex-wrap items-center gap-1 ${
                                    mine ? "justify-end" : "justify-start"
                                  }`}
                                >
                                  {reactions.map((item) => {
                                    const reactedBy = getReactionPeopleLabel(item);

                                    return (
                                      <div
                                        key={item.reaction}
                                        className="group/reaction relative"
                                      >
                                        <button
                                          type="button"
                                          onClick={() => void handleMessageReaction(message, item.reaction)}
                                          disabled={
                                            Number(reactingMessageId) === Number(message.id)
                                          }
                                          className={`inline-flex h-6 items-center gap-1 rounded-full border bg-white px-2 text-[10px] font-bold shadow-sm transition hover:border-sibs-orange/50 disabled:opacity-40 ${
                                            item.reactedByMe
                                              ? "border-sibs-orange/40 bg-sibs-cream-subtle text-sibs-orange"
                                              : "border-sibs-border text-sibs-muted"
                                          }`}
                                          aria-label={`${item.reaction} reacted by ${reactedBy}`}
                                        >
                                          <span className="text-sm leading-none">{item.reaction}</span>
                                          {Number(item.count || 0) > 1 ? (
                                            <span>{Number(item.count || 0)}</span>
                                          ) : null}
                                        </button>

                                        <div
                                          role="tooltip"
                                          className={`pointer-events-none absolute bottom-full z-50 mb-2 hidden w-max max-w-[220px] whitespace-normal break-words rounded-lg bg-sibs-navy px-2.5 py-1.5 text-center text-[10px] font-semibold leading-4 text-white shadow-xl group-hover/reaction:block ${
                                            mine ? "right-0" : "left-0"
                                          }`}
                                        >
                                          <span className="mr-1">{item.reaction}</span>
                                          <span>{reactedBy}</span>
                                        </div>
                                      </div>
                                    );
                                  })}
                                </div>
                              ) : null}

                            </div>
                          </div>

                          {(mine || activeConversation?.isGroup) && seenMembers.length ? (
                            <div
                              className="mt-1 flex items-center justify-end"
                              title={`Seen by ${seenMembers
                                .map((member) =>
                                  cleanText(
                                    member?.preferredName ||
                                      member?.preferred_name ||
                                      member?.displayName ||
                                      member?.sibsId,
                                  ),
                                )
                                .filter(Boolean)
                                .join(", ")}`}
                            >
                              <span className="flex items-center -space-x-1.5">
                                {seenMembers.slice(0, 5).map((member) => {
                                  const memberName = cleanText(
                                    member?.preferredName ||
                                      member?.preferred_name ||
                                      member?.displayName ||
                                      member?.sibsId,
                                  );

                                  return (
                                    <span
                                      key={`seen-${message.id}-${member.sibsId}`}
                                      className="relative inline-flex rounded-full ring-1 ring-sibs-canvas"
                                      title={memberName}
                                    >
                                      <ChatAvatar
                                        employee={member}
                                        initials={
                                          member?.initials ||
                                          cleanText(member?.sibsId)
                                            .slice(0, 2)
                                            .toUpperCase() ||
                                          "U"
                                        }
                                        online={false}
                                        size="xs"
                                      />
                                    </span>
                                  );
                                })}
                                {seenMembers.length > 5 ? (
                                  <span className="relative z-10 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full border border-sibs-canvas bg-sibs-navy px-1 text-[7px] font-extrabold text-white">
                                    +{seenMembers.length - 5}
                                  </span>
                                ) : null}
                              </span>
                            </div>
                          ) : null}
                        </>
                      )}
                        </div>
                      );
                    })}
                    />
                    {/* Derived from the authoritative ticket resolution record. Do not
                        create a chat message: that would alter unread counts and case
                        history. The existing conversation sync updates this event for
                        both the requester and support staff automatically. */}
                    {activeConversation?.isHelpdesk &&
                    activeConversation?.caseCode &&
                    cleanText(activeConversation?.caseStatus).toUpperCase() === "RESOLVED" ? (
                      <div
                        role="status"
                        aria-live="polite"
                        data-helpdesk-case-closed={activeConversation.caseCode}
                        className="my-3 flex items-center justify-center px-3 [overflow-anchor:none]"
                      >
                        <span className="chat-theme-date-pill inline-flex items-center gap-1.5 text-center">
                          <Check size={12} aria-hidden="true" />
                          {`Case #${Number(activeConversation.caseCode.split("-").at(-1)) || activeConversation.caseCode} Closed${activeConversation.caseResolvedAt ? ` (${formatHelpdeskCaseOpenedAt(activeConversation.caseResolvedAt).replace("Today at ", "Today ")})` : ""}`}
                        </span>
                      </div>
                    ) : null}
                    <ChatTypingIndicator
                      activeTypingMembers={activeTypingMembers}
                      typingLabel={typingLabel}
                      renderAvatar={(member) => (
                        <ChatAvatar
                          employee={member}
                          initials={member?.initials}
                          online={
                            chat.presence?.[member?.sibsId] ??
                            member?.online ??
                            false
                          }
                          size="xs"
                        />
                      )}
                      className="mt-2"
                    />
                    <div
                      ref={messageEndRef}
                      aria-hidden="true"
                      className="h-px w-full"
                    />
                  </div>
                ) : (
                  <div className="flex h-full items-center justify-center text-center">
                    <div className="chat-theme-empty-content mx-auto">
                      {activeConversation.isHelpdesk ? (
                        <span
                          className="mx-auto inline-flex h-12 w-12 items-center justify-center rounded-full bg-sibs-navy text-white"
                          aria-hidden="true"
                        >
                          {cleanText(activeConversation.helpdeskCategory).toUpperCase() === "IT"
                            ? <MonitorCog size={21} />
                            : <HeartHandshake size={21} />}
                        </span>
                      ) : (
                        <ChatAvatar
                          employee={activeConversation.isGroup ? null : activeOtherMember}
                          initials={activeConversation.initials}
                          online={activePrivateOnline}
                          group={activeConversation.isGroup}
                          size="lg"
                        />
                      )}
                      <p className="chat-theme-empty-title mt-3 text-sm font-extrabold text-sibs-navy">
                        {activeConversation.isHelpdesk
                          ? getPersonalHelpdeskChatTitle(activeConversation.helpdeskCategory)
                          : activeConversation.title}
                      </p>
                      {!activeConversation.isHelpdesk &&
                      !activeConversation.isGroup &&
                      activePrivateNickname &&
                      activePrivateFullName &&
                      activePrivateNickname !== activePrivateFullName ? (
                        <p className="chat-theme-empty-subtitle mt-1 text-[11px] font-semibold text-sibs-muted">
                          {activePrivateFullName}
                        </p>
                      ) : null}
                      <p className="chat-theme-empty-subtitle mt-1 text-[11px] font-semibold text-sibs-muted">
                        Start the conversation.
                      </p>
                      <ChatTypingIndicator
                        activeTypingMembers={activeTypingMembers}
                        typingLabel={typingLabel}
                        renderAvatar={(member) => (
                          <ChatAvatar
                            employee={member}
                            initials={member?.initials}
                            online={
                              chat.presence?.[member?.sibsId] ??
                              member?.online ??
                              false
                            }
                            size="xs"
                          />
                        )}
                        className="mt-4 justify-center"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

              <footer className={`shrink-0 border-t border-sibs-border bg-white ${isExpanded ? "px-3.5 py-3" : "px-2.5 py-2.5"} max-sm:px-2 max-sm:py-2 max-sm:pb-[max(0.5rem,env(safe-area-inset-bottom))]`}>
                {attachmentNotice ? (
                  <div
                    role="alert"
                    className="mb-2 flex items-start justify-between gap-3 rounded-xl border border-red-200 bg-red-50 px-3 py-2 text-[10px] font-semibold leading-4 text-red-700 shadow-sm"
                  >
                    <span className="min-w-0 flex-1">
                      {attachmentNotice}
                    </span>
                    <button
                      type="button"
                      onClick={() => setAttachmentNotice("")}
                      className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-red-500 transition hover:bg-red-100 hover:text-red-700"
                      aria-label="Dismiss file size notification"
                      title="Dismiss"
                    >
                      <X size={13} />
                    </button>
                  </div>
                ) : null}

                {replyingToMessage ? (
                  <div className="mb-2 flex items-center gap-2 rounded-xl border border-sibs-border bg-sibs-surface px-3 py-2">
                    <div className="min-w-0 flex-1 border-l-[3px] border-sibs-orange pl-2.5">
                      <p className="truncate text-[10px] font-extrabold text-sibs-orange">
                        Replying to {getReplySenderName(replyingToMessage, currentSibsId)}
                      </p>
                      <p className="mt-0.5 truncate text-[10px] font-semibold text-sibs-muted">
                        {getReplyPreviewLabel(replyingToMessage)}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setReplyingToMessage(null)}
                      aria-label="Cancel reply"
                      title="Cancel reply"
                      className="inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-lg text-sibs-faint transition hover:bg-white hover:text-sibs-navy"
                    >
                      <X size={14} />
                    </button>
                  </div>
                ) : null}

                {attachmentsLoading ? (
                  <p role="status" className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold text-sibs-muted">
                    <Loader2 size={13} className="animate-spin" /> Preparing attachments…
                  </p>
                ) : null}
                {selectedImages.length ? (
                  <div className="mb-2 flex gap-2 overflow-x-auto pb-1" aria-label="Attachments waiting to be sent">
                    {selectedImages.map((item, index) => {
                      const isAudio = cleanText(item.detectedMimeType || item.file.type).toLowerCase().startsWith("audio/");
                      const isVideo = cleanText(item.detectedMimeType || item.file.type).toLowerCase().startsWith("video/");
                      const isDocument = isChatDocumentMime(item.detectedMimeType || item.file.type);

                      if (isDocument) {
                        const isExcel = /\.(?:xls|xlsx|csv)$/i.test(item.file.name);
                        const AttachmentIcon = isExcel ? FileSpreadsheet : FileText;
                        return (
                          <div key={`${item.file.name}-${index}`}
                            className="relative flex h-16 min-w-[200px] max-w-[270px] shrink-0 items-center gap-2 rounded-xl border border-sibs-border bg-white px-3 py-2 pr-7 shadow-xs">
                            <AttachmentIcon className="h-8 w-8 shrink-0 text-sibs-navy" />
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-xs font-bold text-sibs-navy" title={item.file.name}>{item.file.name}</p>
                              <p className="text-[10px] font-semibold text-sibs-muted">{(item.file.size / 1024 / 1024).toFixed(2)} MB · Document</p>
                            </div>
                            <button type="button" onClick={() => removeSelectedImage(index)} aria-label={`Remove ${item.file.name}`}
                              className="absolute right-1.5 top-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-900/60 text-white hover:bg-slate-900"><X size={11} /></button>
                          </div>
                        );
                      }

                      if (isAudio) {
                        return (
                          <div
                            key={`${item.file.name}-${index}`}
                            className="relative flex h-16 min-w-[200px] max-w-[260px] shrink-0 items-center gap-2.5 rounded-xl border border-sibs-border bg-white px-3 py-2 shadow-xs"
                          >
                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-orange-50 text-sibs-orange">
                              <Music size={18} />
                            </div>
                            <div className="min-w-0 flex-1">
                              <p className="truncate text-xs font-bold text-sibs-navy" title={item.file.name}>
                                {item.file.name}
                              </p>
                              <p className="text-[10px] font-semibold text-sibs-muted">
                                {(item.file.size / 1024 / 1024).toFixed(2)} MB · Audio
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => removeSelectedImage(index)}
                              className="absolute right-1.5 top-1.5 inline-flex h-5 w-5 items-center justify-center rounded-full bg-slate-900/60 text-white hover:bg-slate-900 transition"
                            >
                              <X size={11} />
                            </button>
                          </div>
                        );
                      }

                      return (
                        <div
                          key={`${item.file.name}-${index}`}
                          className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border border-sibs-border bg-sibs-surface"
                        >
                          {isVideo ? (
                            <video
                              src={item.previewUrl}
                              muted
                              playsInline
                              preload="metadata"
                              className="h-full w-full bg-black object-cover"
                            />
                          ) : isChatHeicImage(item.file) ? (
                            <ChatHeicThumbnail file={item.file} alt={item.file.name} className="h-full w-full object-cover" />
                          ) : (
                            <img
                              src={item.previewUrl}
                              alt={item.file.name}
                              className="h-full w-full object-cover"
                            />
                          )}
                          <button
                            type="button"
                            onClick={() => removeSelectedImage(index)}
                            className="absolute right-1 top-1 inline-flex h-5 w-5 items-center justify-center rounded-full bg-black/70 text-white"
                          >
                            <X size={11} />
                          </button>
                        </div>
                      );
                    })}
                  </div>
                ) : null}

                <div className={`relative flex items-end ${isExpanded ? "gap-2" : "gap-1.5"}`}>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/jpeg,image/png,image/webp,image/gif,audio/mpeg,audio/wav,audio/ogg,audio/webm,audio/mp4,audio/aac,audio/flac,video/mp4,video/webm,video/ogg,video/quicktime,video/x-m4v,.pdf,.doc,.docx,.xls,.xlsx,.csv,.heic,.heif,image/heic,image/heif"
                    multiple
                    onChange={handleFiles}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={sending || attachmentsLoading || selectedImages.length >= MAX_ATTACHMENTS_PER_MESSAGE}
                    title="Add or drop images, media, Word, Excel, or PDF · up to 5 files per send, 10 MB per file; paste screenshots with Ctrl+V"
                    aria-label="Add attachment"
                    className={`inline-flex ${isExpanded ? "h-10 w-10" : "h-9 w-9"} shrink-0 items-center justify-center rounded-xl text-sibs-orange transition hover:bg-sibs-cream-light active:scale-[0.96] disabled:opacity-40`}
                  >
                    <Plus size={18} />
                  </button>

                  <div className={`relative ${isExpanded ? "h-10" : "h-9"} shrink-0`}>
                    <button
                      ref={emojiButtonRef}
                      type="button"
                      onClick={() => {
                        setGifPickerOpen(false);
                        setEmojiPickerOpen((current) => !current);
                      }}
                      disabled={sending}
                      title="Choose emoji"
                      aria-label="Choose emoji"
                      aria-expanded={emojiPickerOpen}
                      className={`inline-flex ${isExpanded ? "h-10 w-10" : "h-9 w-9"} shrink-0 items-center justify-center rounded-xl transition active:scale-[0.96] disabled:opacity-40 ${
                        emojiPickerOpen
                          ? "bg-sibs-cream-subtle text-sibs-orange border border-sibs-orange/30"
                          : "text-sibs-muted hover:bg-sibs-cream-light hover:text-sibs-orange"
                      }`}
                    >
                      <Smile size={18} />
                    </button>

                    {emojiPickerOpen ? (
                      <div
                        ref={emojiPickerRef}
                        className="absolute bottom-[calc(100%+10px)] left-0 z-[160] w-[300px] max-w-[calc(100vw-3rem)] overflow-hidden rounded-2xl border border-sibs-border bg-white shadow-2xl"
                      >
                        <div className="flex items-center justify-between border-b border-sibs-border px-3 py-2.5">
                          <div>
                            <p className="text-[11px] font-extrabold text-sibs-navy">Emoji</p>
                            <p className="mt-0.5 text-[9px] font-semibold text-sibs-faint">Choose an emoji to add to your message</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setEmojiPickerOpen(false);
                              window.requestAnimationFrame(() => textareaRef.current?.focus());
                            }}
                            aria-label="Close emoji picker"
                            className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-sibs-muted transition hover:bg-sibs-surface hover:text-sibs-navy"
                          >
                            <X size={14} />
                          </button>
                        </div>

                        <div className="grid max-h-[260px] grid-cols-8 gap-1 overflow-y-auto p-2.5">
                          {CHAT_EMOJIS.map((emoji, index) => (
                            <button
                              key={`${emoji}-${index}`}
                              type="button"
                              onClick={() => insertEmoji(emoji)}
                              className="flex h-8 w-8 items-center justify-center rounded-lg text-[20px] leading-none transition hover:bg-sibs-cream-light hover:scale-110"
                              title={`Insert ${emoji}`}
                              aria-label={`Insert ${emoji}`}
                            >
                              {emoji}
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : null}
                  </div>

                  <div className={`relative ${isExpanded ? "h-10" : "h-9"} shrink-0`}>
                    <button
                      ref={gifButtonRef}
                      type="button"
                      onClick={() => {
                        setEmojiPickerOpen(false);
                        setGifPickerOpen((current) => {
                          const next = !current;
                          if (next) {
                            window.requestAnimationFrame(() =>
                              gifSearchInputRef.current?.focus(),
                            );
                          }
                          return next;
                        });
                      }}
                      disabled={sending}
                      title="Search GIFs online"
                      aria-label="Search GIFs online"
                      aria-expanded={gifPickerOpen}
                      className={`inline-flex ${isExpanded ? "h-10 w-10" : "h-9 w-9"} shrink-0 items-center justify-center rounded-xl transition active:scale-[0.96] disabled:opacity-40 ${
                        gifPickerOpen
                          ? "bg-sibs-cream-subtle text-sibs-orange border border-sibs-orange/30"
                          : "text-sibs-muted hover:bg-sibs-cream-light hover:text-sibs-orange"
                      }`}
                    >
                      <span className="text-[11px] font-black tracking-[-0.03em]">GIF</span>
                    </button>

                    {gifPickerOpen ? (
                      <div
                        ref={gifPickerRef}
                        className="absolute bottom-[calc(100%+10px)] left-0 z-[160] w-[340px] max-w-[calc(100vw-3rem)] overflow-hidden rounded-2xl border border-sibs-border bg-white shadow-2xl"
                      >
                        <div className="flex items-center justify-between border-b border-sibs-border px-3 py-2.5">
                          <div>
                            <p className="text-[11px] font-extrabold text-sibs-navy">GIFs</p>
                            <p className="mt-0.5 text-[9px] font-semibold text-sibs-faint">Search online GIFs and send instantly</p>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setGifPickerOpen(false);
                              window.requestAnimationFrame(() => textareaRef.current?.focus());
                            }}
                            aria-label="Close GIF picker"
                            className="inline-flex h-7 w-7 items-center justify-center rounded-lg text-sibs-muted transition hover:bg-sibs-surface hover:text-sibs-navy"
                          >
                            <X size={14} />
                          </button>
                        </div>

                        <div className="border-b border-sibs-border p-2.5">
                          <div className="flex h-9 items-center gap-2 rounded-xl border border-sibs-border bg-sibs-surface px-3 focus-within:border-sibs-orange focus-within:bg-white">
                            <Search size={14} className="shrink-0 text-sibs-faint" />
                            <input
                              ref={gifSearchInputRef}
                              value={gifSearch}
                              onChange={(event) => setGifSearch(event.target.value.slice(0, 50))}
                              placeholder="Search GIFs..."
                              className="min-w-0 flex-1 bg-transparent text-[11px] font-semibold text-sibs-navy outline-none placeholder:text-sibs-faint"
                            />
                            {gifSearch ? (
                              <button
                                type="button"
                                onClick={() => setGifSearch("")}
                                aria-label="Clear GIF search"
                                className="text-sibs-faint hover:text-sibs-navy"
                              >
                                <X size={13} />
                              </button>
                            ) : null}
                          </div>
                        </div>

                        <div className="sibs-scrollbar max-h-[310px] overflow-y-auto p-2.5">
                          {gifLoading ? (
                            <div className="flex min-h-36 items-center justify-center text-sibs-muted">
                              <Loader2 size={20} className="animate-spin" />
                            </div>
                          ) : gifError ? (
                            <div className="flex min-h-36 items-center justify-center px-4 text-center text-[10px] font-semibold leading-4 text-red-600">
                              {gifError}
                            </div>
                          ) : gifResults.length ? (
                            <div className="grid grid-cols-2 gap-1.5">
                              {gifResults.map((gif) => (
                                <button
                                  key={gif.id}
                                  type="button"
                                  onClick={() => void submitGif(gif)}
                                  disabled={sending}
                                  title={gif.title || "Send GIF"}
                                  className="group relative overflow-hidden rounded-xl bg-slate-100 disabled:opacity-50"
                                >
                                  <img
                                    src={gif.previewUrl}
                                    alt={gif.title || "GIF"}
                                    className="h-28 w-full object-cover transition duration-150 group-hover:scale-[1.03]"
                                    loading="lazy"
                                  />
                                </button>
                              ))}
                            </div>
                          ) : (
                            <div className="flex min-h-36 items-center justify-center text-center text-[10px] font-semibold text-sibs-faint">
                              No GIFs found.
                            </div>
                          )}
                        </div>

                        <div className="border-t border-sibs-border px-3 py-2 text-center text-[9px] font-extrabold tracking-wide text-sibs-faint">
                          Online GIF search
                        </div>
                      </div>
                    ) : null}
                  </div>

                  <div className="relative min-w-0 flex-1 self-end">
                    {activeConversation?.isGroup &&
                    mentionStart !== null &&
                    mentionCandidates.length ? (
                      <div className="absolute bottom-[calc(100%+8px)] left-0 z-[175] w-[min(320px,calc(100vw-5rem))] overflow-hidden rounded-2xl border border-sibs-border bg-white shadow-[0_18px_50px_rgba(4,44,81,0.20)]">
                        <div className="border-b border-sibs-border px-3 py-2">
                          <p className="text-[10px] font-extrabold text-sibs-navy">
                            Tag a group member
                          </p>
                          <p className="text-[9px] font-semibold text-sibs-faint">
                            Type @ then a name, SIBS ID, or everyone
                          </p>
                        </div>
                        <div className="sibs-scrollbar max-h-56 overflow-y-auto p-1.5">
                          {mentionCandidates.map((member, index) => (
                            <button
                              key={`mention-${member.sibsId}`}
                              type="button"
                              onMouseDown={(event) => event.preventDefault()}
                              onClick={() => insertMention(member)}
                              className={`flex w-full items-center gap-2 rounded-xl px-2.5 py-2 text-left transition ${
                                index === mentionActiveIndex
                                  ? "bg-sibs-cream-light text-sibs-orange font-bold"
                                  : "hover:bg-sibs-surface text-sibs-navy"
                              }`}
                            >
                              {member?.mentionEveryone ? (
                                <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-sibs-navy text-white shadow-sm">
                                  <UsersRound size={17} />
                                </span>
                              ) : (
                                <ChatAvatar
                                  employee={member}
                                  initials={member.initials}
                                  online={
                                    chat.presence?.[member.sibsId] ??
                                    member.online ??
                                    false
                                  }
                                  size="sm"
                                />
                              )}
                              <span className="min-w-0 flex-1">
                                <span className="block truncate text-[11px] font-extrabold text-sibs-navy">
                                  @{getChatMentionLabel(member)}
                                </span>
                                <span className="block truncate text-[9px] font-semibold text-sibs-muted">
                                  {member?.mentionEveryone
                                    ? "Tag all members in this group"
                                    : `${getChatMemberDisplayName(member)} · SIBS ID ${member.sibsId}`}
                                </span>
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    ) : null}

                    <textarea
                      ref={textareaRef}
                      value={draft}
                      disabled={activeConversation?.isHelpdesk && (activeConversation.caseStatus === "REJECTED" || (activeConversation.caseStatus === "RESOLVED" && cleanText(activeConversation.createdBySibsId) !== currentSibsId))}
                      onChange={(event) => {
                        const nextValue = event.target.value.slice(0, 5000);
                        setDraft(nextValue);
                        if (currentSibsId && activeConversation?.id) {
                          saveConversationDraft(currentSibsId, activeConversation.id, nextValue);
                        }
                        updateTypingIndicator(nextValue);
                        updateMentionPicker(
                          nextValue,
                          Math.min(event.target.selectionStart ?? nextValue.length, nextValue.length),
                        );
                      }}
                      onClick={(event) =>
                        updateMentionPicker(
                          draft,
                          event.currentTarget.selectionStart ?? draft.length,
                        )
                      }
                      onKeyUp={(event) => {
                        if (["ArrowUp", "ArrowDown", "Enter", "Tab", "Escape"].includes(event.key)) {
                          return;
                        }
                        updateMentionPicker(
                          draft,
                          event.currentTarget.selectionStart ?? draft.length,
                        );
                      }}
                      onKeyDown={handleComposerKeyDown}
                      onPaste={handleChatPaste}
                      onBlur={() => stopTypingIndicator(activeConversation?.id)}
                      rows={1}
                      placeholder={
                        activeConversation?.isGroup && isExpanded
                          ? "Type a message... (use @ to mention)"
                          : "Type a message..."
                      }
                      className={`block max-h-28 ${isExpanded ? "min-h-10" : "min-h-9"} w-full resize-none rounded-xl border border-sibs-border-subtle bg-sibs-surface px-3 py-2 text-xs font-medium leading-5 text-sibs-navy outline-none transition placeholder:text-sibs-faint hover:border-sibs-border focus:border-sibs-orange focus:bg-white focus:ring-2 focus:ring-sibs-orange/10 overflow-y-hidden no-scrollbar sibs-no-scrollbar [scrollbar-width:none] [-ms-overflow-style:none] [&::-webkit-scrollbar]:hidden`}
                    />
                  </div>

                  <button
                    type="button"
                    onClick={submitMessage}
                    disabled={sending || attachmentsLoading || (!cleanText(draft) && !selectedImages.length) || (activeConversation?.isHelpdesk && (activeConversation.caseStatus === "REJECTED" || (activeConversation.caseStatus === "RESOLVED" && cleanText(activeConversation.createdBySibsId) !== currentSibsId)))}
                    aria-label={attachmentsLoading ? "Preparing attachments" : "Send message"}
                    className={`relative z-[1] inline-flex ${isExpanded ? "h-10 w-10" : "h-9 w-9"} shrink-0 self-end items-center justify-center rounded-xl bg-sibs-orange text-white shadow-xs transition hover:bg-sibs-button-hover active:scale-[0.96] disabled:cursor-not-allowed disabled:bg-slate-100 disabled:text-sibs-faint disabled:shadow-none disabled:opacity-100`}
                  >
                    {sending || attachmentsLoading ? <Loader2 size={17} className="animate-spin" /> : <Send size={17} />}
                  </button>
                </div>
              </footer>
            </>
          ) : (
            <div className="flex h-full flex-col bg-sibs-canvas">
              <header className="flex h-[68px] shrink-0 items-center justify-between gap-1.5 border-b border-white/10 bg-sibs-navy px-4 text-white shadow-xs">
                <div className="min-w-0 flex-1 flex items-center gap-2.5">
                  <span className="inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-white/10 border border-white/15 text-sibs-orange shadow-xs">
                    <MessageCircleMore size={18} />
                  </span>
                  <div>
                    <h2 className="truncate font-heading text-sm font-extrabold text-white">
                      SiBS Chat Workspace
                    </h2>
                    <p className="text-[10px] font-semibold text-white/70">
                      Select a conversation or start a new request
                    </p>
                  </div>
                </div>

                <div className="flex shrink-0 items-center gap-0.5 sm:gap-1">
                  <button
                    type="button"
                    onClick={handleMinimize}
                    title="Minimize chat"
                    aria-label="Minimize chat"
                    className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                  >
                    <Minus size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={toggleExpanded}
                    title="Restore compact size"
                    aria-label="Restore compact size"
                    className="hidden h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white sm:inline-flex"
                  >
                    <Minimize2 size={15} />
                  </button>
                  <button
                    type="button"
                    onClick={handleClose}
                    title="Close SiBS Chat"
                    aria-label="Close SiBS Chat"
                    className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg text-white/75 transition hover:bg-white/10 hover:text-white"
                  >
                    <X size={16} />
                  </button>
                </div>
              </header>
              <div className="flex-1 min-h-0 flex flex-col">
                <EmptyChatState
                  onNewPrivateChat={() => {
                    setNewChatInitialMode("private");
                    setNewChatOpen(true);
                  }}
                  onNewGroupChat={() => {
                    setNewChatInitialMode("group");
                    setNewChatOpen(true);
                  }}
                  onContactHelpdesk={(category) => handleContactHelpdesk(category || "IT")}
                  onNewChat={() => {
                    setNewChatInitialMode("private");
                    setNewChatOpen(true);
                  }}
                />
              </div>
            </div>
          )}

          <NewChatOverlay
            open={newChatOpen}
            initialMode={newChatInitialMode}
            busy={actionBusy}
            onClose={handleCloseNewChat}
            onPrivateChat={(sibsId) =>
              runAction(() => chat.startPrivateConversation(sibsId))
            }
            onCreateGroup={(payload) =>
              runAction(() => chat.startGroupConversation(payload))
            }
          />

          <GroupInfoOverlay
            conversation={activeConversation}
            currentSibsId={currentSibsId}
            presence={chat.presence}
            helpdeskDuty={visibleHelpdeskDuty}
            helpdeskDutyLoading={helpdeskDutyLoading}
            helpdeskDutyError={helpdeskDutyError}
            open={groupInfoOpen}
            onClose={() => setGroupInfoOpen(false)}
            onRename={(conversationId, name) =>
              runAction(() => chat.renameGroup(conversationId, name))
            }
            onAddMembers={(conversationId, memberSibsIds) =>
              runAction(() => chat.addGroupMembers(conversationId, memberSibsIds))
            }
            onRemoveMember={(conversationId, sibsId) =>
              runAction(() => chat.removeGroupMember(conversationId, sibsId))
            }
            onLeave={(conversationId) =>
              runAction(async () => {
                await chat.leaveGroup(conversationId);
                setGroupInfoOpen(false);
              })
            }
          />

          <ChatThemeModal
            open={themeModalOpen}
            onClose={() => setThemeModalOpen(false)}
            conversation={activeConversation}
          />
        </div>
      </section>

      {documentPreview ? (
        <ChatDocumentPreviewModal
          attachment={documentPreview}
          getPreview={getChatAttachmentPreview}
          onClose={closeDocumentPreview}
        />
      ) : null}

      {nicknameConversation && typeof document !== "undefined"
        ? createPortal(
            <div
              className="fixed inset-0 z-[39] flex items-center justify-center bg-slate-950/45 px-4 backdrop-blur-[1px]"
              role="presentation"
              onMouseDown={(event) => {
                if (event.target === event.currentTarget && !nicknameSaving) {
                  setNicknameConversation(null);
                  setNicknameDraft("");
                }
              }}
            >
              <div
                role="dialog"
                aria-modal="true"
                aria-labelledby="chat-nickname-title"
                className="w-full max-w-[390px] overflow-hidden rounded-2xl border border-sibs-border bg-white shadow-[0_24px_70px_rgba(4,44,81,0.28)] font-jakarta"
                onMouseDown={(event) => event.stopPropagation()}
              >
                <div className="px-5 pb-4 pt-5">
                  <div className="flex items-start gap-3">
                    <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-sibs-orange">
                      <Pencil size={18} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <h3
                        id="chat-nickname-title"
                        className="font-heading text-sm font-extrabold text-sibs-navy"
                      >
                        Set nickname
                      </h3>
                      <p className="mt-1 text-[11px] font-semibold leading-5 text-sibs-muted">
                        This nickname is only for your personal chat with {nicknameConversation?.otherMember?.displayName || nicknameConversation?.title}. Group chats continue using the employee&apos;s SiBS HRIS nickname.
                      </p>
                    </div>
                  </div>

                  <label className="mt-4 block text-[10px] font-extrabold uppercase tracking-wide text-sibs-faint">
                    Nickname
                  </label>
                  <input
                    type="text"
                    autoFocus
                    maxLength={60}
                    value={nicknameDraft}
                    onChange={(event) => setNicknameDraft(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter") {
                        event.preventDefault();
                        void savePrivateNickname();
                      }
                    }}
                    placeholder={
                      cleanText(
                        nicknameConversation?.otherMember?.preferredName ||
                          nicknameConversation?.otherMember?.preferred_name,
                      ) || "Enter nickname"
                    }
                    className="mt-1.5 h-10 w-full rounded-xl border border-sibs-border bg-white px-3 text-xs font-bold text-sibs-navy outline-none transition focus:border-sibs-orange focus:ring-2 focus:ring-orange-100"
                  />
                  <div className="mt-1.5 flex items-center justify-between gap-3 text-[9px] font-semibold text-sibs-faint">
                    <span>Leave it empty to use the employee&apos;s regular HRIS name.</span>
                    <span>{nicknameDraft.length}/60</span>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 border-t border-sibs-border bg-sibs-canvas px-4 py-3">
                  <button
                    type="button"
                    onClick={() => {
                      setNicknameConversation(null);
                      setNicknameDraft("");
                    }}
                    disabled={nicknameSaving}
                    className="inline-flex h-9 items-center justify-center rounded-xl border border-sibs-border bg-white px-4 text-[11px] font-extrabold text-sibs-navy transition hover:bg-sibs-surface disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => void savePrivateNickname()}
                    disabled={nicknameSaving}
                    className="inline-flex h-9 min-w-[92px] items-center justify-center gap-2 rounded-xl bg-sibs-orange px-4 text-[11px] font-extrabold text-white shadow-sm transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {nicknameSaving ? (
                      <Loader2 size={14} className="animate-spin" />
                    ) : null}
                    Save
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}

      {helpdeskCloseConfirm && activeConversation?.isHelpdesk && typeof document !== "undefined"
        ? createPortal(
            <div
              className="fixed inset-0 z-[39] flex items-center justify-center bg-slate-950/55 px-4 backdrop-blur-[2px]"
              role="presentation"
              onMouseDown={(event) => event.stopPropagation()}
            >
              <div
                role="alertdialog"
                aria-modal="true"
                aria-labelledby="chat-helpdesk-close-title"
                aria-describedby="chat-helpdesk-close-description"
                className="w-full max-w-[420px] overflow-hidden rounded-2xl border border-sibs-border bg-white font-jakarta shadow-[0_24px_70px_rgba(4,44,81,0.28)]"
                onMouseDown={(event) => event.stopPropagation()}
              >
                <div className="border-t-[4px] border-sibs-orange bg-sibs-navy px-5 py-4">
                  <div className="flex items-center gap-3">
                    <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/20 bg-white/10 text-sibs-orange">
                      <CheckCircle2 size={21} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <h3 id="chat-helpdesk-close-title" className="font-heading text-sm font-extrabold text-white">
                        Close this case?
                      </h3>
                      <p className="mt-0.5 text-[10px] font-semibold text-white/75">
                        Confirm case resolution
                      </p>
                    </div>
                  </div>
                </div>
                <div className="px-5 py-5">
                  <p id="chat-helpdesk-close-description" className="text-xs font-semibold leading-5 text-sibs-muted">
                    Only close this case when the problem has been fixed. This action cannot be undone.
                  </p>
                  <p className="mt-3 rounded-xl border border-sibs-border bg-sibs-surface px-3 py-2 text-[11px] font-bold text-sibs-navy">
                    {getHelpdeskCaseLabel(activeConversation)}
                  </p>
                </div>
                <div className="flex items-center justify-end gap-2 border-t border-sibs-border bg-sibs-canvas px-5 py-3">
                  <button
                    type="button"
                    autoFocus
                    disabled={helpdeskStatusSaving}
                    onClick={() => setHelpdeskCloseConfirm(false)}
                    className="inline-flex h-10 items-center justify-center rounded-xl border border-sibs-border bg-white px-4 text-[11px] font-extrabold text-sibs-navy transition hover:bg-sibs-surface focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sibs-orange disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    disabled={helpdeskStatusSaving || !canChangeHelpdeskStatus}
                    onClick={() => void changeHelpdeskCaseStatus('RESOLVED')}
                    className="inline-flex h-10 min-w-[132px] items-center justify-center gap-2 rounded-xl bg-sibs-orange px-4 text-[11px] font-extrabold text-white shadow-sm transition hover:brightness-95 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sibs-orange disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {helpdeskStatusSaving ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={14} />}
                    {helpdeskStatusSaving ? 'Closing…' : 'Close Case'}
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}

      {deleteConversationConfirm && typeof document !== "undefined"
        ? createPortal(
            <div
              className="fixed inset-0 z-[39] flex items-center justify-center bg-slate-950/45 px-4 backdrop-blur-[1px]"
              role="presentation"
              onMouseDown={(event) => {
                if (
                  event.target === event.currentTarget &&
                  !conversationActionBusyId
                ) {
                  setDeleteConversationConfirm(null);
                }
              }}
            >
              <div
                role="alertdialog"
                aria-modal="true"
                aria-labelledby="chat-delete-conversation-title"
                aria-describedby="chat-delete-conversation-description"
                className="w-full max-w-[390px] overflow-hidden rounded-2xl border border-sibs-border bg-white shadow-[0_24px_70px_rgba(4,44,81,0.28)] font-jakarta"
                onMouseDown={(event) => event.stopPropagation()}
              >
                <div className="px-5 pb-4 pt-5">
                  <div className="flex items-start gap-3">
                    <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-50 text-red-600">
                      <Trash2 size={19} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <h3
                        id="chat-delete-conversation-title"
                        className="font-heading text-sm font-extrabold text-sibs-navy"
                      >
                        Delete conversation?
                      </h3>
                      <p
                        id="chat-delete-conversation-description"
                        className="mt-1.5 text-[11px] font-semibold leading-5 text-sibs-muted"
                      >
                        This removes your current personal chat history with {deleteConversationConfirm.title}. It does not remove the other employee&apos;s copy. New messages can make the conversation appear again.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 border-t border-sibs-border bg-sibs-canvas px-4 py-3">
                  <button
                    type="button"
                    onClick={() => setDeleteConversationConfirm(null)}
                    disabled={Boolean(conversationActionBusyId)}
                    className="inline-flex h-9 items-center justify-center rounded-xl border border-sibs-border bg-white px-4 text-[11px] font-extrabold text-sibs-navy transition hover:bg-sibs-surface disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => void confirmDeleteConversation()}
                    disabled={Boolean(conversationActionBusyId)}
                    className="inline-flex h-9 min-w-[86px] items-center justify-center gap-2 rounded-xl bg-red-600 px-4 text-[11px] font-extrabold text-white shadow-sm transition hover:bg-red-700 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {conversationActionBusyId ? (
                      <Loader2 size={14} className="animate-spin" />
                    ) : null}
                    Delete
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}

      {unsendConfirmMessage && typeof document !== "undefined"
        ? createPortal(
            <div
              className="fixed inset-0 z-[39] flex items-center justify-center bg-slate-950/45 px-4 backdrop-blur-[1px]"
              role="presentation"
              onMouseDown={(event) => {
                if (
                  event.target === event.currentTarget &&
                  !unsendingMessageId
                ) {
                  setUnsendConfirmMessage(null);
                }
              }}
            >
              <div
                role="alertdialog"
                aria-modal="true"
                aria-labelledby="chat-unsend-title"
                aria-describedby="chat-unsend-description"
                className="w-full max-w-[390px] overflow-hidden rounded-2xl border border-sibs-border bg-white shadow-[0_24px_70px_rgba(4,44,81,0.28)] font-jakarta"
                onMouseDown={(event) => event.stopPropagation()}
              >
                <div className="px-5 pb-4 pt-5">
                  <div className="flex items-start gap-3">
                    <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-sibs-cream-light border border-sibs-orange/20 text-sibs-orange">
                      <MessageCircleMore size={20} />
                    </span>
                    <div className="min-w-0 flex-1">
                      <h3
                        id="chat-unsend-title"
                        className="font-heading text-sm font-extrabold text-sibs-navy"
                      >
                        Unsend message?
                      </h3>
                      <p
                        id="chat-unsend-description"
                        className="mt-1.5 text-[11px] font-semibold leading-5 text-sibs-muted"
                      >
                        This message will be removed from the chat for everyone.
                        The record will remain in the system for audit purposes.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 border-t border-sibs-border bg-sibs-surface px-4 py-3">
                  <button
                    type="button"
                    onClick={() => setUnsendConfirmMessage(null)}
                    disabled={Boolean(unsendingMessageId)}
                    className="inline-flex h-9 items-center justify-center rounded-xl border border-sibs-border bg-white px-4 text-[11px] font-extrabold text-sibs-navy transition hover:bg-sibs-surface disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={() => void confirmUnsendMessage()}
                    disabled={Boolean(unsendingMessageId)}
                    className="inline-flex h-9 min-w-[86px] items-center justify-center gap-2 rounded-xl bg-sibs-orange px-4 text-[11px] font-extrabold text-white shadow-sm transition hover:brightness-95 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    {unsendingMessageId ? (
                      <Loader2 size={14} className="animate-spin" />
                    ) : null}
                    Unsend
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </>
  );

  // Keep the floating chat beneath HRIS dialogs and page overlays.
  // Its photo hover and confirmations sit just above the chat panel, not over
  // other modules. A body portal still avoids accidental clipping in AppShell.
  return typeof document !== "undefined"
    ? createPortal(chatUi, document.body)
    : chatUi;
}
